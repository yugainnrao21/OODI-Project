package view;

import report.ReportingMainFrame; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class MasterDashboard extends JFrame {

    // %%%% Shared Bakery System Colors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_LIGHT     = new Color(220, 200, 200);
    static final Color GOLD           = new Color(218, 165,  32);

    public MasterDashboard() {
        setTitle("Bakery Sales Inventory and Management System");
        setSize(700, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 110);
        mainPanel.add(headerBar);

        JLabel lblTitle = new JLabel("BAKERY SALES, INVENTORY & MANAGEMENT", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24)); 
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(10, 18, 680, 38);
        headerBar.add(lblTitle);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 108, 700, 3);
        mainPanel.add(goldBar);

        JLabel lblSubtitle = new JLabel("Master Application Gateway", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblSubtitle.setForeground(TEXT_LIGHT);
        lblSubtitle.setBounds(30, 70, 640, 22);
        headerBar.add(lblSubtitle);

        JPanel cardArea = new JPanel(null);
        cardArea.setBackground(CREAM);
        cardArea.setBounds(50, 140, 600, 380);
        cardArea.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(cardArea);

        JLabel lblMenu = new JLabel("SELECT A SYSTEM MODULE", SwingConstants.CENTER);
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMenu.setForeground(CRIMSON_DARK);
        lblMenu.setBounds(0, 20, 600, 22);
        cardArea.add(lblMenu);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(GOLD);
        cardSep.setBounds(100, 50, 400, 2);
        cardArea.add(cardSep);

        JPanel gridPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        gridPanel.setBackground(CREAM);
        gridPanel.setBounds(40, 70, 520, 280); 
        
        // 1. PRODUCT MANAGEMENT
        JButton btnProduct = createIconButton("🍞", "1. PRODUCT MANAGEMENT");
        btnProduct.addActionListener(e -> {
            new product.SmartInventoryApp().setVisible(true);
            this.dispose();
        });
        gridPanel.add(btnProduct);

        // 2. SUPPLIER MANAGEMENT
        JButton btnSupplier = createIconButton("🚚", "2. SUPPLIER MANAGEMENT");
        btnSupplier.addActionListener(e -> {
            new MainDashboard().setVisible(true); 
            this.dispose();
        });
        gridPanel.add(btnSupplier);

        // 3. SALES & ORDER PROCESSING
        JButton btnSales = createIconButton("🛒", "3. SALES & ORDER PROCESSING");
        btnSales.addActionListener(e -> {
            new sales.view.BakeryApp().setVisible(true);
            this.dispose();
        });
        gridPanel.add(btnSales);

        // 4. REPORTING & ANALYTICS (FIXED: NOW POINTS TO THE HUB)
        JButton btnReporting = createIconButton("📊", "4. REPORTING & ANALYTICS");
        btnReporting.addActionListener(e -> {
            new ReportingMainFrame().setVisible(true); 
            this.dispose();
        });
        gridPanel.add(btnReporting);

        cardArea.add(gridPanel);

        JButton btnExit = new JButton("SHUT DOWN SYSTEM");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnExit.setBackground(new Color(200, 180, 180));
        btnExit.setForeground(CRIMSON_DARK);
        btnExit.setFocusPainted(false);
        btnExit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnExit.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        btnExit.setBounds(250, 545, 200, 38);
        btnExit.addActionListener(e -> System.exit(0)); 
        mainPanel.add(btnExit);

        setContentPane(mainPanel);
    }

    private JButton createIconButton(String icon, String text) {
        String htmlFormat = "<html><center><span style='font-size:28px;'>" + icon + 
                            "</span><br><br><span style='font-size:12px; font-weight:bold;'>" + 
                            "<nobr>" + text.replace("<br>", "</nobr><br><nobr>") + "</nobr>" + 
                            "</span></center></html>";
        JButton btn = new JButton(htmlFormat);
        
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MasterDashboard().setVisible(true));
    }
}