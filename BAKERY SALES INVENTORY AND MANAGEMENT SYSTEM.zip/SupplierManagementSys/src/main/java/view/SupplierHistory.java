package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

// ============================================================
// CLASS: SupplierHistory
// From Class Diagram: <<Boundary>>
// Fields: searchField, historyTable
// Methods: enterSearchKeyword(), selectSupplier(), showSupplierProfile(),
//          enableEditMode(), submitUpdatedInfo(), clickDeactivateSupplier(),
//          showHistoryTable(), showErrorMessage()
// ============================================================

public class SupplierHistory extends JFrame {

    // %%%% Colour palette (matching friend's BakeryApp design) %%%%%%%%%%%%%%%%%%%
    private static final Color CRIMSON      = new Color(139,   0,  28);
    private static final Color CRIMSON_DARK = new Color(100,   0,  20);
    private static final Color CRIMSON_SOFT = new Color(180,  30,  55);
    private static final Color CREAM        = new Color(255, 248, 240);
    private static final Color WHITE        = Color.WHITE;
    private static final Color TEXT_DARK    = new Color( 30,  10,  10);
    private static final Color TEXT_LIGHT   = new Color(220, 200, 200);
    private static final Color GOLD         = new Color(218, 165,  32);
    private static final Color TABLE_ROW_A  = new Color(255, 245, 245);
    private static final Color TABLE_ROW_B  = new Color(255, 255, 255);
    private static final Color INPUT_BG     = new Color(255, 248, 240);

    // %%%% Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    private static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD,  22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    private static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    private static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Fields matching class diagram — names UNCHANGED
    private JTextField searchField;      // searchField from class diagram
    private JTable     historyTable;     // historyTable from class diagram

    // Extra UI components — names UNCHANGED
    private JTextField txtName;
    private JTextField txtContact;
    private JTextField txtEmail;
    private JTextField txtAddress;
    private JTextField txtStatus;
    private JButton    btnSearch;
    private JButton    btnClear;
    private JButton    btnBack;
    private JButton    btnUpdate;
    private JButton    btnDelete;
    private JPanel     mainPanel;
    private DefaultTableModel tableModel;

    public SupplierHistory() {
        initComponents();
        setTitle("Supplier History");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 920);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void initComponents() {
        mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // ---- Header bar ----
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 100);
        mainPanel.add(headerBar);

        // ---- BACK button ----
        btnBack = makeButton("< BACK", new Color(180, 130, 130));
        btnBack.setForeground(WHITE);
        btnBack.setBounds(10, 10, 85, 28);
        btnBack.addActionListener(e -> {
            new MainDashboard().setVisible(true);
            this.dispose();
        });
        headerBar.add(btnBack);

        // ---- Title ----
        JLabel lblTitle = new JLabel("SUPPLIER HISTORY", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(0, 28, 700, 42);
        headerBar.add(lblTitle);

        // ---- Gold divider ----
        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 100, 700, 3);
        mainPanel.add(goldBar);

        // ---- Search bar card ----
        JPanel searchCard = new JPanel(null);
        searchCard.setBackground(CREAM);
        searchCard.setBounds(25, 115, 650, 58);
        searchCard.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        mainPanel.add(searchCard);

        JLabel lblSearch = new JLabel("Supplier ID :");
        lblSearch.setFont(FONT_HEADER);
        lblSearch.setForeground(CRIMSON_DARK);
        lblSearch.setBounds(15, 17, 110, 24);
        searchCard.add(lblSearch);

        searchField = new JTextField();                // searchField — diagram field
        searchField.setBackground(INPUT_BG);
        searchField.setFont(FONT_BODY);
        searchField.setForeground(TEXT_DARK);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 140, 140), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        searchField.setBounds(130, 15, 330, 28);
        searchField.addActionListener(e -> enterSearchKeyword(searchField.getText().trim()));
        searchCard.add(searchField);

        btnSearch = makeButton("Search", CRIMSON);
        btnSearch.setForeground(WHITE);
        btnSearch.setBounds(475, 15, 110, 28);
        btnSearch.addActionListener(e -> enterSearchKeyword(searchField.getText().trim()));
        searchCard.add(btnSearch);

        // ---- Profile card ----
        JPanel profileCard = new JPanel(null);
        profileCard.setBackground(CREAM);
        profileCard.setBounds(25, 185, 650, 265);
        profileCard.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        mainPanel.add(profileCard);

        JLabel lblProfile = new JLabel("SUPPLIER PROFILE", SwingConstants.LEFT);
        lblProfile.setFont(FONT_HEADER);
        lblProfile.setForeground(CRIMSON_DARK);
        lblProfile.setBounds(15, 10, 250, 20);
        profileCard.add(lblProfile);

        JSeparator pSep = new JSeparator();
        pSep.setForeground(GOLD);
        pSep.setBounds(15, 34, 620, 2);
        profileCard.add(pSep);

        // Profile fields
        int lx = 15, fx = 130, fw = 490, pgy = 45, pgap = 42;

        addProfileLabel(profileCard, "Name :",    lx, pgy);
        txtName    = makeReadonlyField();
        txtName.setBounds(fx, pgy - 3, fw, 28);
        profileCard.add(txtName);

        addProfileLabel(profileCard, "Contact :", lx, pgy + pgap);
        txtContact = makeReadonlyField();
        txtContact.setBounds(fx, pgy + pgap - 3, fw, 28);
        profileCard.add(txtContact);

        addProfileLabel(profileCard, "Email :",   lx, pgy + pgap * 2);
        txtEmail   = makeReadonlyField();
        txtEmail.setBounds(fx, pgy + pgap * 2 - 3, fw, 28);
        profileCard.add(txtEmail);

        addProfileLabel(profileCard, "Address :", lx, pgy + pgap * 3);
        txtAddress = makeReadonlyField();
        txtAddress.setBounds(fx, pgy + pgap * 3 - 3, fw, 28);
        profileCard.add(txtAddress);

        addProfileLabel(profileCard, "Status :",  lx, pgy + pgap * 4);
        txtStatus  = makeReadonlyField();
        txtStatus.setBounds(fx, pgy + pgap * 4 - 3, fw, 28);
        profileCard.add(txtStatus);

        // ---- Order History card ----
        JPanel historyCard = new JPanel(null);
        historyCard.setBackground(CREAM);
        historyCard.setBounds(25, 462, 650, 340);
        historyCard.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        mainPanel.add(historyCard);

        JLabel lblHistory = new JLabel("ORDER HISTORY", SwingConstants.LEFT);
        lblHistory.setFont(FONT_HEADER);
        lblHistory.setForeground(CRIMSON_DARK);
        lblHistory.setBounds(15, 10, 250, 20);
        historyCard.add(lblHistory);

        JSeparator hSep = new JSeparator();
        hSep.setForeground(GOLD);
        hSep.setBounds(15, 34, 620, 2);
        historyCard.add(hSep);

        // ---- History table (with alternating row colours like BakeryApp) ----
        tableModel = new DefaultTableModel(
            new Object[][]{},
            new String[]{"PO NUMBER", "ORDER DATE", "TOTAL AMOUNT (RM)", "STATUS"}
        ) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };

        historyTable = new JTable(tableModel);        // historyTable — diagram field
        historyTable.setFont(FONT_BODY);
        historyTable.setRowHeight(26);
        historyTable.setShowGrid(false);
        historyTable.setIntercellSpacing(new Dimension(0, 1));
        historyTable.setSelectionBackground(CRIMSON);
        historyTable.setSelectionForeground(WHITE);

        // Alternating rows — same pattern as BakeryApp
        historyTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) comp.setBackground(r % 2 == 0 ? TABLE_ROW_A : TABLE_ROW_B);
                comp.setForeground(sel ? WHITE : TEXT_DARK);
                return comp;
            }
        });

        historyTable.getTableHeader().setFont(FONT_HEADER);
        historyTable.getTableHeader().setBackground(CRIMSON);
        historyTable.getTableHeader().setForeground(WHITE);
        historyTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane tableScroll = new JScrollPane(historyTable);
        tableScroll.setBounds(15, 45, 620, 265);
        tableScroll.setBorder(BorderFactory.createLineBorder(CRIMSON, 1));
        historyCard.add(tableScroll);

        // ---- Action buttons bar ----
        JPanel btnBar = new JPanel(null);
        btnBar.setBackground(CRIMSON_DARK);
        btnBar.setBounds(0, 818, 700, 60);
        mainPanel.add(btnBar);

        btnClear = makeButton("↺  CLEAR",  new Color(180, 130, 130));
        btnClear.setForeground(WHITE);
        btnClear.setBounds(60, 12, 150, 36);
        btnClear.addActionListener(e -> clearAll());
        btnBar.add(btnClear);

        btnUpdate = makeButton("✎  UPDATE", new Color(218, 165, 32));
        btnUpdate.setForeground(TEXT_DARK);
        btnUpdate.setBounds(270, 12, 150, 36);
        btnUpdate.addActionListener(e -> submitUpdatedInfo(null));
        btnBar.add(btnUpdate);

        btnDelete = makeButton("✕  DELETE", new Color(200, 50, 60));
        btnDelete.setForeground(WHITE);
        btnDelete.setBounds(478, 12, 150, 36);
        btnDelete.addActionListener(e -> clickDeactivateSupplier());
        btnBar.add(btnDelete);

        setContentPane(mainPanel);
    }

    // ---- Helpers ----
    private void addProfileLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_HEADER);
        lbl.setForeground(CRIMSON_DARK);
        lbl.setBounds(x, y, 110, 24);
        panel.add(lbl);
    }

    private JTextField makeReadonlyField() {
        JTextField tf = new JTextField();
        tf.setEditable(false);
        tf.setBackground(WHITE);
        tf.setFont(FONT_BODY);
        tf.setForeground(TEXT_DARK);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 140, 140), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        return tf;
    }

    private JButton makeButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 1),
            BorderFactory.createEmptyBorder(3, 10, 3, 10)
        ));
        return btn;
    }

    // ---------- Class diagram methods ----------

    // + enterSearchKeyword(keyword : String) : void
    public void enterSearchKeyword(String keyword) {
        if (keyword.isEmpty()) {
            showErrorMessage("Please enter a Supplier ID to search.");
            return;
        }
        selectSupplier(keyword);
    }

    // + selectSupplier(supplierID : String) : void
    public void selectSupplier(String supplierID) {
        controller.SupplierController sc = new controller.SupplierController();
        model.Supplier found = sc.searchSupplier(supplierID);
        if (found != null) {
            showSupplierProfile(found);
            showHistoryTable(sc.requestSupplierHistory(supplierID));
        } else {
            clearProfileFields();
            JOptionPane.showMessageDialog(this,
                "No supplier found with ID: " + supplierID,
                "Search Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // + showSupplierProfile(supplierData : Supplier) : void
    public void showSupplierProfile(model.Supplier s) {
        txtName.setText(s.getSupplierName());
        txtContact.setText(s.getContactNumber());
        txtEmail.setText(s.getEmail());
        txtAddress.setText(s.getAddress().replace("[COMMA]", ","));
        txtStatus.setText(s.getStatus());
    }

    // + enableEditMode() : void
    public void enableEditMode() {
        txtName.setEditable(true);
        txtContact.setEditable(true);
        txtEmail.setEditable(true);
        txtAddress.setEditable(true);
    }

    // + submitUpdatedInfo(updatedData : Object) : boolean
    public boolean submitUpdatedInfo(Object updatedData) {
        String id = searchField.getText().trim();
        if (id.isEmpty()) {
            showErrorMessage("Please search for a supplier first.");
            return false;
        }
        String[] options   = {"Active", "Inactive"};
        String   newStatus = (String) JOptionPane.showInputDialog(
                this,
                "Select new status for supplier " + id + ":",
                "Update Status",
                JOptionPane.QUESTION_MESSAGE,
                null, options, options[0]);
        if (newStatus == null) return false;

        controller.SupplierController sc = new controller.SupplierController();
        boolean ok = sc.updateStatus(id, newStatus);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Status updated to: " + newStatus);
            txtStatus.setText(newStatus);
        } else {
            showErrorMessage("Could not update status.");
        }
        return ok;
    }

    // + clickDeactivateSupplier() : void
    public void clickDeactivateSupplier() {
        String id = searchField.getText().trim();
        if (id.isEmpty()) {
            showErrorMessage("Please search for a supplier first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete supplier '" + id + "'? This cannot be undone.",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        controller.SupplierController sc = new controller.SupplierController();
        boolean ok = sc.deleteSupplier(id);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Supplier '" + id + "' deleted successfully.");
            clearAll();
        } else {
            showErrorMessage("Could not delete supplier.");
        }
    }

    // + showHistoryTable(formattedHistory : List) : void
    public void showHistoryTable(java.util.List<String[]> formattedHistory) {
        tableModel.setRowCount(0);
        if (formattedHistory != null) {
            for (String[] row : formattedHistory) {
                tableModel.addRow(row);
            }
        }
    }

    // + showErrorMessage() : void
    public void showErrorMessage() {
        JOptionPane.showMessageDialog(this, "An error occurred.",
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message,
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearAll() {
        searchField.setText("");
        clearProfileFields();
        tableModel.setRowCount(0);
    }

    private void clearProfileFields() {
        txtName.setText("");
        txtContact.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        txtStatus.setText("");
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new SupplierHistory().setVisible(true));
    }
}