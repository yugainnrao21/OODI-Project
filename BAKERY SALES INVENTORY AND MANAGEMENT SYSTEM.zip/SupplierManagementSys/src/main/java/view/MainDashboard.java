package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class MainDashboard extends JFrame {

    // %%%% Colour palette %%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color TEXT_LIGHT     = new Color(220, 200, 200);
    static final Color GOLD           = new Color(218, 165,  32);

    // %%%% Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    public MainDashboard() {
        setTitle("Supplier Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 620);
        setLocationRelativeTo(null);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // Header
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 110);
        mainPanel.add(headerBar);

        JLabel lblTitle = new JLabel("SUPPLIER MANAGEMENT SYSTEM", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(30, 18, 640, 38);
        headerBar.add(lblTitle);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 108, 700, 3);
        mainPanel.add(goldBar);

        JLabel lblSubtitle = new JLabel("Track your ingredients and manage your baking partners", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubtitle.setForeground(TEXT_LIGHT);
        lblSubtitle.setBounds(30, 70, 640, 22);
        headerBar.add(lblSubtitle);

        // Card area
        JPanel cardArea = new JPanel(null);
        cardArea.setBackground(CREAM);
        cardArea.setBounds(50, 140, 600, 360);
        cardArea.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(cardArea);

        JLabel lblMenu = new JLabel("SELECT AN OPTION", SwingConstants.CENTER);
        lblMenu.setFont(FONT_HEADER);
        lblMenu.setForeground(CRIMSON_DARK);
        lblMenu.setBounds(0, 18, 600, 22);
        cardArea.add(lblMenu);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(GOLD);
        cardSep.setBounds(20, 46, 560, 2);
        cardArea.add(cardSep);

        // Buttons
        JButton btnManageSuppliers = createMenuButton("📅 REGISTER SUPPLIER");
        btnManageSuppliers.setBounds(100, 70, 400, 60);
        btnManageSuppliers.addActionListener(e -> clickSupplierManagement());
        cardArea.add(btnManageSuppliers);

        JButton btnHistory = createMenuButton("📅 SUPPLIER HISTORY");
        btnHistory.setBounds(100, 150, 400, 60);
        btnHistory.addActionListener(e -> {
            new SupplierHistory().setVisible(true);
            this.dispose();
        });
        cardArea.add(btnHistory);

        JButton btnManageOrders = createMenuButton("📅 MANAGE ORDERS");
        btnManageOrders.setBounds(100, 230, 400, 60);
        btnManageOrders.addActionListener(e -> clickOrderManagement());
        cardArea.add(btnManageOrders);

        // Updated BACK button
        JButton btnBack = new JButton("< BACK TO MAIN DASHBOARD");
        btnBack.setFont(FONT_BTN);
        btnBack.setBackground(new Color(200, 180, 180));
        btnBack.setForeground(CRIMSON_DARK);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        btnBack.setBounds(225, 515, 250, 38);
        btnBack.addActionListener(e -> {
            new MasterDashboard().setVisible(true);
            this.dispose();
        });
        mainPanel.add(btnBack);

        setContentPane(mainPanel);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    public void clickSupplierManagement() {
        new RegisterSupplier().setVisible(true);
        this.dispose();
    }

    public void clickOrderManagement() {
        new PurchaseOrderHandling().setVisible(true);
        this.dispose();
    }
}