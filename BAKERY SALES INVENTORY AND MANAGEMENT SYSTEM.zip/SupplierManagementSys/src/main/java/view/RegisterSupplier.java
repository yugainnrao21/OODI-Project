package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

// ============================================================
// CLASS: RegisterSupplier
// From Class Diagram: <<Boundary>>
// Fields: txtName, cbSupplierType
// Methods: displayRegistrationForm(), submitSupplierForm(),
//         showSuccessMessage(), showErrorMessage()
// ============================================================

public class RegisterSupplier extends JFrame {

    // %%%% Colour palette %%%%
    private static final Color CRIMSON      = new Color(139,   0,  28);
    private static final Color CRIMSON_DARK = new Color(100,   0,  20);
    private static final Color CRIMSON_SOFT = new Color(180,  30,  55);
    private static final Color CREAM        = new Color(255, 248, 240);
    private static final Color WHITE        = Color.WHITE;
    private static final Color TEXT_DARK    = new Color( 30,  10,  10);
    private static final Color TEXT_LIGHT   = new Color(220, 200, 200);
    private static final Color GOLD         = new Color(218, 165,  32);
    private static final Color INPUT_BG     = new Color(255, 248, 240); 

    // %%%% Fonts %%%%
    private static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD,  22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    private static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Fields matching class diagram 
    private JTextField        txtSupplierID;
    private JTextField        txtName;                
    private JComboBox<String> cbSupplierType;        
    private JTextField        txtContactNumber;
    private JTextField        txtEmail;
    private JTextArea         txtAddress;
    private JComboBox<String> cmbStatus;
    
    // NEW FIELDS FOR TOPSIS
    private JTextField        txtCostScore;
    private JTextField        txtDeliveryScore;
    private JTextField        txtQualityScore;

    private JButton           btnSubmit;
    private JButton           btnClear;
    private JButton           btnBack;
    private JLabel            lblTitle;
    private JPanel            mainPanel;

    public RegisterSupplier() {
        initComponents();
        setTitle("Register New Supplier");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(620, 780); // Increased height to fit the new metrics
        setLocationRelativeTo(null);
        setResizable(false);
        displayRegistrationForm();
    }

    private void initComponents() {
        mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // ---- Header bar ----
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 620, 100);
        mainPanel.add(headerBar);

        // ---- BACK button ----
        btnBack = new JButton("< BACK");
        btnBack.setFont(FONT_BTN);
        btnBack.setBackground(new Color(180, 130, 130));
        btnBack.setForeground(WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(160, 100, 100), 1));
        btnBack.setBounds(10, 10, 85, 28);
        btnBack.addActionListener(e -> {
            new MainDashboard().setVisible(true);
            this.dispose();
        });
        headerBar.add(btnBack);

        // ---- Title ----
        lblTitle = new JLabel("REGISTER NEW SUPPLIER", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(0, 28, 620, 38);
        headerBar.add(lblTitle);

        // ---- Gold divider ----
        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 100, 620, 3);
        mainPanel.add(goldBar);

        // ---- Form card ----
        JPanel formCard = new JPanel(null);
        formCard.setBackground(CREAM);
        formCard.setBounds(30, 120, 560, 590); // Expanded card height
        formCard.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(formCard);

        JLabel lblFormTitle = new JLabel("Supplier Information", SwingConstants.LEFT);
        lblFormTitle.setFont(FONT_HEADER);
        lblFormTitle.setForeground(CRIMSON_DARK);
        lblFormTitle.setBounds(20, 12, 300, 20);
        formCard.add(lblFormTitle);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(GOLD);
        cardSep.setBounds(20, 36, 520, 2);
        formCard.add(cardSep);

        // ---- Form layout ----
        int labelX = 20, fieldX = 185, fieldW = 340, startY = 48, gap = 45;

        addFormLabel(formCard, "Supplier ID :", labelX, startY);
        txtSupplierID = makeTextField();
        txtSupplierID.setBounds(fieldX, startY - 3, fieldW, 28);
        formCard.add(txtSupplierID);

        addFormLabel(formCard, "Supplier Name :", labelX, startY + gap);
        txtName = makeTextField();                    
        txtName.setBounds(fieldX, startY + gap - 3, fieldW, 28);
        formCard.add(txtName);

        addFormLabel(formCard, "Supplier Type :", labelX, startY + gap * 2);
        cbSupplierType = new JComboBox<>(new String[]{"Local", "Overseas"}); 
        styleCombo(cbSupplierType);
        cbSupplierType.setBounds(fieldX, startY + gap * 2 - 3, fieldW, 28);
        formCard.add(cbSupplierType);

        addFormLabel(formCard, "Contact Number :", labelX, startY + gap * 3);
        txtContactNumber = makeTextField();
        txtContactNumber.setBounds(fieldX, startY + gap * 3 - 3, fieldW, 28);
        formCard.add(txtContactNumber);

        addFormLabel(formCard, "Email :", labelX, startY + gap * 4);
        txtEmail = makeTextField();
        txtEmail.setBounds(fieldX, startY + gap * 4 - 3, fieldW, 28);
        formCard.add(txtEmail);

        addFormLabel(formCard, "Address :", labelX, startY + gap * 5);
        JScrollPane scrollAddr = new JScrollPane();
        txtAddress = new JTextArea(3, 20);
        txtAddress.setBackground(INPUT_BG);
        txtAddress.setFont(FONT_BODY);
        txtAddress.setForeground(TEXT_DARK);
        txtAddress.setLineWrap(true);
        txtAddress.setBorder(BorderFactory.createLineBorder(new Color(200, 140, 140), 1));
        scrollAddr.setViewportView(txtAddress);
        scrollAddr.setBounds(fieldX, startY + gap * 5 - 3, fieldW, 58);
        formCard.add(scrollAddr);

        // Sub-header for TOPSIS Metrics
        JLabel lblMetrics = new JLabel("Performance Metrics (TOPSIS Algorithm)", SwingConstants.LEFT);
        lblMetrics.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblMetrics.setForeground(CRIMSON_DARK);
        lblMetrics.setBounds(20, startY + gap * 5 + 70, 300, 20);
        formCard.add(lblMetrics);

        // The 3 New TOPSIS Inputs
        int metricStartY = startY + gap * 5 + 95;
        
        addFormLabel(formCard, "Cost Score :", labelX, metricStartY);
        txtCostScore = makeTextField();
        txtCostScore.setBounds(fieldX, metricStartY - 3, fieldW, 28);
        formCard.add(txtCostScore);
        
        addFormLabel(formCard, "Delivery Score :", labelX, metricStartY + 35);
        txtDeliveryScore = makeTextField();
        txtDeliveryScore.setBounds(fieldX, metricStartY + 35 - 3, fieldW, 28);
        formCard.add(txtDeliveryScore);
        
        addFormLabel(formCard, "Quality Score :", labelX, metricStartY + 70);
        txtQualityScore = makeTextField();
        txtQualityScore.setBounds(fieldX, metricStartY + 70 - 3, fieldW, 28);
        formCard.add(txtQualityScore);

        addFormLabel(formCard, "Status :", labelX, metricStartY + 115);
        cmbStatus = new JComboBox<>(new String[]{"Active", "Inactive"});
        styleCombo(cmbStatus);
        cmbStatus.setBounds(fieldX, metricStartY + 112, fieldW, 28);
        formCard.add(cmbStatus);

        // ---- Separator before buttons ----
        JSeparator sep2 = new JSeparator();
        sep2.setForeground(GOLD);
        sep2.setBounds(20, 540, 520, 2);
        formCard.add(sep2);

        // ---- Buttons inside card ----
        btnSubmit = makeActionButton("✔  SUBMIT", new Color(200, 50, 60), WHITE);
        btnSubmit.setBounds(60, 550, 160, 26);
        btnSubmit.addActionListener(e -> submitSupplierForm(null));
        formCard.add(btnSubmit);

        btnClear = makeActionButton("↺  CLEAR", CREAM, CRIMSON_DARK);
        btnClear.setBackground(CREAM);
        btnClear.setForeground(CRIMSON_DARK);
        btnClear.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        btnClear.setBounds(340, 550, 160, 26);
        btnClear.addActionListener(e -> clearForm());
        formCard.add(btnClear);

        setContentPane(mainPanel);
    }

    // ---- Helpers ----
    private void addFormLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_HEADER);
        lbl.setForeground(CRIMSON_DARK);
        lbl.setBounds(x, y, 160, 25);
        panel.add(lbl);
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        tf.setBackground(INPUT_BG);
        tf.setFont(FONT_BODY);
        tf.setForeground(TEXT_DARK);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 140, 140), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        return tf;
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setBackground(INPUT_BG);
        combo.setFont(FONT_BODY);
        combo.setForeground(TEXT_DARK);
    }

    private JButton makeActionButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    public void displayRegistrationForm() {
        setVisible(true);
    }

    // + submitSupplierForm(supplierData : Object) : boolean
    public boolean submitSupplierForm(Object supplierData) {
        try {
            String id      = txtSupplierID.getText().trim();
            String name    = txtName.getText().trim();
            String type    = cbSupplierType.getSelectedItem().toString();
            String contact = txtContactNumber.getText().trim();
            String email   = txtEmail.getText().trim();
            String address = txtAddress.getText().trim().replace(",", "[COMMA]");
            String status  = cmbStatus.getSelectedItem().toString();

            // Validation
            if (id.isEmpty() || name.isEmpty() || contact.isEmpty() || email.isEmpty() || address.isEmpty()) {
                showErrorMessage("Please fill in all required fields.");
                return false;
            }
            if (id.length() < 3) {
                showErrorMessage("Supplier ID must be at least 3 characters.");
                return false;
            }
            if (!contact.matches("\\d{10,11}")) {
                showErrorMessage("Contact Number must be 10–11 digits (e.g. 0123456789).");
                txtContactNumber.requestFocus();
                return false;
            }
            if (name.matches(".*\\d.*")) {
                showErrorMessage("Supplier Name cannot contain numbers.");
                return false;
            }
            if (!email.matches("^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,6}$")) {
                showErrorMessage("Please enter a valid email address.");
                return false;
            }

            // NEW: Parsing the TOPSIS metrics safely + 0-10 Validation Shield
            double costScore = 0;
            double deliveryScore = 0;
            double qualityScore = 0;
            
            try {
                costScore = Double.parseDouble(txtCostScore.getText().trim());
                deliveryScore = Double.parseDouble(txtDeliveryScore.getText().trim());
                qualityScore = Double.parseDouble(txtQualityScore.getText().trim());
                
                // 🛡️ FRONTEND SHIELD: Check if numbers are between 0 and 10
                if (costScore < 0 || costScore > 10 || deliveryScore < 0 || deliveryScore > 10 || qualityScore < 0 || qualityScore > 10) {
                    showErrorMessage("All Performance Scores must be a number between 0 and 10.\n(e.g., 8.5 or 10)");
                    return false; 
                }
                
            } catch (NumberFormatException ex) {
                showErrorMessage("Performance Metrics (Cost, Delivery, Quality) must be valid numbers.");
                return false;
            }

            // Duplicate check
            controller.SupplierController sc = new controller.SupplierController();
            if (sc.searchSupplier(id) != null) {
                showErrorMessage("ID '" + id + "' is already registered. Please use a unique ID.");
                txtSupplierID.requestFocus();
                return false;
            }

            // Save using the newly updated controller method
            boolean success = sc.registerSupplier(id, name, contact, email, address, status, type, costScore, deliveryScore, qualityScore);
            
            if (success) {
                showSuccessMessage("Supplier registered successfully with TOPSIS metrics!");
                clearForm();
                return true;
            } else {
                showErrorMessage("Database error: could not save supplier.");
                return false;
            }
        } catch (Exception e) {
            showErrorMessage("An error occurred: " + e.getMessage());
            return false;
        }
    }

    public void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public void showErrorMessage() {
        JOptionPane.showMessageDialog(this, "An error occurred.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearForm() {
        txtSupplierID.setText("");
        txtName.setText("");
        txtContactNumber.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        txtCostScore.setText("");
        txtDeliveryScore.setText("");
        txtQualityScore.setText("");
        cbSupplierType.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        txtSupplierID.requestFocus();
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new RegisterSupplier().setVisible(true));
    }
}