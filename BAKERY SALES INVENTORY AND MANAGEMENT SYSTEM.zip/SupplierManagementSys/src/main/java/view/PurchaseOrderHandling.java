package view;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;

// ============================================================
// CLASS: PurchaseOrderHandling
// From Class Diagram: <<Boundary>>
// Fields: txtOrderTotal, lblTaxAmount, btnAutoSelectSupplier, cbPriority
// Methods: displayPurchaseOrderForm(), prepareOrder(),
//         clickAutoSelectSupplier(), clickSubmitOrder(),
//         showOrderConfirmation(), initiateCancelOrder()
// ============================================================
public class PurchaseOrderHandling extends JFrame {

    // %%%% Colour palette (Matching the new design system) %%%%
    private static final Color CRIMSON      = new Color(139,   0,  28);
    private static final Color CRIMSON_DARK = new Color(100,   0,  20);
    private static final Color CRIMSON_SOFT = new Color(180,  30,  55);
    private static final Color CREAM        = new Color(255, 248, 240);
    private static final Color WHITE        = Color.WHITE;
    private static final Color TEXT_DARK    = new Color( 30,  10,  10);
    private static final Color GOLD         = new Color(218, 165,  32);
    private static final Color INPUT_BG     = new Color(255, 248, 240);

    // %%%% Fonts %%%%
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    private static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Fields matching class diagram
    private JTextField txtOrderTotal;          
    private JLabel     lblTaxAmount;           
    private JButton    btnAutoSelectSupplier;  
    private JComboBox<String> cbPriority;      

    // Extra UI (Upgraded for Inventory Bridge!)
    private JTextField txtSupplierID;
    private JComboBox<product.DatabaseManager.Product> cbProduct; // Replaced txtItem
    private JTextField txtQuantity;                               // Added for restock math
    private JButton    btnSubmit;
    private JButton    btnClear;
    private JButton    btnBack;
    private JPanel     mainPanel;

    public PurchaseOrderHandling() {
        initComponents();
        setTitle("Purchase Order Handling");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(680, 680); 
        setLocationRelativeTo(null);
        setResizable(false);
        displayPurchaseOrderForm();
    }

    private void initComponents() {
        // ---- Main panel (crimson background) ----
        mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // ---- Header bar ----
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 680, 100);
        mainPanel.add(headerBar);

        // ---- BACK button ----
        btnBack = new JButton("< BACK");
        btnBack.setFont(FONT_BTN);
        btnBack.setBackground(new Color(180, 130, 130));
        btnBack.setForeground(WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(160, 100, 100), 1));
        btnBack.setBounds(10, 10, 85, 28);
        btnBack.addActionListener(e -> {
            new MainDashboard().setVisible(true);
            this.dispose();
        });
        headerBar.add(btnBack);

        // ---- Title ----
        JLabel lblTitle = new JLabel("CREATE PURCHASE ORDER", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(0, 35, 680, 38);
        headerBar.add(lblTitle);

        // ---- Gold divider ----
        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 100, 680, 3);
        mainPanel.add(goldBar);

        // ---- Form card (cream background) ----
        JPanel formCard = new JPanel(null);
        formCard.setBackground(CREAM);
        formCard.setBounds(30, 125, 600, 490);
        formCard.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(formCard);

        // ---- Section label inside card ----
        JLabel lblFormTitle = new JLabel("Order Details", SwingConstants.LEFT);
        lblFormTitle.setFont(FONT_HEADER);
        lblFormTitle.setForeground(CRIMSON_DARK);
        lblFormTitle.setBounds(20, 12, 300, 20);
        formCard.add(lblFormTitle);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(GOLD);
        cardSep.setBounds(20, 36, 560, 2);
        formCard.add(cardSep);

        // ---- Form layout ----
        int lx = 30, fx = 210, fw = 340, gy = 60, gap = 55;

        // Supplier ID
        addFormLabel(formCard, "Supplier ID :", lx, gy);
        txtSupplierID = makeTextField();
        txtSupplierID.setBounds(fx, gy - 3, fw, 30);
        formCard.add(txtSupplierID);

        // 🚀 THE BRIDGE: Item Details (Product Dropdown + Quantity)
        addFormLabel(formCard, "Select Product :", lx, gy + gap);
        
        // Fetch products from Nuriz's database!
        product.DatabaseManager.ProductDAO pDao = new product.DatabaseManager.ProductDAO();
        List<product.DatabaseManager.Product> productList = pDao.getAllProducts();
        
        cbProduct = new JComboBox<>(productList.toArray(new product.DatabaseManager.Product[0]));
        cbProduct.setFont(FONT_BODY);
        cbProduct.setBackground(WHITE);
        cbProduct.setBounds(fx, gy + gap - 3, 220, 30);
        formCard.add(cbProduct);

        // Quantity Field
        txtQuantity = makeTextField();
        txtQuantity.setBounds(fx + 230, gy + gap - 3, 110, 30);
        txtQuantity.setToolTipText("Qty");
        formCard.add(txtQuantity);
        
        JLabel lblQtyHint = new JLabel("Qty");
        lblQtyHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblQtyHint.setForeground(CRIMSON_DARK);
        lblQtyHint.setBounds(fx + 235, gy + gap - 18, 50, 15);
        formCard.add(lblQtyHint);

        // Tax Amount label
        lblTaxAmount = new JLabel("Tax Amount : RM 0.00");
        lblTaxAmount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTaxAmount.setForeground(CRIMSON);
        lblTaxAmount.setBounds(fx, gy + gap * 3 - 5, fw, 30);
        formCard.add(lblTaxAmount);

        // Total Amount
        addFormLabel(formCard, "Total Amount (RM) :", lx, gy + gap * 2);
        txtOrderTotal = makeTextField();
        txtOrderTotal.setBounds(fx, gy + gap * 2 - 3, fw, 30);
        
        // Instant tax calculation
        txtOrderTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override 
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c != '.' && c != java.awt.event.KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
                if (c == '.' && txtOrderTotal.getText().contains(".")) evt.consume();
            }

            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                try {
                    String input = txtOrderTotal.getText().trim();
                    if (!input.isEmpty()) {
                        double amount = Double.parseDouble(input);
                        double tax = amount * 0.06; // 6% Tax Calculation
                        lblTaxAmount.setText("Tax Amount : RM " + String.format("%.2f", tax));
                    } else {
                        lblTaxAmount.setText("Tax Amount : RM 0.00");
                    }
                } catch (NumberFormatException ex) {
                    lblTaxAmount.setText("Tax Amount : RM 0.00");
                }
            }
        });
        formCard.add(txtOrderTotal);

        JSeparator sep2 = new JSeparator();
        sep2.setForeground(GOLD);
        sep2.setBounds(20, 255, 560, 2);
        formCard.add(sep2);

        // ---- TOPSIS Dynamic Dropdown ----
        addFormLabel(formCard, "Auto-Select Priority:", 30, 268);
        String[] priorities = {
            "Balanced (Default)", 
            "Prioritize Quality", 
            "Prioritize Lowest Cost", 
            "Prioritize Fastest Delivery"
        };
        cbPriority = new JComboBox<>(priorities);
        cbPriority.setBounds(180, 265, 210, 30);
        cbPriority.setFont(FONT_BODY);
        cbPriority.setBackground(WHITE);
        formCard.add(cbPriority);

        // ---- Action buttons ----
        btnAutoSelectSupplier = makeActionButton("★ AUTO-SELECT BEST", GOLD, CRIMSON_DARK);
        btnAutoSelectSupplier.setBounds(30, 310, 230, 45);
        btnAutoSelectSupplier.addActionListener(e -> clickAutoSelectSupplier());
        formCard.add(btnAutoSelectSupplier);

        btnSubmit = makeActionButton("✔ SUBMIT ORDER", new Color(200, 50, 60), WHITE);
        btnSubmit.setBounds(280, 310, 160, 45);
        btnSubmit.addActionListener(e -> clickSubmitOrder());
        formCard.add(btnSubmit);

        btnClear = makeActionButton("↺ CLEAR", CREAM, CRIMSON_DARK);
        btnClear.setBounds(460, 310, 110, 45);
        btnClear.addActionListener(e -> clearForm());
        formCard.add(btnClear);

        JSeparator sep3 = new JSeparator();
        sep3.setForeground(GOLD);
        sep3.setBounds(20, 375, 560, 2);
        formCard.add(sep3);

        // ---- Cancel Order section ----
        JLabel lblCancel = new JLabel("Cancel an Existing Order:", SwingConstants.LEFT);
        lblCancel.setFont(FONT_HEADER);
        lblCancel.setForeground(CRIMSON_DARK);
        lblCancel.setBounds(30, 385, 280, 25);
        formCard.add(lblCancel);

        JTextField txtCancelPO = makeTextField();
        txtCancelPO.setBounds(30, 415, 230, 30);
        txtCancelPO.setToolTipText("Enter PO Number to cancel");
        formCard.add(txtCancelPO);

        JLabel lblCancelHint = new JLabel("PO Number");
        lblCancelHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblCancelHint.setForeground(CRIMSON_DARK);
        lblCancelHint.setBounds(30, 450, 200, 18);
        formCard.add(lblCancelHint);

        JButton btnCancel = makeActionButton("✕ CANCEL ORDER", new Color(180, 50, 50), WHITE);
        btnCancel.setBounds(280, 415, 160, 30);
        btnCancel.addActionListener(e -> initiateCancelOrder(txtCancelPO.getText().trim()));
        formCard.add(btnCancel);

        setContentPane(mainPanel);
    }

    // ---------- Helpers ----------
    private void addFormLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_HEADER);
        lbl.setForeground(CRIMSON_DARK);
        lbl.setBounds(x, y, 160, 25);
        panel.add(lbl);
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        tf.setBackground(INPUT_BG);
        tf.setFont(FONT_BODY);
        tf.setForeground(TEXT_DARK);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 140, 140), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        return tf;
    }

    private JButton makeActionButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(GOLD, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ---------- Class diagram methods ----------

    public void displayPurchaseOrderForm() {
        setVisible(true);
    }

    public void prepareOrder(String supplierID, java.util.List<model.OrderItem> itemList) {
        txtSupplierID.setText(supplierID);
    }

    public void clickAutoSelectSupplier() {
        String userChoice = cbPriority.getSelectedItem().toString();
        double wC = 0.33, wD = 0.33, wQ = 0.34; 

        if (userChoice.equals("Prioritize Quality")) {
            wC = 0.1; wD = 0.1; wQ = 0.8;
        } else if (userChoice.equals("Prioritize Lowest Cost")) {
            wC = 0.8; wD = 0.1; wQ = 0.1;
        } else if (userChoice.equals("Prioritize Fastest Delivery")) {
            wC = 0.1; wD = 0.8; wQ = 0.1;
        }

        controller.SupplierController sc = new controller.SupplierController();
        model.Supplier best = sc.recommendBestSupplier(wC, wD, wQ);
        
        if (best != null) {
            txtSupplierID.setText(best.getSupplierID());

            String totalText = txtOrderTotal.getText().trim();
            if (!totalText.isEmpty()) {
                try {
                    double amount = Double.parseDouble(totalText);
                    if (best instanceof model.Taxable) {
                        double tax = ((model.Taxable) best).calculateTax(amount);
                        lblTaxAmount.setText(String.format("Tax Amount : RM %.2f (%s)", tax, best.getSupplierType()));
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Enter a valid numeric amount first.");
                    return;
                }
            }
            
            String specialDetails = "TOPSIS Evaluation Complete!\n\n"
                                  + "Winner: " + best.getSupplierName() + " (" + best.getSupplierType() + ")\n"
                                  + "ID: " + best.getSupplierID() + "\n\n"
                                  + "--- Evaluation Mode ---\n"
                                  + "Selected: " + userChoice + "\n\n"
                                  + "--- Winner's Performance Metrics ---\n"
                                  + "Cost Score: " + best.getCostMetric() + " / 10\n"
                                  + "Delivery Score: " + best.getDeliveryMetric() + " / 10\n"
                                  + "Quality Score: " + best.getQualityMetric() + " / 10";

            JOptionPane.showMessageDialog(this, specialDetails, "Best Supplier Details", JOptionPane.INFORMATION_MESSAGE);
            
        } else {
            JOptionPane.showMessageDialog(this, "No active suppliers found in the database.", "Auto-Select", JOptionPane.WARNING_MESSAGE);
        }
    }

    // 🚀 THE FINAL BRIDGE: clickSubmitOrder()
    public boolean clickSubmitOrder() {
        String supplierID = txtSupplierID.getText().trim();
        String qtyText    = txtQuantity.getText().trim();
        String amountText = txtOrderTotal.getText().trim();
        product.DatabaseManager.Product selectedProduct = (product.DatabaseManager.Product) cbProduct.getSelectedItem();

        if (supplierID.isEmpty() || qtyText.isEmpty() || amountText.isEmpty() || selectedProduct == null) {
            JOptionPane.showMessageDialog(this,
                "Please fill in all fields (including Quantity) before submitting.",
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        try {
            double amount = Double.parseDouble(amountText);
            int qty = Integer.parseInt(qtyText);
            
            // Format the item details so it saves nicely in your PurchaseOrder database
            String itemDetails = selectedProduct.getName() + " (Qty: " + qty + ")";

            controller.OrderController oc = new controller.OrderController();
            boolean ok = oc.createPurchaseOrder(supplierID, itemDetails, amount);
            
            if (ok) {
                // 💥 THE INVENTORY RESTOCK MAGIC 💥
                // Instantly update Nuriz's table with the new quantity!
                product.DatabaseManager.ProductDAO pDao = new product.DatabaseManager.ProductDAO();
                pDao.updateStock(selectedProduct.getProductID(), qty);

                String poNum = "PO-" + System.currentTimeMillis() % 100000;
                showOrderConfirmation(poNum);
                clearForm();
                return true;
            } else {
                JOptionPane.showMessageDialog(this,
                    "Error: Could not save the purchase order.",
                    "Database Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Total Amount and Quantity must be valid numbers.");
            return false;
        }
    }

    public void showOrderConfirmation(String generatedPONumber) {
        JOptionPane.showMessageDialog(this,
            "Purchase Order created successfully!\nPO Number: " + generatedPONumber + "\n\nInventory has been automatically restocked!",
            "Order Confirmed", JOptionPane.INFORMATION_MESSAGE);
    }

    public void initiateCancelOrder(String poNumber) {
        if (poNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter a PO Number to cancel.");
            return;
        }
        String reason = JOptionPane.showInputDialog(this,
            "Enter reason for cancelling " + poNumber + ":");
        if (reason == null) return;

        controller.OrderController oc = new controller.OrderController();
        boolean ok = oc.requestCancelOrder(poNumber, reason);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Order " + poNumber + " has been cancelled.");
        } else {
            JOptionPane.showMessageDialog(this,
                "Could not cancel order. Check PO Number.");
        }
    }

    private void clearForm() {
        txtSupplierID.setText("");
        if(cbProduct.getItemCount() > 0) cbProduct.setSelectedIndex(0);
        txtQuantity.setText("");
        txtOrderTotal.setText("");
        lblTaxAmount.setText("Tax Amount : RM 0.00");
        cbPriority.setSelectedIndex(0); 
        txtSupplierID.requestFocus();
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) { /* use default */ }
        java.awt.EventQueue.invokeLater(() -> new PurchaseOrderHandling().setVisible(true));
    }
}