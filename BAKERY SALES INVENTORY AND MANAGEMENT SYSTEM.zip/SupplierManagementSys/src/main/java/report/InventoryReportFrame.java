package report;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class InventoryReportFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color GOLD           = new Color(218, 165,  32);
    static final Color TABLE_ROW_A    = new Color(255, 245, 245);
    static final Color TABLE_ROW_B    = new Color(255, 255, 255);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Swing elements that require dynamic updates
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel summaryLabel;
    private JTextField searchField;

    public InventoryReportFrame() {
        setTitle("Inventory Report");
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // ---- Main Panel ----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // ---- Custom Header ----
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(CRIMSON_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblHeader = new JLabel("📦 INVENTORY REPORT", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(WHITE);
        headerPanel.add(lblHeader, BorderLayout.CENTER);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setPreferredSize(new Dimension(800, 3));
        headerPanel.add(goldBar, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ---- Center Container ----
        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setBackground(CREAM);
        centerContainer.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // ---- Filter/Search Bar ----
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterPanel.setBackground(CREAM);

        JLabel searchLabel = new JLabel("Search Product:");
        searchLabel.setFont(FONT_BODY);
        searchLabel.setForeground(TEXT_DARK);
        
        searchField = new JTextField(20);
        searchField.setFont(FONT_BODY);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        JButton searchBtn = createPrimaryButton("SEARCH");

        filterPanel.add(searchLabel);
        filterPanel.add(searchField);
        filterPanel.add(searchBtn);

        // ---- Dynamic Data Table ----
        String[] columns = {"Product", "Stock (Qty)", "Unit Price", "Total Value", "Status"};
        tableModel = new DefaultTableModel(columns, 0); 
        table = new JTable(tableModel);
        
        table.setFont(FONT_BODY);
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(CRIMSON_DARK);
        table.getTableHeader().setForeground(WHITE);
        table.setEnabled(false);

        // Custom Table Renderer for alternating rows and "LOW" stock highlighting
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                
                if (r < t.getRowCount() && t.getValueAt(r, 4) != null) {
                    String status = (String) t.getValueAt(r, 4);
                    if ("LOW".equals(status)) {
                        comp.setBackground(new Color(255, 210, 210)); 
                        comp.setForeground(CRIMSON);
                        setFont(new Font("Segoe UI", Font.BOLD, 13));
                    } else {
                        comp.setBackground(r % 2 == 0 ? TABLE_ROW_A : TABLE_ROW_B);
                        comp.setForeground(TEXT_DARK);
                        setFont(FONT_BODY);
                    }
                }
                return comp;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(GOLD, 2));

        // ---- Dynamic Summary Label ----
        summaryLabel = new JLabel("TOTAL VALUE: RM 0.00     |     LOW STOCK ITEMS: 0", SwingConstants.CENTER);
        summaryLabel.setFont(FONT_HEADER);
        summaryLabel.setForeground(CRIMSON_DARK);
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));

        centerContainer.add(filterPanel, BorderLayout.NORTH);
        centerContainer.add(scrollPane, BorderLayout.CENTER);
        centerContainer.add(summaryLabel, BorderLayout.SOUTH);
        mainPanel.add(centerContainer, BorderLayout.CENTER);

        // ---- Bottom Panel (Buttons) ----
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(CREAM);

        JButton exportBtn = createExportButton("⬇ EXPORT REPORT");
        JButton backBtn = createSecondaryButton("< BACK");

        exportBtn.addActionListener(e -> new ExportDialog(this).setVisible(true));
        backBtn.addActionListener(e -> dispose());

        bottomPanel.add(exportBtn);
        bottomPanel.add(backBtn);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        searchBtn.addActionListener(e -> loadInventoryData());
        loadInventoryData();
    }

    // =================================================================
    // 🚀 FIXED: Now reads from Nuriz's Single Source of Truth
    // =================================================================
    private void loadInventoryData() {
        tableModel.setRowCount(0); 
        String searchText = searchField.getText().trim();
        
        // The Magic Query: Joins Product & StockThreshold, and aliases columns to match Siti's code perfectly!
        String sql = "SELECT " +
                     "  p.name AS product_name, " +
                     "  p.quantity AS stock_qty, " +
                     "  p.price AS unit_price, " +
                     "  (p.quantity * p.price) AS total_val, " +
                     "  IF(p.quantity <= IFNULL(t.threshold, 10), 'LOW', 'OK') AS status " +
                     "FROM Product p " +
                     "LEFT JOIN StockThreshold t ON p.productID = t.productID " +
                     "WHERE p.name LIKE ?";
        
        double totalValueSum = 0.0;
        int lowStockCount = 0;

        // Note: Make sure Siti's DBConnection points to bakery_db!
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, "%" + searchText + "%");
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String product = rs.getString("product_name");
                    int qty = rs.getInt("stock_qty");
                    double unitPrice = rs.getDouble("unit_price");
                    double totalValue = rs.getDouble("total_val");
                    String status = rs.getString("status");

                    if ("LOW".equals(status)) {
                        lowStockCount++;
                    }
                    totalValueSum += totalValue;

                    tableModel.addRow(new Object[]{
                        product,
                        qty,
                        String.format("RM %.2f", unitPrice),
                        String.format("RM %.2f", totalValue),
                        status
                    });
                }
            }

            summaryLabel.setText(String.format("TOTAL VALUE: RM %.2f     |     LOW STOCK ITEMS: %d", totalValueSum, lowStockCount));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "SQL Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(6, 15, 6, 15));
        return btn;
    }

    private JButton createExportButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(GOLD);
        btn.setForeground(TEXT_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 35));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CRIMSON_DARK, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        return btn;
    }

    private JButton createSecondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(new Color(200, 180, 180));
        btn.setForeground(CRIMSON_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 35));
        btn.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        return btn;
    }
}