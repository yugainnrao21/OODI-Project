package report;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ExportDialog extends JDialog {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color GOLD           = new Color(218, 165,  32);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    public ExportDialog(JFrame parent) {
        super(parent, "Export Report", true);
        setSize(400, 280);
        setLocationRelativeTo(parent);
        setResizable(false);

        // ---- Main Panel (Cream Background) ----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // ---- Custom Header ----
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(CRIMSON_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblHeader = new JLabel("⬇ EXPORT REPORT", SwingConstants.CENTER);
        lblHeader.setFont(FONT_HEADER);
        lblHeader.setForeground(WHITE);
        headerPanel.add(lblHeader, BorderLayout.CENTER);

        // Gold divider under header
        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setPreferredSize(new Dimension(400, 3));
        headerPanel.add(goldBar, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ---- Form Panel ----
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        formPanel.setBackground(CREAM);
        formPanel.setBorder(BorderFactory.createEmptyBorder(25, 40, 15, 40));

        JLabel formatLabel = new JLabel("Select Format:");
        formatLabel.setFont(FONT_BODY);
        formatLabel.setForeground(TEXT_DARK);
        
        JComboBox<String> formatBox = new JComboBox<>(new String[]{"PDF", "CSV"});
        formatBox.setFont(FONT_BODY);
        formatBox.setBackground(WHITE);

        JLabel fileLabel = new JLabel("File Name:");
        fileLabel.setFont(FONT_BODY);
        fileLabel.setForeground(TEXT_DARK);
        
        JTextField fileField = new JTextField("report_export");
        fileField.setFont(FONT_BODY);
        fileField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        formPanel.add(formatLabel); 
        formPanel.add(formatBox);
        formPanel.add(fileLabel);   
        formPanel.add(fileField);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // ---- Bottom Panel (Buttons) ----
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(CREAM);

        JButton exportBtn = createPrimaryButton("EXPORT");
        JButton cancelBtn = createSecondaryButton("CANCEL");

        exportBtn.addActionListener(e -> {
            String format = (String) formatBox.getSelectedItem();
            String fileName = fileField.getText().trim();
            if (fileName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a file name.", "Input Error", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Exported as " + fileName + "." + format.toLowerCase() + " successfully!", "Export Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        cancelBtn.addActionListener(e -> dispose());

        bottomPanel.add(exportBtn);
        bottomPanel.add(cancelBtn);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    // Helper: Style for the main Action Button
    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 35));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    // Helper: Style for the Cancel Button
    private JButton createSecondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(new Color(200, 180, 180));
        btn.setForeground(CRIMSON_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 35));
        btn.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        return btn;
    }

    public static void main(String[] args) {
        // Quick tester to preview the dialog
        SwingUtilities.invokeLater(() -> new ExportDialog(null).setVisible(true));
    }
}