package report;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class SalesReportFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color GOLD           = new Color(218, 165,  32);
    static final Color TABLE_ROW_A    = new Color(255, 245, 245);
    static final Color TABLE_ROW_B    = new Color(255, 255, 255);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // GUI Components
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel summaryLabel;
    private JTextField fromField, toField;
    
    // New Input Fields for GUI Data Entry
    private JTextField inputDateField, inputProductField, inputQtyField, inputPriceField;

    public SalesReportFrame() {
        setTitle("Sales Report & Entry");
        setSize(850, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // ---- Main Panel ----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // ---- Custom Header ----
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(CRIMSON_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblHeader = new JLabel("💰 SALES MANAGEMENT & REPORT", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(WHITE);
        headerPanel.add(lblHeader, BorderLayout.CENTER);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setPreferredSize(new Dimension(850, 3));
        headerPanel.add(goldBar, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ---- Center Container ----
        JPanel centerContainer = new JPanel();
        centerContainer.setLayout(new BoxLayout(centerContainer, BoxLayout.Y_AXIS));
        centerContainer.setBackground(CREAM);
        centerContainer.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // =================================================================
        // SECTION 1: GUI INPUT FORM
        // =================================================================
        JPanel inputFormPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        inputFormPanel.setBackground(CREAM);
        inputFormPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(CRIMSON, 1), 
                "Add New Sale Entry (Key-in here)", 
                TitledBorder.LEFT, TitledBorder.TOP, FONT_BTN, CRIMSON));

        inputDateField = new JTextField("2026-06-17", 8);
        inputProductField = new JTextField(12);
        inputQtyField = new JTextField(4);
        inputPriceField = new JTextField(6);

        JButton btnAddSale = createPrimaryButton("➕ ADD TO DATABASE");

        inputFormPanel.add(new JLabel("Date:"));    inputFormPanel.add(inputDateField);
        inputFormPanel.add(new JLabel("Product:")); inputFormPanel.add(inputProductField);
        inputFormPanel.add(new JLabel("Qty:"));     inputFormPanel.add(inputQtyField);
        inputFormPanel.add(new JLabel("Price (RM):")); inputFormPanel.add(inputPriceField);
        inputFormPanel.add(btnAddSale);

        centerContainer.add(inputFormPanel);
        centerContainer.add(Box.createRigidArea(new Dimension(0, 15)));

        // =================================================================
        // SECTION 2: FILTER BAR
        // =================================================================
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterPanel.setBackground(CREAM);

        JLabel fromLabel = new JLabel("From Date:");
        fromField = new JTextField("2026-01-01", 10);
        JLabel toLabel = new JLabel("To Date:");
        toField = new JTextField("2026-12-31", 10);
        JButton filterBtn = createPrimaryButton("🔍 APPLY FILTER");

        filterPanel.add(fromLabel);  filterPanel.add(fromField);
        filterPanel.add(toLabel);    filterPanel.add(toField);
        filterPanel.add(filterBtn);
        
        centerContainer.add(filterPanel);

        // =================================================================
        // SECTION 3: DATA TABLE
        // =================================================================
        String[] columns = {"Date", "Product", "Qty Sold", "Unit Price", "Total"};
        tableModel = new DefaultTableModel(columns, 0); 
        table = new JTable(tableModel);
        table.setFont(FONT_BODY);
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(CRIMSON_DARK);
        table.getTableHeader().setForeground(WHITE);
        table.setEnabled(false);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                comp.setBackground(r % 2 == 0 ? TABLE_ROW_A : TABLE_ROW_B);
                comp.setForeground(TEXT_DARK);
                return comp;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        centerContainer.add(scrollPane);

        // ---- Summary Label ----
        summaryLabel = new JLabel("TOTAL SALES: RM 0.00     |     TOTAL ORDERS: 0", SwingConstants.CENTER);
        summaryLabel.setFont(FONT_HEADER);
        summaryLabel.setForeground(CRIMSON_DARK);
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));
        centerContainer.add(summaryLabel);

        mainPanel.add(centerContainer, BorderLayout.CENTER);

        // ---- Bottom Panel (Buttons) ----
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(CREAM);

        JButton exportBtn = createExportButton("⬇ EXPORT REPORT");
        JButton backBtn = createSecondaryButton("< BACK");

        exportBtn.addActionListener(e -> new ExportDialog(this).setVisible(true));
        backBtn.addActionListener(e -> dispose());

        bottomPanel.add(exportBtn);
        bottomPanel.add(backBtn);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // ---- Action Listeners ----
        filterBtn.addActionListener(e -> loadSalesData());
        btnAddSale.addActionListener(e -> insertSaleToDatabase());

        // Load dynamic data on startup
        loadSalesData();
    }

    private void insertSaleToDatabase() {
        String date = inputDateField.getText().trim();
        String product = inputProductField.getText().trim();
        String qtyStr = inputQtyField.getText().trim();
        String priceStr = inputPriceField.getText().trim();

        if (date.isEmpty() || product.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill up all inputs before adding!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "INSERT INTO sales (sale_date, product_name, quantity, unit_price) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, date);
            ps.setString(2, product);
            ps.setInt(3, Integer.parseInt(qtyStr));
            ps.setDouble(4, Double.parseDouble(priceStr));

            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Successfully saved to SQL!", "Success", JOptionPane.INFORMATION_MESSAGE);
                inputProductField.setText("");
                inputQtyField.setText("");
                inputPriceField.setText("");
                loadSalesData();
            }
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Quantity must be an Integer and Price must be a Decimal value!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Insertion Error: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadSalesData() {
        tableModel.setRowCount(0); 
        String sql = "SELECT sale_date, product_name, quantity, unit_price, total_price " +
                     "FROM sales WHERE sale_date BETWEEN ? AND ?";
        double totalSales = 0.0;
        int totalOrders = 0;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, fromField.getText().trim());
            ps.setString(2, toField.getText().trim());
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String date = rs.getString("sale_date");
                    String product = rs.getString("product_name");
                    int qty = rs.getInt("quantity");
                    double unitPrice = rs.getDouble("unit_price");
                    double total = rs.getDouble("total_price");

                    totalSales += total;
                    totalOrders += qty;

                    tableModel.addRow(new Object[]{ date, product, qty, 
                        String.format("RM %.2f", unitPrice), 
                        String.format("RM %.2f", total)
                    });
                }
            }
            summaryLabel.setText(String.format("TOTAL SALES: RM %.2f     |     TOTAL ITEMS SOLD: %d", totalSales, totalOrders));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error Fetching Data: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 1),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        return btn;
    }

    private JButton createExportButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(GOLD);
        btn.setForeground(TEXT_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 35));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CRIMSON_DARK, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        return btn;
    }

    private JButton createSecondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(new Color(200, 180, 180));
        btn.setForeground(CRIMSON_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 35));
        btn.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SalesReportFrame().setVisible(true));
    }
}