package report;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ScheduleReportFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color GOLD           = new Color(218, 165,  32);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    public ScheduleReportFrame() {
        setTitle("Schedule Report");
        setSize(600, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // ---- Main Panel ----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // ---- Custom Header ----
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(CRIMSON_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblHeader = new JLabel("⏰ SCHEDULE REPORT", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(WHITE);
        headerPanel.add(lblHeader, BorderLayout.CENTER);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setPreferredSize(new Dimension(600, 3));
        headerPanel.add(goldBar, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ---- Form Panel ----
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 15, 20));
        formPanel.setBackground(CREAM);
        formPanel.setBorder(BorderFactory.createEmptyBorder(35, 60, 25, 60));

        // 1. Report Type
        JLabel typeLabel = new JLabel("Report Type:");
        typeLabel.setFont(FONT_BODY);
        typeLabel.setForeground(TEXT_DARK);
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Sales Report", "Inventory Report", "Supplier Report"});
        styleComboBox(typeBox);

        // 2. Frequency
        JLabel freqLabel = new JLabel("Frequency:");
        freqLabel.setFont(FONT_BODY);
        freqLabel.setForeground(TEXT_DARK);
        JComboBox<String> freqBox = new JComboBox<>(new String[]{"Daily", "Weekly", "Monthly"});
        styleComboBox(freqBox);

        // 3. Date Range
        JLabel rangeLabel = new JLabel("Date Range:");
        rangeLabel.setFont(FONT_BODY);
        rangeLabel.setForeground(TEXT_DARK);
        JComboBox<String> rangeBox = new JComboBox<>(new String[]{"Today", "This Week", "This Month", "This Year"});
        styleComboBox(rangeBox);

        // 4. Export Format
        JLabel formatLabel = new JLabel("Export Format:");
        formatLabel.setFont(FONT_BODY);
        formatLabel.setForeground(TEXT_DARK);
        JComboBox<String> formatBox = new JComboBox<>(new String[]{"PDF", "CSV"});
        styleComboBox(formatBox);

        // 5. Recipient Email
        JLabel emailLabel = new JLabel("Recipient Email:");
        emailLabel.setFont(FONT_BODY);
        emailLabel.setForeground(TEXT_DARK);
        JTextField emailField = new JTextField("admin@bakery.com");
        emailField.setFont(FONT_BODY);
        emailField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));

        // Add to form
        formPanel.add(typeLabel);   formPanel.add(typeBox);
        formPanel.add(freqLabel);   formPanel.add(freqBox);
        formPanel.add(rangeLabel);  formPanel.add(rangeBox);
        formPanel.add(formatLabel); formPanel.add(formatBox);
        formPanel.add(emailLabel);  formPanel.add(emailField);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // ---- Bottom Panel (Buttons) ----
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(CREAM);

        JButton saveBtn = createPrimaryButton("SAVE SCHEDULE");
        JButton backBtn = createSecondaryButton("< BACK");

        saveBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            if (email.isEmpty() || !email.contains("@")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Invalid Email", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Schedule saved!\nReport will be automatically sent to: " + email, "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        backBtn.addActionListener(e -> dispose());

        bottomPanel.add(saveBtn);
        bottomPanel.add(backBtn);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    // Helper: Style Combo Boxes
    private void styleComboBox(JComboBox<String> box) {
        box.setFont(FONT_BODY);
        box.setBackground(WHITE);
    }

    // Helper: Style for Primary Button
    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(160, 40));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    // Helper: Style for Secondary/Back Button
    private JButton createSecondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(new Color(200, 180, 180));
        btn.setForeground(CRIMSON_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 40));
        btn.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ScheduleReportFrame().setVisible(true));
    }
}