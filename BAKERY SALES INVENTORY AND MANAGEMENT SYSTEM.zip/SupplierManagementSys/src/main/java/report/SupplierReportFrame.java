package report;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class SupplierReportFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color GOLD           = new Color(218, 165,  32);
    static final Color TABLE_ROW_A    = new Color(255, 245, 245);
    static final Color TABLE_ROW_B    = new Color(255, 255, 255);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Swing elements that require dynamic updates
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel summaryLabel;
    private JTextField searchField;
    
    // New Input Fields for GUI Entry
    private JTextField inputSupplierField, inputContactField, inputPhoneField, inputProductField;

    public SupplierReportFrame() {
        setTitle("Supplier Management & Report");
        setSize(850, 700); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // ---- Main Panel ----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // ---- Custom Header ----
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(CRIMSON_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblHeader = new JLabel("🚚 SUPPLIER MANAGEMENT & REPORT", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(WHITE);
        headerPanel.add(lblHeader, BorderLayout.CENTER);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setPreferredSize(new Dimension(850, 3));
        headerPanel.add(goldBar, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ---- Center Container ----
        JPanel centerContainer = new JPanel();
        centerContainer.setLayout(new BoxLayout(centerContainer, BoxLayout.Y_AXIS));
        centerContainer.setBackground(CREAM);
        centerContainer.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // =================================================================
        // SECTION 1: GUI INPUT FORM (To Insert Data into SQL)
        // =================================================================
        JPanel inputFormPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        inputFormPanel.setBackground(CREAM);
        inputFormPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(CRIMSON, 1), 
                "Add New Supplier (Key-in here)", 
                TitledBorder.LEFT, TitledBorder.TOP, FONT_BTN, CRIMSON));

        inputSupplierField = new JTextField(12);
        inputContactField = new JTextField(10);
        inputPhoneField = new JTextField(9);
        inputProductField = new JTextField(12);
        
        JButton btnAddSupplier = createPrimaryButton("➕ ADD TO DATABASE");

        inputFormPanel.add(new JLabel("Supplier:")); inputFormPanel.add(inputSupplierField);
        inputFormPanel.add(new JLabel("Contact:"));  inputFormPanel.add(inputContactField);
        inputFormPanel.add(new JLabel("Phone:"));    inputFormPanel.add(inputPhoneField);
        inputFormPanel.add(new JLabel("Product:"));  inputFormPanel.add(inputProductField);
        inputFormPanel.add(btnAddSupplier);

        centerContainer.add(inputFormPanel);
        centerContainer.add(Box.createRigidArea(new Dimension(0, 15)));

        // =================================================================
        // SECTION 2: SEARCH BAR
        // =================================================================
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterPanel.setBackground(CREAM);

        JLabel searchLabel = new JLabel("Search Supplier/Product:");
        searchLabel.setFont(FONT_BODY);
        searchLabel.setForeground(TEXT_DARK);
        
        searchField = new JTextField(20);
        searchField.setFont(FONT_BODY);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        JButton searchBtn = createPrimaryButton("🔍 SEARCH");

        filterPanel.add(searchLabel);
        filterPanel.add(searchField);
        filterPanel.add(searchBtn);

        centerContainer.add(filterPanel);

        // =================================================================
        // SECTION 3: DATA TABLE (View Live SQL Data)
        // =================================================================
        String[] columns = {"Supplier Name", "Contact Person", "Phone Number", "Product Supplied"};
        tableModel = new DefaultTableModel(columns, 0); 
        table = new JTable(tableModel);
        
        table.setFont(FONT_BODY);
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(CRIMSON_DARK);
        table.getTableHeader().setForeground(WHITE);
        table.setEnabled(false);

        // Custom Table Renderer for alternating rows
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                comp.setBackground(r % 2 == 0 ? TABLE_ROW_A : TABLE_ROW_B);
                comp.setForeground(TEXT_DARK);
                return comp;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        centerContainer.add(scrollPane);

        // ---- Dynamic Summary Label ----
        summaryLabel = new JLabel("TOTAL ACTIVE SUPPLIERS: 0", SwingConstants.CENTER);
        summaryLabel.setFont(FONT_HEADER);
        summaryLabel.setForeground(CRIMSON_DARK);
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));
        centerContainer.add(summaryLabel);
        
        mainPanel.add(centerContainer, BorderLayout.CENTER);

        // ---- Bottom Panel (Buttons) ----
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(CREAM);

        JButton exportBtn = createExportButton("⬇ EXPORT REPORT");
        JButton backBtn = createSecondaryButton("< BACK");

        exportBtn.addActionListener(e -> new ExportDialog(this).setVisible(true));
        backBtn.addActionListener(e -> dispose());

        bottomPanel.add(exportBtn);
        bottomPanel.add(backBtn);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // ---- Action Listeners ----
        searchBtn.addActionListener(e -> loadSupplierData());
        btnAddSupplier.addActionListener(e -> insertSupplierToDatabase());

        // Fetch data initially on window launch
        loadSupplierData();
    }

    private void insertSupplierToDatabase() {
        String name = inputSupplierField.getText().trim();
        String contact = inputContactField.getText().trim();
        String phone = inputPhoneField.getText().trim();
        String product = inputProductField.getText().trim();
        
        if (name.isEmpty() || contact.isEmpty() || phone.isEmpty() || product.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill up all input fields before adding!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "INSERT INTO suppliers (supplier_name, contact_person, phone_number, product_supplied) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, name);
            ps.setString(2, contact);
            ps.setString(3, phone);
            ps.setString(4, product);
            
            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Successfully saved supplier to SQL!", "Success", JOptionPane.INFORMATION_MESSAGE);
                inputSupplierField.setText("");
                inputContactField.setText("");
                inputPhoneField.setText("");
                inputProductField.setText("");
                loadSupplierData();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Insertion Error: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadSupplierData() {
        tableModel.setRowCount(0);
        
        String searchText = searchField.getText().trim();
        String sql = "SELECT supplier_name, contact_person, phone_number, product_supplied " +
                     "FROM suppliers WHERE supplier_name LIKE ? OR product_supplied LIKE ?";
        
        int totalSuppliers = 0;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            String queryWildcard = "%" + searchText + "%";
            ps.setString(1, queryWildcard);
            ps.setString(2, queryWildcard);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String name = rs.getString("supplier_name");
                    String contact = rs.getString("contact_person");
                    String phone = rs.getString("phone_number");
                    String product = rs.getString("product_supplied");
                    totalSuppliers++;
                    tableModel.addRow(new Object[]{name, contact, phone, product});
                }
            }
            summaryLabel.setText("TOTAL ACTIVE SUPPLIERS: " + totalSuppliers);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error Fetching Data: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 1),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        return btn;
    }

    private JButton createExportButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(GOLD);
        btn.setForeground(TEXT_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 35));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CRIMSON_DARK, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        return btn;
    }

    private JButton createSecondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(new Color(200, 180, 180));
        btn.setForeground(CRIMSON_DARK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 35));
        btn.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SupplierReportFrame().setVisible(true));
    }
}