package report;

import view.MainDashboard;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class DashboardFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_DARK      = new Color( 30,  10,  10);
    static final Color TEXT_LIGHT     = new Color(220, 200, 200);
    static final Color GOLD           = new Color(218, 165,  32);

    // %%%% Shared Fonts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    static final Font FONT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    public DashboardFrame() {
        initComponents();
        setTitle("Dashboard Overview");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 620); // Matched to your MainDashboard size
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void initComponents() {
        // ---- Main panel (crimson background) ----
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // ---- Header bar ----
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 110);
        mainPanel.add(headerBar);

        // ---- Title inside header ----
        JLabel lblTitle = new JLabel("📊 DASHBOARD OVERVIEW", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(30, 18, 640, 38);
        headerBar.add(lblTitle);

        // ---- Gold divider ----
        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 108, 700, 3);
        mainPanel.add(goldBar);

        // ---- Subtitle ----
        JLabel lblSubtitle = new JLabel("Live System Metrics & Performance", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubtitle.setForeground(TEXT_LIGHT);
        lblSubtitle.setBounds(30, 70, 640, 22);
        headerBar.add(lblSubtitle);

        // ---- Card area (cream background) ----
        JPanel cardArea = new JPanel(null);
        cardArea.setBackground(CREAM);
        cardArea.setBounds(50, 140, 600, 360);
        cardArea.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(cardArea);

        // ---- Grid Panel for the 4 Data Cards ----
        JPanel gridPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        gridPanel.setBackground(CREAM);
        gridPanel.setBounds(30, 30, 540, 240); // Centered inside the cream area
        
        gridPanel.add(createDataCard("TODAY'S SALES", "RM 1,250.00"));
        gridPanel.add(createDataCard("LOW STOCK ITEMS", "4 Items"));
        gridPanel.add(createDataCard("PENDING ORDERS", "7 Orders"));
        gridPanel.add(createDataCard("TOP PRODUCT", "Choc Cake"));
        
        cardArea.add(gridPanel);

        // ---- REFRESH BUTTON ----
        JButton btnRefresh = createMenuButton("⟳  REFRESH DATA");
        btnRefresh.setBounds(100, 290, 400, 45);
        btnRefresh.addActionListener(e -> JOptionPane.showMessageDialog(this, "Dashboard refreshed!"));
        cardArea.add(btnRefresh);

        // ---- BACK BUTTON ----
        JButton btnBack = new JButton("< BACK");
        btnBack.setFont(FONT_BTN);
        btnBack.setBackground(new Color(200, 180, 180));
        btnBack.setForeground(CRIMSON_DARK);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        btnBack.setBounds(250, 515, 200, 38);
        btnBack.addActionListener(e -> {
            // Closes this window and returns to the previous one
            this.dispose(); 
        });
        mainPanel.add(btnBack);

        // ---- Footer strip ----
        JPanel footer = new JPanel(null);
        footer.setBackground(CRIMSON_DARK);
        footer.setBounds(0, 555, 700, 25);
        JLabel lblFooter = new JLabel("© Supplier Management System", SwingConstants.CENTER);
        lblFooter.setFont(FONT_SMALL);
        lblFooter.setForeground(TEXT_LIGHT);
        lblFooter.setBounds(0, 4, 700, 16);
        footer.add(lblFooter);
        mainPanel.add(footer);

        setContentPane(mainPanel);
    }

    // Custom UI element for the 4 data blocks
    private JPanel createDataCard(String title, String value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GOLD, 1),
                BorderFactory.createEmptyBorder(15, 10, 15, 10)));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(FONT_HEADER);
        titleLabel.setForeground(CRIMSON_DARK);

        JLabel valueLabel = new JLabel(value, SwingConstants.CENTER);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLabel.setForeground(CRIMSON);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    // Reusing your exact button style
    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DashboardFrame().setVisible(true));
    }
}