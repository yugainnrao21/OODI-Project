package report;

import view.MasterDashboard;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ReportingMainFrame extends JFrame {

    // %%%% Shared Colour Palette %%%%%%%%%%%%%%%%%%%
    static final Color APP_CRIMSON      = new Color(139,   0,  28);
    static final Color APP_CRIMSON_DARK = new Color(100,   0,  20);
    static final Color APP_CRIMSON_SOFT = new Color(180,  30,  55);
    static final Color APP_CREAM        = new Color(255, 248, 240);
    static final Color APP_GOLD         = new Color(218, 165,  32);
    static final Color APP_TEXT_LIGHT   = new Color(220, 200, 200);
    static final Color WHITE            = Color.WHITE;

    public ReportingMainFrame() {
        setTitle("Reporting & Analytics");
        setSize(700, 620); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(APP_CRIMSON);

        // Header
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(APP_CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 110);
        mainPanel.add(headerBar);

        JLabel lblTitle = new JLabel("REPORTING & ANALYTICS", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(30, 18, 640, 38);
        headerBar.add(lblTitle);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(APP_GOLD);
        goldBar.setBounds(0, 108, 700, 3);
        mainPanel.add(goldBar);

        JLabel lblSubtitle = new JLabel("Track your daily sales, profits, and bakery performance", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubtitle.setForeground(APP_TEXT_LIGHT);
        lblSubtitle.setBounds(30, 70, 640, 22);
        headerBar.add(lblSubtitle);

        // Card area
        JPanel cardArea = new JPanel(null);
        cardArea.setBackground(APP_CREAM);
        cardArea.setBounds(50, 140, 600, 360);
        cardArea.setBorder(BorderFactory.createLineBorder(APP_GOLD, 2));
        mainPanel.add(cardArea);

        JLabel lblMenu = new JLabel("SELECT A MODULE", SwingConstants.CENTER);
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblMenu.setForeground(APP_CRIMSON_DARK);
        lblMenu.setBounds(0, 15, 600, 22);
        cardArea.add(lblMenu);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(APP_GOLD);
        cardSep.setBounds(20, 42, 560, 2);
        cardArea.add(cardSep);

        // Grid
        JPanel gridPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        gridPanel.setBackground(APP_CREAM);
        gridPanel.setBounds(30, 60, 540, 260); 
        
        JButton dashboardBtn = createMenuButton("📊  DASHBOARD");
        JButton salesBtn     = createMenuButton("📈  SALES REPORT");
        JButton inventoryBtn = createMenuButton("📦  INVENTORY REPORT");
        JButton supplierBtn  = createMenuButton("🏢  SUPPLIER REPORT");
        JButton scheduleBtn  = createMenuButton("📅  SCHEDULE REPORT");

        dashboardBtn.addActionListener(e -> new DashboardFrame().setVisible(true));
        salesBtn.addActionListener(e -> new SalesReportFrame().setVisible(true));
        inventoryBtn.addActionListener(e -> new InventoryReportFrame().setVisible(true));
        supplierBtn.addActionListener(e -> new SupplierReportFrame().setVisible(true));
        scheduleBtn.addActionListener(e -> new ScheduleReportFrame().setVisible(true));

        gridPanel.add(dashboardBtn);
        gridPanel.add(salesBtn);
        gridPanel.add(inventoryBtn);
        gridPanel.add(supplierBtn);
        gridPanel.add(scheduleBtn);
        cardArea.add(gridPanel);

        // BACK TO MASTER DASHBOARD BUTTON
        JButton btnBack = new JButton("< BACK TO MAIN DASHBOARD");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBack.setBackground(new Color(200, 180, 180));
        btnBack.setForeground(APP_CRIMSON_DARK);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        btnBack.setBounds(230, 515, 240, 38);
        btnBack.addActionListener(e -> {
            new MasterDashboard().setVisible(true); 
            this.dispose();
        });
        mainPanel.add(btnBack);

        setContentPane(mainPanel);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(APP_CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(APP_GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(APP_CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(APP_CRIMSON); }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ReportingMainFrame().setVisible(true));
    }
}