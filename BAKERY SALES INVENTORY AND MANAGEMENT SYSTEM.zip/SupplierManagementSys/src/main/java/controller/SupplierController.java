package controller;

import model.Supplier;
import database.Database;

// ============================================================
// CLASS: SupplierController
// From Class Diagram: <<Control>>
// Bridges the Boundary (view) and the Repository (Database)
// ============================================================
public class SupplierController {

    // - database : Database  (from class diagram)
    private Database database = new Database();

    // + registerSupplier(supplierData : Object) : boolean
    public boolean registerSupplier(String id, String name, String contact, 
                                    String email, String address, String status, String type,
                                    double cost, double delivery, double quality) { 
        
        // 🛡️ BACKUP SHIELD: Backend Validation for 0-10 Scale 🛡️
        if (cost < 0 || cost > 10 || delivery < 0 || delivery > 10 || quality < 0 || quality > 10) {
            System.out.println("❌ Registration Failed: Performance scores must be between 0 and 10.");
            return false; // Aborts the save!
        }

        // 🚀 TRUE FACTORY DESIGN PATTERN 🚀
        // We delegate object creation entirely to the dedicated Factory class!
        model.Supplier newSupplier = model.SupplierFactory.createSupplier(type, id, name, contact, email, address, status, cost, delivery, quality);
        
        if (newSupplier != null) return database.persistSupplier(newSupplier);
        return false;
    }

    // + submitSearch(keyword : String) : List
    public java.util.List<Supplier> submitSearch(String keyword) {
        return database.querySupplierByKeyword(keyword);
    }

    // + getSupplierProfile(supplierID : String) : Supplier
    public Supplier getSupplierProfile(String supplierID) {
        return database.fetchSupplier(supplierID);
    }

    // Convenience alias used by views
    public Supplier searchSupplier(String id) {
        return database.searchSupplier(id);
    }

    // + updateSupplier(supplierID : String, updatedData : Object) : boolean
    public boolean updateStatus(String id, String newStatus) {
        return database.updateSupplierStatus(id, newStatus);
    }

    // + requestDeactivateSupplier(supplierID : String) : boolean
    public boolean requestDeactivateSupplier(String supplierID) {
        return database.updateSupplierStatus(supplierID, "Inactive");
    }

    // + requestSupplierHistory(supplierID : String) : List
    public java.util.List<String[]> requestSupplierHistory(String supplierID) {
        return database.fetchOrdersBySupplier(supplierID);
    }

    // Delete
    public boolean deleteSupplier(String id) {
        return database.deleteSupplier(id);
    }

    // + showErrorMessage() : void
    public void showErrorMessage() {
        System.out.println("[SupplierController] An error occurred.");
    }

    // ================================================================
    // TOPSIS: recommendBestSupplier (Now takes Dynamic User Weights)
    // ================================================================
    public model.Supplier recommendBestSupplier(double costWeight, double deliveryWeight, double qualityWeight) {
        java.util.List<model.Supplier> realSuppliers = database.getAllActiveSuppliers();
        if (realSuppliers.isEmpty()) return null;

        int count = realSuppliers.size();
        double[][] decisionMatrix = new double[count][3];
        
        for (int i = 0; i < count; i++) {
            // Pull the REAL numbers from your database objects!
            decisionMatrix[i][0] = realSuppliers.get(i).getCostMetric();
            decisionMatrix[i][1] = realSuppliers.get(i).getDeliveryMetric();
            decisionMatrix[i][2] = realSuppliers.get(i).getQualityMetric();
        }
        
        // Put the user's inputs into the array format the math expects
        double[] userWeights = {costWeight, deliveryWeight, qualityWeight};
        
        model.SupplierEvaluator evaluator = new model.SupplierEvaluator();
        
        // Pass the user weights into the math evaluator
        return evaluator.getBestSupplier(realSuppliers, decisionMatrix, userWeights);
    }
}