package controller;

import database.Database;
import model.PurchaseOrder;
import model.OrderItem;
import java.util.ArrayList;

// ============================================================
// CLASS: OrderController
// From Class Diagram: <<Control>>
// ============================================================
public class OrderController {

    // - database : Database  (from class diagram)
    private Database database = new Database();

    // + createPurchaseOrder(supplierID : String, itemList : List) : PurchaseOrder
    public boolean createPurchaseOrder(String supplierID, String itemDetails, double amount) {
        String poNumber = "PO-" + (int)(Math.random() * 90000 + 10000);
        ArrayList<OrderItem> items = new ArrayList<>();
        items.add(new OrderItem(itemDetails, 1));
        PurchaseOrder newOrder = new PurchaseOrder(poNumber, supplierID, items, amount);
        return database.savePurchaseOrder(newOrder);
    }

    // + requestCancelOrder(poNumber : String, reason : String) : boolean
    public boolean requestCancelOrder(String poNumber, String reason) {
        return database.updateOrderStatus(poNumber, "Cancelled", reason);
    }

    // + sendOrderDetails(poObject : PurchaseOrder) : boolean
    public boolean sendOrderDetails(PurchaseOrder poObject) {
        return database.savePurchaseOrder(poObject);
    }

    // + notifySupplierCancellation(poNumber : String) : void
    public void notifySupplierCancellation(String poNumber) {
        System.out.println("[OrderController] Order " + poNumber + " has been cancelled.");
    }
}