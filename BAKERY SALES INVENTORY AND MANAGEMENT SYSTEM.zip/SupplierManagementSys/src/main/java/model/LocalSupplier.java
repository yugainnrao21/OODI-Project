package model;

// ============================================================
// CLASS: LocalSupplier
// From Class Diagram: <<Entity>>
// extends Supplier (INHERITANCE)
// implements Taxable (INTERFACE)
// Demonstrates: INHERITANCE + POLYMORPHISM (overrides getSupplierType & calculateTax)
// ============================================================
public class LocalSupplier extends Supplier implements Taxable {

    // - sstRegistrationNumber : String  (from class diagram)
    private String sstRegistrationNumber;

    // Constructor
   // Constructor
    public LocalSupplier(String supplierID, String supplierName, String contactNumber,
                         String email, String address, String status,
                         double costMetric, double deliveryMetric, double qualityMetric, // <-- ADDED METRICS
                         String sstRegistrationNumber) {
        
        // Pass all 9 variables up to the parent Supplier class
        super(supplierID, supplierName, contactNumber, email, address, status, costMetric, deliveryMetric, qualityMetric);
        
        this.sstRegistrationNumber = sstRegistrationNumber;
    }

    // + getSupplierType() : String  — POLYMORPHISM: overrides abstract method
    @Override
    public String getSupplierType() {
        return "Local";
    }

    // + calculateTax(orderAmount : double) : double  — POLYMORPHISM: implements interface
    @Override
    public double calculateTax(double orderAmount) {
        return orderAmount * 0.06; // 6% SST for Local suppliers
    }

    public String getSstRegistrationNumber() { return sstRegistrationNumber; }
}