package model;

import java.util.List;

// ============================================================
// CLASS: PurchaseOrder
// From Class Diagram: <<Entity>>
// Demonstrates: POLYMORPHISM via method overloading (2 constructors)
//               ENCAPSULATION (private fields + getters/setters)
// ============================================================
public class PurchaseOrder {

    // Fields matching class diagram (- = private)
    private String      poNumber;
    private String      supplierID;
    private List<OrderItem> itemList;
    private double      totalAmount;
    private String      status;

    // -------------------------------------------------------
    // POLYMORPHISM: METHOD OVERLOADING — Constructor 1
    // Used when creating a brand new order (status defaults to "Pending")
    // + newPurchaseOrder(supplierID: String, itemList: List) : PurchaseOrder
    // -------------------------------------------------------
    public PurchaseOrder(String poNumber, String supplierID,
                         List<OrderItem> itemList, double totalAmount) {
        this.poNumber     = poNumber;
        this.supplierID   = supplierID;
        this.itemList     = itemList;
        this.totalAmount  = totalAmount;
        this.status       = "Pending";
    }

    // -------------------------------------------------------
    // POLYMORPHISM: METHOD OVERLOADING — Constructor 2
    // Used when loading an existing order from the text file
    // -------------------------------------------------------
    public PurchaseOrder(String poNumber, String supplierID,
                         List<OrderItem> itemList, double totalAmount, String status) {
        this.poNumber     = poNumber;
        this.supplierID   = supplierID;
        this.itemList     = itemList;
        this.totalAmount  = totalAmount;
        this.status       = status;
    }

    // - calculateTotalAmount() : double  (from class diagram)
    private double calculateTotalAmount() {
        double total = 0;
        if (itemList != null) {
            for (OrderItem item : itemList) {
                total += item.getSubtotal();
            }
        }
        return total;
    }

    // + setStatus(status: String) : void
    public void setStatus(String status) {
        this.status = status;
    }

    // POLYMORPHISM: METHOD OVERRIDING — overrides Java's default toString()
    @Override
    public String toString() {
        return "PO Number: " + poNumber + " | Supplier: " + supplierID
             + " | Total: RM " + String.format("%.2f", totalAmount)
             + " | Status: " + status;
    }

    // Getters (Encapsulation)
    public String          getPoNumber()     { return poNumber; }
    public String          getSupplierID()   { return supplierID; }
    public List<OrderItem> getItemList()     { return itemList; }
    public double          getTotalAmount()  { return totalAmount; }
    public String          getStatus()       { return status; }
}