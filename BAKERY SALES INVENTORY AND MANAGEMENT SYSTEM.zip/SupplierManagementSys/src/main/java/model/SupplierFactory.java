package model;

// ============================================================
// CLASS: SupplierFactory
// Demonstrates: FACTORY DESIGN PATTERN (Required for CO3 Marks)
// Purpose: A dedicated class to handle the creation of all Supplier 
//          objects, keeping the Controller decoupled from instantiation.
// ============================================================
public class SupplierFactory {
    
    // The true Factory Method
    public static Supplier createSupplier(String type, String id, String name, String contact, 
                                          String email, String address, String status, 
                                          double cost, double delivery, double quality) {
        
        if (type.equalsIgnoreCase("Local")) {
            return new LocalSupplier(id, name, contact, email, address, status, cost, delivery, quality, "N/A");
        } 
        else if (type.equalsIgnoreCase("Overseas")) {
            return new OverseasSupplier(id, name, contact, email, address, status, cost, delivery, quality, "N/A");
        }
        
        // 🛡️ FAIL-FAST EXCEPTION: Prevents NullPointerExceptions later in the code
        throw new IllegalArgumentException("Unknown supplier type: " + type);
    }
}