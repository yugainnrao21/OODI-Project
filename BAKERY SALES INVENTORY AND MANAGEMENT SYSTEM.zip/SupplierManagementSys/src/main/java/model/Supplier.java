package model;

// ============================================================
// ABSTRACT CLASS: Supplier
// From Class Diagram: <<Abstract Entity>>
// Subclasses: LocalSupplier, OverseasSupplier
// Demonstrates: ABSTRACTION + ENCAPSULATION
// ============================================================
public abstract class Supplier {

    // Protected fields matching class diagram (# = protected)
    protected String supplierID;
    protected String supplierName;
    protected String contactNumber;
    protected String email;
    protected String address;
    protected String status;
    
    // NEW: The TOPSIS Metrics (# = protected)
    protected double costMetric;
    protected double deliveryMetric;
    protected double qualityMetric;

    // Constructor (Updated to require the 3 new metrics)
    public Supplier(String supplierID, String supplierName, String contactNumber,
                    String email, String address, String status,
                    double costMetric, double deliveryMetric, double qualityMetric) {
        this.supplierID    = supplierID;
        this.supplierName  = supplierName;
        this.contactNumber = contactNumber;
        this.email         = email;
        this.address       = address;
        this.status        = status;
        
        // NEW: Assigning the TOPSIS metrics
        this.costMetric     = costMetric;
        this.deliveryMetric = deliveryMetric;
        this.qualityMetric  = qualityMetric;
    }

    // Abstract method - from class diagram: + getSupplierType() {abstract} : String
    // Forces every subclass to declare their own type
    public abstract String getSupplierType();

    // + setStatus(status: String) : void
    public void setStatus(String status) {
        this.status = status;
    }

    // Original Getters (Encapsulation)
    public String getSupplierID()       { return supplierID; }
    public String getSupplierName()     { return supplierName; }
    public String getContactNumber()    { return contactNumber; }
    public String getEmail()            { return email; }
    public String getAddress()          { return address; }
    public String getStatus()           { return status; }
    
    // NEW: Getters for TOPSIS Algorithm
    public double getCostMetric()       { return costMetric; }
    public double getDeliveryMetric()   { return deliveryMetric; }
    public double getQualityMetric()    { return qualityMetric; }

    // Format for text-file database storage
    @Override
    public String toString() {
        return supplierID + "," + supplierName + "," + contactNumber + ","
             + email + "," + address + "," + status + "," 
             + costMetric + "," + deliveryMetric + "," + qualityMetric + "," 
             + getSupplierType();
    }
}