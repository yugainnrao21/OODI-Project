package model;

// ============================================================
// CLASS: OrderItem
// From Class Diagram: <<Entity>>
// Relationship: PurchaseOrder has 1..* OrderItem
// ============================================================
public class OrderItem {

    // Fields matching class diagram
    private String itemID;
    private int    quantity;
    private double unitPrice;
    private String itemName;

    // Constructor
    public OrderItem(String itemName, int quantity) {
        this.itemID    = "ITEM-" + (int)(Math.random() * 9000 + 1000);
        this.itemName  = itemName;
        this.quantity  = quantity;
        this.unitPrice = 0.0;
    }

    public OrderItem(String itemID, String itemName, int quantity, double unitPrice) {
        this.itemID    = itemID;
        this.itemName  = itemName;
        this.quantity  = quantity;
        this.unitPrice = unitPrice;
    }

    // + getSubtotal() : double
    public double getSubtotal() {
        return quantity * unitPrice;
    }

    // + setQuantity(qty : int) : void
    public void setQuantity(int qty) {
        this.quantity = qty;
    }

    // Getters
    public String getItemID()    { return itemID; }
    public String getItemName()  { return itemName; }
    public int    getQuantity()  { return quantity; }
    public double getUnitPrice() { return unitPrice; }
}