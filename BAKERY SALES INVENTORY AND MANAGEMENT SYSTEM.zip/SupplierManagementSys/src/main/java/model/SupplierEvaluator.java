package model;

import java.util.List;

// ============================================================
// CLASS: SupplierEvaluator
// From Class Diagram: <<Model>>
// Used by: SupplierController.recommendBestSupplier()
// Demonstrates: Encapsulation + complex algorithm logic
// ============================================================
public class SupplierEvaluator {

    // - isBenefit : boolean[]   (from class diagram)
    // All metrics are now graded on a scale where a HIGHER score is BETTER.
    private boolean[] isBenefit = {true, true, true};

    // + evaluateSuppliers(matrix : double[][], criteriaWeights: double[]) : double[]
    // THE FIX: Weights are no longer hardcoded! They are passed in from the UI.
    public double[] evaluateSuppliers(double[][] matrix, double[] criteriaWeights) {
        int numSuppliers = matrix.length;
        int numCriteria  = criteriaWeights.length;

        // Step 1: Normalize the matrix
        double[][] normalized = new double[numSuppliers][numCriteria];
        for (int j = 0; j < numCriteria; j++) {
            double sumSq = 0;
            for (int i = 0; i < numSuppliers; i++) sumSq += Math.pow(matrix[i][j], 2);
            double sqrtSum = Math.sqrt(sumSq);
            for (int i = 0; i < numSuppliers; i++)
                normalized[i][j] = (sqrtSum == 0) ? 0 : matrix[i][j] / sqrtSum;
        }

        // Step 2: Weighted normalized matrix
        double[][] weighted = new double[numSuppliers][numCriteria];
        for (int i = 0; i < numSuppliers; i++)
            for (int j = 0; j < numCriteria; j++)
                weighted[i][j] = normalized[i][j] * criteriaWeights[j];

        // Step 3: Ideal best (V+) and ideal worst (V-)
        double[] idealBest  = new double[numCriteria];
        double[] idealWorst = new double[numCriteria];
        for (int j = 0; j < numCriteria; j++) {
            double max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            for (int i = 0; i < numSuppliers; i++) {
                if (weighted[i][j] > max) max = weighted[i][j];
                if (weighted[i][j] < min) min = weighted[i][j];
            }
            idealBest[j]  = isBenefit[j] ? max : min;
            idealWorst[j] = isBenefit[j] ? min : max;
        }

        // Step 4: Closeness scores
        double[] closeness = new double[numSuppliers];
        for (int i = 0; i < numSuppliers; i++) {
            double distBest = 0, distWorst = 0;
            for (int j = 0; j < numCriteria; j++) {
                distBest  += Math.pow(weighted[i][j] - idealBest[j],  2);
                distWorst += Math.pow(weighted[i][j] - idealWorst[j], 2);
            }
            distBest  = Math.sqrt(distBest);
            distWorst = Math.sqrt(distWorst);
            closeness[i] = distWorst / (distBest + distWorst);
        }
        return closeness;
    }

    // + getBestSupplier(suppliers : List, matrix : double[][], weights : double[]) : Supplier
    // THE FIX: Added 'weights' as a parameter so it can pass them to evaluateSuppliers
    public Supplier getBestSupplier(List<Supplier> suppliers, double[][] matrix, double[] weights) {
        if (suppliers == null || suppliers.isEmpty() || matrix == null) return null;
        
        // Pass the user's weights into the math engine
        double[] scores   = evaluateSuppliers(matrix, weights); 
        
        int bestIndex     = 0;
        double maxScore   = -1;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) { maxScore = scores[i]; bestIndex = i; }
        }
        return suppliers.get(bestIndex);
    }
}