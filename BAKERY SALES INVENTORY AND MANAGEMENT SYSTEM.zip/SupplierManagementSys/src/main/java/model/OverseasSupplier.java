package model;

// ============================================================
// CLASS: OverseasSupplier
// From Class Diagram: <<Entity>>
// extends Supplier (INHERITANCE)
// implements Taxable (INTERFACE)
// Demonstrates: INHERITANCE + POLYMORPHISM (overrides getSupplierType & calculateTax)
// ============================================================
public class OverseasSupplier extends Supplier implements Taxable {

    // - importCountry : String  (from class diagram)
    private String importCountry;

    // Constructor
    // Constructor
    public OverseasSupplier(String supplierID, String supplierName, String contactNumber,
                            String email, String address, String status,
                            double costMetric, double deliveryMetric, double qualityMetric, // <-- ADDED METRICS
                            String importCountry) {
        
        // Pass all 9 variables up to the parent Supplier class
        super(supplierID, supplierName, contactNumber, email, address, status, costMetric, deliveryMetric, qualityMetric);
        
        this.importCountry = importCountry;
    }

    // + getSupplierType() : String  — POLYMORPHISM: overrides abstract method
    @Override
    public String getSupplierType() {
        return "Overseas";
    }

    // + calculateTax(orderAmount : double) : double  — POLYMORPHISM: implements interface
    @Override
    public double calculateTax(double orderAmount) {
        return orderAmount * 0.10; // 10% Import Duty for Overseas suppliers
    }

    public String getImportCountry() { return importCountry; }
}