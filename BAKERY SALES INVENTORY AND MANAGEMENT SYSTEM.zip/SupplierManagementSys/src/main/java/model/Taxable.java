package model;
 
// ============================================================
// INTERFACE: Taxable
// From Class Diagram: <<Interface>>
// Implemented by: LocalSupplier, OverseasSupplier
// ============================================================
public interface Taxable {
    double calculateTax(double orderAmount);
}
 