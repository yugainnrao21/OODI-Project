package database;

import model.Supplier;
import model.PurchaseOrder;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class Database {

    private boolean connectionStatus = true;

    // ==========================================================
    // MYSQL CONNECTION
    // ==========================================================
    private static final String URL      = "jdbc:mysql://localhost:3306/bakery_db";
    private static final String USER     = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Database Connection Failed: " + e.getMessage());
            return null;
        }
    }

    // ==========================================================
    // SUPPLIER METHODS
    // ==========================================================

    public boolean persistSupplier(Supplier supplier) {
        
        // 1. YOUR MODULE SQL: Saves the full data needed for your TOPSIS algorithm
        String sql1 = "INSERT INTO Supplier (supplierID, supplierName, contactNumber, email, "
                   + "address, status, costMetric, deliveryMetric, qualityMetric, supplierType) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // 2. THE BRIDGE SQL: Copies the basic info over to Siti's Reporting table!
        String sql2 = "INSERT INTO suppliers (supplier_name, contact_person, phone_number, product_supplied) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt1 = conn.prepareStatement(sql1);
             PreparedStatement stmt2 = conn.prepareStatement(sql2)) {

            // --- EXECUTE QUERY 1 (Your full data) ---
            stmt1.setString(1,  supplier.getSupplierID());
            stmt1.setString(2,  supplier.getSupplierName());
            stmt1.setString(3,  supplier.getContactNumber());
            stmt1.setString(4,  supplier.getEmail());
            stmt1.setString(5,  supplier.getAddress());
            stmt1.setString(6,  supplier.getStatus());
            stmt1.setDouble(7,  supplier.getCostMetric());
            stmt1.setDouble(8,  supplier.getDeliveryMetric());
            stmt1.setDouble(9,  supplier.getQualityMetric());
            stmt1.setString(10, supplier.getSupplierType());
            stmt1.executeUpdate();

            // --- EXECUTE QUERY 2 (The Bridge to Siti's Module) ---
            stmt2.setString(1, supplier.getSupplierName());
            // SMART MAPPING: We use your Email field for her Contact Person column
            stmt2.setString(2, supplier.getEmail()); 
            stmt2.setString(3, supplier.getContactNumber());
            // SMART MAPPING: We use your Type field and add "Goods" for her Product column
            stmt2.setString(4, supplier.getSupplierType() + " Goods"); 
            stmt2.executeUpdate();

            return true;

        } catch (SQLException e) {
            System.out.println("SQL Insert Error: " + e.getMessage());
            return false;
        }
    }

    public List<Supplier> querySupplierByKeyword(String keyword) {
        List<Supplier> results = new ArrayList<>();
        String sql = "SELECT * FROM Supplier WHERE supplierID LIKE ? OR supplierName LIKE ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + keyword + "%");
            stmt.setString(2, "%" + keyword + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Supplier s = buildSupplierFromResultSet(rs);
                    if (s != null) results.add(s);
                }
            }
        } catch (SQLException e) {
            System.out.println("Query Error: " + e.getMessage());
        }
        return results;
    }

    public Supplier fetchSupplier(String supplierID) {
        return searchSupplier(supplierID);
    }

    public Supplier searchSupplier(String searchID) {
        String sql = "SELECT * FROM Supplier WHERE supplierID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, searchID);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return buildSupplierFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Search Error: " + e.getMessage());
        }
        return null;
    }

    public boolean applyUpdate(String supplierID, Object updatedData) {
        if (updatedData instanceof model.Supplier) {
            model.Supplier s = (model.Supplier) updatedData;
            String sql = "UPDATE Supplier SET supplierName = ?, contactNumber = ?, "
                       + "email = ?, address = ?, status = ? WHERE supplierID = ?";
            try (Connection conn = getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, s.getSupplierName());
                stmt.setString(2, s.getContactNumber());
                stmt.setString(3, s.getEmail());
                stmt.setString(4, s.getAddress());
                stmt.setString(5, s.getStatus());
                stmt.setString(6, supplierID);
                return stmt.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Apply Update Error: " + e.getMessage());
            }
        }
        return false;
    }

    public boolean checkPendingOrders(String supplierID) {
        String sql = "SELECT * FROM PurchaseOrder WHERE supplierID = ? AND status = 'Pending'";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplierID);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.out.println("Check Pending Error: " + e.getMessage());
        }
        return false;
    }

    public boolean updateSupplierStatus(String supplierID, String status) {
        String sql = "UPDATE Supplier SET status = ? WHERE supplierID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, supplierID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Update Supplier Error: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteSupplier(String supplierID) {
        String sql = "DELETE FROM Supplier WHERE supplierID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplierID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Delete Supplier Error: " + e.getMessage());
            return false;
        }
    }

    public List<Supplier> getAllActiveSuppliers() {
        List<Supplier> list = new ArrayList<>();
        String sql = "SELECT * FROM Supplier WHERE status = 'Active'";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Supplier s = buildSupplierFromResultSet(rs);
                if (s != null) list.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Database Fetch Error: " + e.getMessage());
        }
        return list;
    }

    // ==========================================================
    // PURCHASE ORDER METHODS
    // ==========================================================

    public boolean savePurchaseOrder(PurchaseOrder poObject) {
        String sql = "INSERT INTO PurchaseOrder (poNumber, supplierID, totalAmount, status) "
                   + "VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, poObject.getPoNumber());
            stmt.setString(2, poObject.getSupplierID());
            stmt.setDouble(3, poObject.getTotalAmount());
            stmt.setString(4, poObject.getStatus());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Order Save Error: " + e.getMessage());
            return false;
        }
    }

    public boolean savePurchaseOrder(String poNumber, String supplierID,
                                     String date, String amount, String status) {
        String sql = "INSERT INTO PurchaseOrder (poNumber, supplierID, totalAmount, status) "
                   + "VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, poNumber);
            stmt.setString(2, supplierID);
            stmt.setDouble(3, Double.parseDouble(amount));
            stmt.setString(4, status);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Save Order String Error: " + e.getMessage());
            return false;
        }
    }

    public boolean updateOrderStatus(String poNumber, String status, String reason) {
        String sql = "UPDATE PurchaseOrder SET status = ? WHERE poNumber = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, poNumber);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Update Order Error: " + e.getMessage());
            return false;
        }
    }

    public List<String[]> fetchOrdersBySupplier(String supplierID) {
        List<String[]> orders = new ArrayList<>();
        String sql = "SELECT * FROM PurchaseOrder WHERE supplierID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplierID);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String[] data = new String[4];
                    data[0] = rs.getString("poNumber");
                    data[1] = rs.getString("orderDate");
                    data[2] = String.valueOf(rs.getDouble("totalAmount"));
                    data[3] = rs.getString("status");
                    orders.add(data);
                }
            }
        } catch (SQLException e) {
            System.out.println("Fetch Orders Error: " + e.getMessage());
        }
        return orders;
    }

    // ==========================================================
    // PRIVATE HELPER 
    // ==========================================================
    private Supplier buildSupplierFromResultSet(ResultSet rs) {
        try {
            String id       = rs.getString("supplierID");
            String name     = rs.getString("supplierName");
            String contact  = rs.getString("contactNumber");
            String email    = rs.getString("email");
            String address  = rs.getString("address");
            String status   = rs.getString("status");
            double cost     = rs.getDouble("costMetric");
            double delivery = rs.getDouble("deliveryMetric");
            double quality  = rs.getDouble("qualityMetric");
            String type     = rs.getString("supplierType");

            return model.SupplierFactory.createSupplier(type, id, name, contact, email, address, status, cost, delivery, quality);
        } catch (SQLException e) {
            System.out.println("Build Supplier Error: " + e.getMessage());
            return null;
        } catch (IllegalArgumentException e) {
            System.out.println("Factory Error: " + e.getMessage());
            return null;
        }
    }
}