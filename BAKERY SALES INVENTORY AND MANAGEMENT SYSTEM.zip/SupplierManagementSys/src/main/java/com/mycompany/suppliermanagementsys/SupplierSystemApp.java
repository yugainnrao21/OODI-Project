package com.mycompany.suppliermanagementsys;

// ============================================================
// CLASS: SupplierSystemApp
// From Class Diagram: <<Application>>
// Entry point — launches MainDashboard
// ============================================================
public class SupplierSystemApp {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view.MainDashboard().setVisible(true);
            }
        });
    }
}