package product;

import view.MasterDashboard;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class SmartInventoryApp extends JFrame {

    // %%%% Shared Bakery System Colors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color TEXT_LIGHT     = new Color(220, 200, 200);
    static final Color GOLD           = new Color(218, 165,  32);

    public SmartInventoryApp() {
        setTitle("Product Management System");
        setSize(700, 620); // Resized to match your system standards
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(CRIMSON);

        // ---- Header bar ----
        JPanel headerBar = new JPanel(null);
        headerBar.setBackground(CRIMSON_DARK);
        headerBar.setBounds(0, 0, 700, 110);
        mainPanel.add(headerBar);

        JLabel lblTitle = new JLabel("PRODUCT MANAGEMENT", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(WHITE);
        lblTitle.setBounds(30, 18, 640, 38);
        headerBar.add(lblTitle);

        JPanel goldBar = new JPanel();
        goldBar.setBackground(GOLD);
        goldBar.setBounds(0, 108, 700, 3);
        mainPanel.add(goldBar);

        JLabel lblSubtitle = new JLabel("Manage your baked goods, categories, and daily stock", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblSubtitle.setForeground(TEXT_LIGHT);
        lblSubtitle.setBounds(30, 70, 640, 22);
        headerBar.add(lblSubtitle);

        // ---- Card area ----
        JPanel cardArea = new JPanel(null);
        cardArea.setBackground(CREAM);
        cardArea.setBounds(50, 140, 600, 360);
        cardArea.setBorder(BorderFactory.createLineBorder(GOLD, 2));
        mainPanel.add(cardArea);

        JLabel lblMenu = new JLabel("SELECT A MODULE", SwingConstants.CENTER);
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMenu.setForeground(CRIMSON_DARK);
        lblMenu.setBounds(0, 18, 600, 22);
        cardArea.add(lblMenu);

        JSeparator cardSep = new JSeparator();
        cardSep.setForeground(GOLD);
        cardSep.setBounds(20, 46, 560, 2);
        cardArea.add(cardSep);

        // ---- Action Buttons ----
        JButton btnProduct = createMenuButton("📅 PRODUCT CATALOG");
        btnProduct.setBounds(100, 70, 400, 60);
        btnProduct.addActionListener(e -> new ProductManagementFrame().setVisible(true));
        cardArea.add(btnProduct);

        JButton btnCategory = createMenuButton("📅 MANAGE CATEGORIES");
        btnCategory.setBounds(100, 150, 400, 60);
        btnCategory.addActionListener(e -> new CategoryManagementFrame().setVisible(true));
        cardArea.add(btnCategory);

        JButton btnAlert = createMenuButton("📅 STOCK ALERTS");
        btnAlert.setBounds(100, 230, 400, 60);
        btnAlert.addActionListener(e -> new StockAlertFrame().setVisible(true));
        cardArea.add(btnAlert);

        // ---- BACK TO MASTER DASHBOARD BUTTON ----
        JButton btnBack = new JButton("< BACK TO MAIN DASHBOARD");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBack.setBackground(new Color(200, 180, 180));
        btnBack.setForeground(CRIMSON_DARK);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 1));
        btnBack.setBounds(230, 515, 240, 38);
        btnBack.addActionListener(e -> {
            new MasterDashboard().setVisible(true); // Successfully links back to Gateway
            this.dispose(); // Closes current window
        });
        mainPanel.add(btnBack);

        setContentPane(mainPanel);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SmartInventoryApp().setVisible(true));
    }
}