package product;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ProductManagementFrame extends JFrame {

    // %%%% Shared Bakery System Colors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color GOLD           = new Color(218, 165,  32);

    private DefaultTableModel tableModel;
    private JTable table;
    
    // 🚀 THE BRIDGE TO THE DATABASE!
    private DatabaseManager.ProductDAO dao;

    public ProductManagementFrame() {
        // Initialize the database connection
        dao = new DatabaseManager.ProductDAO();

        setTitle("Product Catalog");
        setSize(900, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(CREAM);

        // ── Top bar ──────────────────────────────────────────────
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(CRIMSON_DARK);
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        JLabel lbl = new JLabel("PRODUCT CATALOG");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lbl.setForeground(WHITE);
        topPanel.add(lbl, BorderLayout.WEST);
        
        JPanel goldDivider = new JPanel();
        goldDivider.setBackground(GOLD);
        goldDivider.setPreferredSize(new Dimension(900, 3));
        
        JPanel headerContainer = new JPanel(new BorderLayout());
        headerContainer.add(topPanel, BorderLayout.CENTER);
        headerContainer.add(goldDivider, BorderLayout.SOUTH);
        
        add(headerContainer, BorderLayout.NORTH);

        // ── Table ─────────────────────────────────────────────────
        String[] columns = {"ID", "Product Name", "Category", "Price (RM)", "Qty", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setBackground(WHITE);
        table.setGridColor(new Color(230, 230, 230));
        
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(CRIMSON);
        table.getTableHeader().setForeground(WHITE);
        
        table.setSelectionBackground(CRIMSON_SOFT);
        table.setSelectionForeground(WHITE);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        scrollPane.setBackground(CREAM);
        scrollPane.getViewport().setBackground(CREAM);
        add(scrollPane, BorderLayout.CENTER);

        // ── Bottom button bar ─────────────────────────────────────
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        btnPanel.setBackground(CREAM);
        btnPanel.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, GOLD));

        JButton btnAdd    = createActionButton("⊕  ADD NEW");
        JButton btnEdit   = createActionButton("✎  EDIT");
        JButton btnRemove = createActionButton("☒  REMOVE");
        JButton btnSearch = createActionButton("⌕  SEARCH");

        btnPanel.add(btnAdd);
        btnPanel.add(btnEdit);
        btnPanel.add(btnRemove);
        btnPanel.add(btnSearch);
        add(btnPanel, BorderLayout.SOUTH);

        // ── Button actions ────────────────────────────────────────
        btnAdd.addActionListener(e -> showAddDialog());
        btnRemove.addActionListener(e -> removeSelectedRow());
        btnSearch.addActionListener(e -> showSearchDialog());
        btnEdit.addActionListener(e -> showEditDialog());

        // 🚀 LOAD DATA FROM MYSQL WHEN WINDOW OPENS!
        loadTableData();
    }

    // Custom Button Stylizer
    private JButton createActionButton(String text) {
        JButton btn = new JButton(text);
        btn.setPreferredSize(new Dimension(150, 45));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(CRIMSON_DARK, 2));
        
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }

    // =====================================================================
    // 🚀 NEW METHOD: Fetch from Database
    // =====================================================================
    private void loadTableData() {
        tableModel.setRowCount(0); // Clear old data
        List<DatabaseManager.Product> products = dao.getAllProducts();
        
        for (DatabaseManager.Product p : products) {
            String id = "P" + String.format("%03d", p.getProductID());
            int threshold = dao.getStockThreshold(p.getProductID());
            String status = p.getQuantity() <= threshold ? "Low Stock" : "In Stock";
            
            tableModel.addRow(new Object[]{
                id, 
                p.getName(), 
                p.getCategoryName(), 
                String.format("%.2f", p.getPrice()), 
                p.getQuantity(), 
                status
            });
        }
    }

    // Helper to get or create category IDs safely
    private int getCategoryIdSafely(String categoryName) {
        List<DatabaseManager.Category> cats = dao.getAllCategories();
        for (DatabaseManager.Category c : cats) {
            if (c.getName().equalsIgnoreCase(categoryName)) return c.getCategoryID();
        }
        dao.addCategory(categoryName);
        cats = dao.getAllCategories();
        return cats.get(cats.size() - 1).getCategoryID();
    }

    // ── Dialog Logics (Wired to Database) ──
    private void showAddDialog() {
        JTextField fName  = new JTextField();
        JTextField fCat   = new JTextField();
        JTextField fPrice = new JTextField();
        JTextField fQty   = new JTextField();

        Object[] fields = {
            "Product Name:", fName,
            "Category:",     fCat,
            "Price (RM):",   fPrice,
            "Quantity:",     fQty
        };

        int result = JOptionPane.showConfirmDialog(this, fields, "Add New Product", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = fName.getText().trim();
                String cat = fCat.getText().trim();
                double p = Double.parseDouble(fPrice.getText().trim());
                int q = Integer.parseInt(fQty.getText().trim());

                if (name.isEmpty() || cat.isEmpty() || p <= 0 || q < 0) throw new Exception();

                int catId = getCategoryIdSafely(cat);
                DatabaseManager.Product newProd = new DatabaseManager.Product(name, "Added via UI", p, q, catId);
                
                if (dao.addProduct(newProd, 10)) { // 10 is default threshold
                    JOptionPane.showMessageDialog(this, "Product added successfully!");
                    loadTableData(); // Refresh table from DB
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add product. Check for duplicate names.");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Check text fields and numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void removeSelectedRow() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to remove.");
            return;
        }
        
        String idString = (String) tableModel.getValueAt(row, 0);
        int actualId = Integer.parseInt(idString.replace("P", ""));
        String name = (String) tableModel.getValueAt(row, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, "Remove \"" + name + "\"? This cannot be undone.", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.removeProduct(actualId)) {
                JOptionPane.showMessageDialog(this, "Product removed successfully.");
                loadTableData(); // Refresh table
            } else {
                JOptionPane.showMessageDialog(this, "Cannot remove product. It might be linked to orders.");
            }
        }
    }

    private void showEditDialog() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.");
            return;
        }
        
        String idString = (String) tableModel.getValueAt(row, 0);
        int actualId = Integer.parseInt(idString.replace("P", ""));

        JTextField fName  = new JTextField((String) tableModel.getValueAt(row, 1));
        JTextField fCat   = new JTextField((String) tableModel.getValueAt(row, 2));
        JTextField fPrice = new JTextField((String) tableModel.getValueAt(row, 3));
        JTextField fQty   = new JTextField(tableModel.getValueAt(row, 4).toString());

        Object[] fields = {
            "Product Name:", fName,
            "Category:",     fCat,
            "Price (RM):",   fPrice,
            "Quantity:",     fQty
        };
        int result = JOptionPane.showConfirmDialog(this, fields, "Edit Product", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            try {
                double p = Double.parseDouble(fPrice.getText().trim());
                int q = Integer.parseInt(fQty.getText().trim());
                int catId = getCategoryIdSafely(fCat.getText().trim());

                DatabaseManager.Product updatedProd = new DatabaseManager.Product(actualId, fName.getText().trim(), "Updated via UI", p, q, catId);
                
                if (dao.updateProduct(updatedProd)) {
                    JOptionPane.showMessageDialog(this, "Product updated successfully.");
                    loadTableData(); // Refresh
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update database.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showSearchDialog() {
        String keyword = JOptionPane.showInputDialog(this, "Enter search keyword:");
        if (keyword == null || keyword.trim().isEmpty()) return;
        
        // Use DAO to search real database
        tableModel.setRowCount(0); 
        List<DatabaseManager.Product> searchResults = dao.searchProduct(keyword);
        
        for (DatabaseManager.Product p : searchResults) {
            String id = "P" + String.format("%03d", p.getProductID());
            int threshold = dao.getStockThreshold(p.getProductID());
            String status = p.getQuantity() <= threshold ? "Low Stock" : "In Stock";
            tableModel.addRow(new Object[]{id, p.getName(), p.getCategoryName(), String.format("%.2f", p.getPrice()), p.getQuantity(), status});
        }
        
        if (searchResults.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No results found for: " + keyword);
            loadTableData(); // Reset table
        }
    }
}