package product;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StockAlertFrame extends JFrame {

    // %%%% Shared Bakery System Colors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color GOLD           = new Color(218, 165,  32);
    static final Color SUCCESS_GREEN  = new Color(34,  139,  34);

    private DefaultTableModel tableModel;
    private JLabel info;
    
    // 🚀 The Bridge to the Database
    private DatabaseManager.ProductDAO dao;

    public StockAlertFrame() {
        // Initialize the database connection
        dao = new DatabaseManager.ProductDAO();

        setTitle("Stock Alerts");
        setSize(700, 500); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(CREAM);

        // ── Top bar (Matching Theme) ──────────────────────────────
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(CRIMSON_DARK);
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        JLabel lbl = new JLabel("STOCK ALERTS");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lbl.setForeground(WHITE);
        topPanel.add(lbl, BorderLayout.WEST);

        // Gold Divider
        JPanel goldDivider = new JPanel();
        goldDivider.setBackground(GOLD);
        goldDivider.setPreferredSize(new Dimension(700, 3));
        
        JPanel headerContainer = new JPanel(new BorderLayout());
        headerContainer.add(topPanel, BorderLayout.CENTER);
        headerContainer.add(goldDivider, BorderLayout.SOUTH);
        add(headerContainer, BorderLayout.NORTH);

        // ── Alert table ───────────────────────────────────────────
        String[] columns = {"Product Name", "Category", "Current Qty", "Threshold", "Alert Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(javax.swing.table.TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                c.setBackground(row % 2 == 0 ? CREAM : WHITE);
                if (isRowSelected(row)) {
                    c.setBackground(CRIMSON_SOFT);
                    c.setForeground(WHITE);
                } else {
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        };
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setGridColor(new Color(230, 230, 230));
        
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(CRIMSON);
        table.getTableHeader().setForeground(WHITE);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        scrollPane.setBackground(CREAM);
        scrollPane.getViewport().setBackground(CREAM);
        add(scrollPane, BorderLayout.CENTER);

        // ── Info label ────────────────────────────────────────────
        info = new JLabel("  ⓘ  Checking system for stock alerts...");
        info.setFont(new Font("Segoe UI", Font.BOLD, 13));
        info.setForeground(CRIMSON);
        info.setPreferredSize(new Dimension(700, 40));
        info.setBackground(new Color(255, 235, 235));
        info.setOpaque(true);
        info.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, GOLD));
        add(info, BorderLayout.SOUTH);

        // 🚀 Fetch Data!
        loadAlerts();
    }

    // =====================================================================
    // 🚀 NEW METHOD: Calculate and Load Alerts Dynamically
    // =====================================================================
    private void loadAlerts() {
        tableModel.setRowCount(0);
        List<DatabaseManager.Product> products = dao.getAllProducts();
        int alertCount = 0;

        for (DatabaseManager.Product p : products) {
            int threshold = dao.getStockThreshold(p.getProductID());
            
            // If the stock is at or below the warning threshold
            if (p.getQuantity() <= threshold) {
                
                // Ensure the database records this alert!
                dao.triggerAlert(p.getProductID(), p.getQuantity());

                String severity = (p.getQuantity() == 0) ? "OUT OF STOCK" : "CRITICAL LOW";
                
                tableModel.addRow(new Object[]{
                    p.getName(),
                    p.getCategoryName(),
                    p.getQuantity(),
                    threshold,
                    severity
                });
                alertCount++;
            }
        }

        // Update the bottom banner based on the results
        if (alertCount > 0) {
            info.setText("  ⚠  Found " + alertCount + " product(s) below safe threshold levels!");
            info.setForeground(CRIMSON);
            info.setBackground(new Color(255, 235, 235));
        } else {
            info.setText("  ✅  All stock levels are optimal. No alerts found.");
            info.setForeground(SUCCESS_GREEN);
            info.setBackground(new Color(235, 255, 235));
        }
    }
}