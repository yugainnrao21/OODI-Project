package product;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CategoryManagementFrame extends JFrame {

    // %%%% Shared Bakery System Colors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    static final Color CRIMSON        = new Color(139,   0,  28);
    static final Color CRIMSON_DARK   = new Color(100,   0,  20);
    static final Color CRIMSON_SOFT   = new Color(180,  30,  55);
    static final Color CREAM          = new Color(255, 248, 240);
    static final Color WHITE          = Color.WHITE;
    static final Color GOLD           = new Color(218, 165,  32);

    // 🚀 Upgraded to hold actual Category Objects so we can track their hidden Database IDs!
    private DefaultListModel<DatabaseManager.Category> listModel;
    private JList<DatabaseManager.Category> categoryList;
    
    // 🚀 The Bridge to the Database
    private DatabaseManager.ProductDAO dao;

    public CategoryManagementFrame() {
        // Initialize the database connection
        dao = new DatabaseManager.ProductDAO();

        setTitle("Manage Categories");
        setSize(550, 500); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(CREAM);

        // ── Top bar (Matching Theme) ──────────────────────────────
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(CRIMSON_DARK);
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        JLabel lbl = new JLabel("MANAGE CATEGORIES");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lbl.setForeground(WHITE);
        topPanel.add(lbl, BorderLayout.WEST);
        
        // Gold Divider
        JPanel goldDivider = new JPanel();
        goldDivider.setBackground(GOLD);
        goldDivider.setPreferredSize(new Dimension(550, 3));
        
        JPanel headerContainer = new JPanel(new BorderLayout());
        headerContainer.add(topPanel, BorderLayout.CENTER);
        headerContainer.add(goldDivider, BorderLayout.SOUTH);
        add(headerContainer, BorderLayout.NORTH);

        // ── Category list ─────────────────────────────────────────
        listModel = new DefaultListModel<>();
        categoryList = new JList<>(listModel);
        categoryList.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        categoryList.setFixedCellHeight(38);
        categoryList.setBackground(WHITE);
        categoryList.setSelectionBackground(CRIMSON_SOFT);
        categoryList.setSelectionForeground(WHITE);
        
        JScrollPane scrollPane = new JScrollPane(categoryList);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        scrollPane.setBackground(CREAM);
        scrollPane.getViewport().setBackground(CREAM);
        add(scrollPane, BorderLayout.CENTER);

        // ── Buttons ───────────────────────────────────────────────
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 15));
        btnPanel.setBackground(CREAM);
        btnPanel.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, GOLD));

        JButton btnAdd    = createActionButton("⊕  ADD");
        JButton btnRename = createActionButton("✎  RENAME");
        JButton btnDelete = createActionButton("☒  DELETE");

        btnPanel.add(btnAdd);
        btnPanel.add(btnRename);
        btnPanel.add(btnDelete);
        add(btnPanel, BorderLayout.SOUTH);

        // ── Button Actions (Wired to Database) ─────────────────────
        btnAdd.addActionListener(e -> {
            String name = JOptionPane.showInputDialog(this, "Enter new category name:");
            if (name == null || name.trim().isEmpty()) return;
            
            // Check for duplicates before adding
            for (int i = 0; i < listModel.size(); i++) {
                if (listModel.get(i).getName().equalsIgnoreCase(name.trim())) {
                    JOptionPane.showMessageDialog(this, "Category already exists.");
                    return;
                }
            }
            
            if (dao.addCategory(name.trim())) {
                JOptionPane.showMessageDialog(this, "Category added successfully.");
                loadCategories(); // Refresh the list from the DB
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add category to database.");
            }
        });

        btnRename.addActionListener(e -> {
            DatabaseManager.Category selected = categoryList.getSelectedValue();
            if (selected == null) { JOptionPane.showMessageDialog(this, "Select a category first."); return; }
            
            String newName = JOptionPane.showInputDialog(this, "Enter new name:", selected.getName());
            if (newName == null || newName.trim().isEmpty()) return;
            
            // Pass the hidden ID to the database so it knows exactly which row to update
            if (dao.renameCategory(selected.getCategoryID(), newName.trim())) {
                JOptionPane.showMessageDialog(this, "Category renamed successfully.");
                loadCategories(); // Refresh the list from the DB
            } else {
                JOptionPane.showMessageDialog(this, "Failed to rename category.");
            }
        });

        btnDelete.addActionListener(e -> {
            DatabaseManager.Category selected = categoryList.getSelectedValue();
            if (selected == null) { JOptionPane.showMessageDialog(this, "Select a category first."); return; }
            
            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete \"" + selected.getName() + "\"?\n(Note: You cannot delete categories that are currently being used by products)",
                "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                
            if (confirm == JOptionPane.YES_OPTION) {
                // Pass the hidden ID to delete it safely
                if (dao.deleteCategory(selected.getCategoryID())) {
                    JOptionPane.showMessageDialog(this, "Category deleted.");
                    loadCategories(); // Refresh the list from the DB
                } else {
                    JOptionPane.showMessageDialog(this, "Cannot delete category!\nMake sure no products are using this category first.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 🚀 Fetch all categories from the database when the window opens!
        loadCategories();
    }

    // =====================================================================
    // 🚀 NEW METHOD: Fetch Categories from Database
    // =====================================================================
    private void loadCategories() {
        listModel.clear(); // Clear the old mockup data
        List<DatabaseManager.Category> categories = dao.getAllCategories();
        
        for (DatabaseManager.Category c : categories) {
            listModel.addElement(c); // Automatically uses the toString() method to show the name
        }
    }

    // Custom Button Stylizer
    private JButton createActionButton(String text) {
        JButton btn = new JButton(text);
        btn.setPreferredSize(new Dimension(140, 45));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(CRIMSON);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(CRIMSON_DARK, 2));
        
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON_SOFT); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(CRIMSON); }
        });
        return btn;
    }
}