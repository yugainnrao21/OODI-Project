package product; // Adjust this if Nuriz's package is named something else

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseManager combined class for the Product Management module.
 */
public class DatabaseManager {

    // ==========================================================
    // CONNECTION SETUP (FIXED TO MATCH bakery_db)
    // ==========================================================
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bakery_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // Left blank for XAMPP default
    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                System.out.println("Database connected successfully.");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ==========================================================
    // ENTITY: Category
    // ==========================================================
    public static class Category {
        private int categoryID;
        private String name;

        public Category() {}
        public Category(int categoryID, String name) {
            this.categoryID = categoryID;
            this.name = name;
        }
        public Category(String name) {
            this.name = name;
        }

        public int getCategoryID() { return categoryID; }
        public void setCategoryID(int categoryID) { this.categoryID = categoryID; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        @Override
        public String toString() {
            return name; // Useful for displaying directly in a JComboBox
        }
    }

    // ==========================================================
    // ENTITY: Product
    // ==========================================================
    public static class Product {
        private int productID;
        private String name;
        private String description;
        private double price;
        private int quantity;
        private int categoryID;
        private String categoryName;

        public Product() {}

        public Product(int productID, String name, String description, double price, int quantity, int categoryID) {
            this.productID = productID;
            this.name = name;
            this.description = description;
            this.price = price;
            this.quantity = quantity;
            this.categoryID = categoryID;
        }

        public Product(String name, String description, double price, int quantity, int categoryID) {
            this.name = name;
            this.description = description;
            this.price = price;
            this.quantity = quantity;
            this.categoryID = categoryID;
        }

        public int getProductID() { return productID; }
        public void setProductID(int productID) { this.productID = productID; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
        public int getCategoryID() { return categoryID; }
        public void setCategoryID(int categoryID) { this.categoryID = categoryID; }
        public String getCategoryName() { return categoryName; }
        public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

        @Override
        public String toString() {
            return name;
        }
    }

    // ==========================================================
    // DAO: ProductDAO (CRUD logic for tables)
    // ==========================================================
    public static class ProductDAO {
        private Connection conn;

        public ProductDAO() {
            this.conn = DatabaseManager.getConnection();
        }

        // --- CATEGORY ---
        public boolean addCategory(String name) {
            String sql = "INSERT INTO Category (name) VALUES (?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Add category failed: " + e.getMessage());
                return false;
            }
        }

        public boolean renameCategory(int categoryID, String newName) {
            String sql = "UPDATE Category SET name = ? WHERE categoryID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, newName);
                ps.setInt(2, categoryID);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Rename category failed: " + e.getMessage());
                return false;
            }
        }

        public boolean deleteCategory(int categoryID) {
            if (checkLinkedProducts(categoryID)) {
                System.out.println("Cannot delete: category still has linked products.");
                return false;
            }
            String sql = "DELETE FROM Category WHERE categoryID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, categoryID);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Delete category failed: " + e.getMessage());
                return false;
            }
        }

        public boolean checkLinkedProducts(int categoryID) {
            String sql = "SELECT COUNT(*) FROM Product WHERE categoryID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, categoryID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1) > 0;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        public List<Category> getAllCategories() {
            List<Category> list = new ArrayList<>();
            String sql = "SELECT * FROM Category ORDER BY name";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Category(rs.getInt("categoryID"), rs.getString("name")));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        // --- PRODUCT ---
        public boolean addProduct(Product p, int threshold) {
            String sql = "INSERT INTO Product (name, description, price, quantity, categoryID) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, p.getName());
                ps.setString(2, p.getDescription());
                ps.setDouble(3, p.getPrice());
                ps.setInt(4, p.getQuantity());
                ps.setInt(5, p.getCategoryID());

                int rows = ps.executeUpdate();
                if (rows > 0) {
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) {
                            int newProductID = keys.getInt(1);
                            setStockThreshold(newProductID, threshold);
                        }
                    }
                    return true;
                }
            } catch (SQLException e) {
                System.out.println("Add product failed: " + e.getMessage());
            }
            return false;
        }

        public boolean updateProduct(Product p) {
            Product old = getProduct(p.getProductID());
            if (old == null) return false;

            String sql = "UPDATE Product SET name=?, description=?, price=?, quantity=?, categoryID=? WHERE productID=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getName());
                ps.setString(2, p.getDescription());
                ps.setDouble(3, p.getPrice());
                ps.setInt(4, p.getQuantity());
                ps.setInt(5, p.getCategoryID());
                ps.setInt(6, p.getProductID());

                boolean success = ps.executeUpdate() > 0;
                if (success) {
                    if (!old.getName().equals(p.getName()))
                        logChange(p.getProductID(), "name", old.getName(), p.getName());
                    if (old.getPrice() != p.getPrice())
                        logChange(p.getProductID(), "price", String.valueOf(old.getPrice()), String.valueOf(p.getPrice()));
                    if (old.getQuantity() != p.getQuantity())
                        logChange(p.getProductID(), "quantity", String.valueOf(old.getQuantity()), String.valueOf(p.getQuantity()));
                }
                return success;
            } catch (SQLException e) {
                System.out.println("Update product failed: " + e.getMessage());
                return false;
            }
        }

        public boolean removeProduct(int productID) {
            if (checkActiveOrders(productID)) {
                System.out.println("Cannot delete: product is linked to a pending order.");
                return false;
            }
            String sql = "DELETE FROM Product WHERE productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Remove product failed: " + e.getMessage());
                return false;
            }
        }

        public boolean checkActiveOrders(int productID) {
            String sql = "SELECT COUNT(*) FROM OrderItem oi JOIN SalesOrder so ON oi.orderID = so.orderID WHERE oi.productID = ? AND so.status = 'pending'";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1) > 0;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        public List<Product> getAllProducts() {
            List<Product> list = new ArrayList<>();
            String sql = "SELECT p.*, c.name AS categoryName FROM Product p JOIN Category c ON p.categoryID = c.categoryID ORDER BY p.name";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRowToProduct(rs));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        public Product getProduct(int productID) {
            String sql = "SELECT p.*, c.name AS categoryName FROM Product p JOIN Category c ON p.categoryID = c.categoryID WHERE p.productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return mapRowToProduct(rs);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }

        public List<Product> searchProduct(String keyword) {
            if (keyword == null || keyword.trim().isEmpty()) {
                return getAllProducts();
            }
            List<Product> list = new ArrayList<>();
            String sql = "SELECT p.*, c.name AS categoryName FROM Product p JOIN Category c ON p.categoryID = c.categoryID WHERE p.name LIKE ? OR c.name LIKE ? OR p.productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                String likeTerm = "%" + keyword + "%";
                ps.setString(1, likeTerm);
                ps.setString(2, likeTerm);

                int idSearch = -1;
                try { idSearch = Integer.parseInt(keyword.trim()); } catch (NumberFormatException ignored) {}
                ps.setInt(3, idSearch);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapRowToProduct(rs));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        public boolean checkDuplicate(String name) {
            String sql = "SELECT COUNT(*) FROM Product WHERE name = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1) > 0;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        private Product mapRowToProduct(ResultSet rs) throws SQLException {
            Product p = new Product(
                rs.getInt("productID"),
                rs.getString("name"),
                rs.getString("description"),
                rs.getDouble("price"),
                rs.getInt("quantity"),
                rs.getInt("categoryID")
            );
            p.setCategoryName(rs.getString("categoryName"));
            return p;
        }

        // --- STOCK THRESHOLD ---
        public boolean setStockThreshold(int productID, int threshold) {
            String sql = "INSERT INTO StockThreshold (productID, threshold) VALUES (?, ?) ON DUPLICATE KEY UPDATE threshold = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                ps.setInt(2, threshold);
                ps.setInt(3, threshold);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        public int getStockThreshold(int productID) {
            String sql = "SELECT threshold FROM StockThreshold WHERE productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt("threshold");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return 10;
        }

        public boolean updateStock(int productID, int qtyChange) {
            String sql = "UPDATE Product SET quantity = quantity + ? WHERE productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, qtyChange);
                ps.setInt(2, productID);

                boolean success = ps.executeUpdate() > 0;
                if (success) {
                    int newLevel = getProduct(productID).getQuantity();
                    int threshold = getStockThreshold(productID);
                    if (newLevel <= threshold) {
                        triggerAlert(productID, newLevel);
                    } else {
                        autoDismissAlert(productID);
                    }
                }
                return success;
            } catch (SQLException e) {
                System.out.println("Update stock failed: " + e.getMessage());
                return false;
            }
        }

        // --- ALERT RECORD ---
        public boolean triggerAlert(int productID, int stockLevel) {
            if (hasActiveAlert(productID)) {
                return false;
            }
            String sql = "INSERT INTO AlertRecord (productID, stockLevel, status) VALUES (?, ?, 'active')";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                ps.setInt(2, stockLevel);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.out.println("Trigger alert failed: " + e.getMessage());
                return false;
            }
        }

        private boolean hasActiveAlert(int productID) {
            String sql = "SELECT COUNT(*) FROM AlertRecord WHERE productID = ? AND status = 'active'";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1) > 0;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        public boolean dismissAlert(int alertID) {
            String sql = "UPDATE AlertRecord SET status = 'read' WHERE alertID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, alertID);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        public boolean autoDismissAlert(int productID) {
            String sql = "UPDATE AlertRecord SET status = 'auto dismissed' WHERE productID = ? AND status = 'active'";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        public List<String> getActiveAlerts() {
            List<String> alerts = new ArrayList<>();
            String sql = "SELECT ar.alertID, p.name, ar.stockLevel, ar.createdAt FROM AlertRecord ar JOIN Product p ON ar.productID = p.productID WHERE ar.status = 'active' ORDER BY ar.createdAt DESC";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    alerts.add(String.format("[Alert #%d] %s stock at %d", rs.getInt("alertID"), rs.getString("name"), rs.getInt("stockLevel")));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return alerts;
        }

        // --- SALES ORDER / ORDER ITEM ---
        public int createTestOrder(int productID, int quantity, double unitPrice) {
            String orderSql = "INSERT INTO SalesOrder (status) VALUES ('pending')";
            String itemSql = "INSERT INTO OrderItem (orderID, productID, quantity, unitPrice) VALUES (?, ?, ?, ?)";

            try (PreparedStatement psOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                psOrder.executeUpdate();
                try (ResultSet keys = psOrder.getGeneratedKeys()) {
                    if (keys.next()) {
                        int orderID = keys.getInt(1);
                        try (PreparedStatement psItem = conn.prepareStatement(itemSql)) {
                            psItem.setInt(1, orderID);
                            psItem.setInt(2, productID);
                            psItem.setInt(3, quantity);
                            psItem.setDouble(4, unitPrice);
                            psItem.executeUpdate();
                        }
                        return orderID;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return -1;
        }

        // --- PRODUCT AUDIT LOG ---
        private void logChange(int productID, String field, String oldValue, String newValue) {
            String sql = "INSERT INTO ProductAuditLog (productID, changedField, oldValue, newValue) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                ps.setString(2, field);
                ps.setString(3, oldValue);
                ps.setString(4, newValue);
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public List<String> getAuditLog(int productID) {
            List<String> logs = new ArrayList<>();
            String sql = "SELECT * FROM ProductAuditLog WHERE productID = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        logs.add(String.format("[%s] %s: '%s' -> '%s'",
                            rs.getTimestamp("changedAt"),
                            rs.getString("changedField"),
                            rs.getString("oldValue"),
                            rs.getString("newValue")));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return logs;
        }
    }
}