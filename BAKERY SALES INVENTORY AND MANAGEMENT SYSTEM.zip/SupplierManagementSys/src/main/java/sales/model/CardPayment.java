package sales.model;

/**
 * Card payment (credit/debit). Charges a small 1.5% processing fee.
 * Overrides PaymentMethod to provide card-specific behaviour.
 */
public class CardPayment implements PaymentMethod {

    @Override
    public double getProcessingFee(double amount) {
        return amount * 0.015;
    }

    @Override
    public String getDescription() {
        return "Credit/Debit Card";
    }
}
