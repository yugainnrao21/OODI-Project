package sales.model;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class Order {
    private int orderID;
    private int customerID;
    private Date orderDate;
    private double total;
    private String status;
    private String shippingAddress;
    private List<CartItem> orderItems;
    private static int nextID = 1000;

    // Original Constructor (used for creating NEW orders from the cart)
    public Order(int customerID, double total, String shippingAddress, List<CartItem> items) {
        this.orderID = nextID++;
        this.customerID = customerID;
        this.orderDate = new Date();
        this.total = total;
        this.status = "Pending";
        this.shippingAddress = shippingAddress;
        this.orderItems = new ArrayList<>(items);
    }

    // NEW Constructor (used by OrderDB to load EXISTING orders from the database)
    public Order(int orderID, int customerID, double total, String shippingAddress, List<CartItem> items) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.total = total;
        this.shippingAddress = shippingAddress;
        this.orderItems = new ArrayList<>(items);
        this.status = "Pending"; // Default, usually overwritten by setStatus later
    }

    public void checkout() { this.status = "Processing"; }
    public void confirmOrder() { this.status = "Confirmed"; }

    // --- Getters ---
    public int getOrderID() { return orderID; }
    public int getCustomerID() { return customerID; }
    public Date getOrderDate() { return orderDate; }
    public double getTotal() { return total; }
    public String getStatus() { return status; }
    public String getShippingAddress() { return shippingAddress; }
    public List<CartItem> getOrderItems() { return orderItems; }

    // --- Setters (Required for Database loading) ---
    public void setStatus(String status) { this.status = status; }
    public void setOrderID(int orderID) { this.orderID = orderID; }
    public void setOrderDate(Date orderDate) { this.orderDate = orderDate; }
    public void setOrderItems(List<CartItem> orderItems) { this.orderItems = orderItems; }
}