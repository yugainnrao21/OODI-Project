package sales.model;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class Order {
    private int orderID;
    private int customerID;
    private Date orderDate;
    private double total;
    private String status;
    private String shippingAddress;
    private List<CartItem> orderItems;
    private static int nextID = 1000;

    public Order(int customerID, double total, String shippingAddress, List<CartItem> items) {
        this.orderID = nextID++;
        this.customerID = customerID;
        this.orderDate = new Date();
        this.total = total;
        this.status = "Pending";
        this.shippingAddress = shippingAddress;
        this.orderItems = new ArrayList<>(items);
    }

    public void checkout() { this.status = "Processing"; }
    public void confirmOrder() { this.status = "Confirmed"; }

    public int getOrderID() { return orderID; }
    public int getCustomerID() { return customerID; }
    public Date getOrderDate() { return orderDate; }
    public double getTotal() { return total; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getShippingAddress() { return shippingAddress; }
    public List<CartItem> getOrderItems() { return orderItems; }
}
