package sales.model;

/**
 * Abstraction for the different ways a Customer can pay for an Order.
 * Each concrete payment type implements its own processing fee and
 * description, demonstrating polymorphic behaviour when called through
 * this common interface (e.g. PaymentMethod m = new CardPayment(); m.getDescription();).
 */
public interface PaymentMethod {
    double getProcessingFee(double amount);
    String getDescription();
}
