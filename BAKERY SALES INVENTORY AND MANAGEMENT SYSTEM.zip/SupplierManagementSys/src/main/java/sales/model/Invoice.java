package sales.model;

import java.util.Date;

public class Invoice {
    private int invoiceID;
    private int orderID;
    private Date issueDate;
    private String pdfPath;
    private static int nextID = 9000;

    public Invoice(int orderID) {
        this.invoiceID = nextID++;
        this.orderID = orderID;
        this.issueDate = new Date();
        this.pdfPath = "invoice_" + invoiceID + ".pdf";
    }

    public void generate() {
        // In real app would generate PDF
        System.out.println("Invoice " + invoiceID + " generated.");
    }

    public void sendViaEmail(String email) {
        System.out.println("Invoice sent to " + email);
    }

    public String getDownloadLink() {
        return pdfPath;
    }

    public int getInvoiceID() { return invoiceID; }
    public int getOrderID() { return orderID; }
    public Date getIssueDate() { return issueDate; }
    public String getPdfPath() { return pdfPath; }
}
