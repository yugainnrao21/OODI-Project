package sales.model;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private int customerID;
    private String name;
    private String email;
    private String address;

    public Customer(int customerID, String name, String email, String address) {
        this.customerID = customerID;
        this.name = name;
        this.email = email;
        this.address = address;
    }

    public int getCustomerID() { return customerID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public List<Product> browseProducts() {
        return new ArrayList<>();
    }
}
