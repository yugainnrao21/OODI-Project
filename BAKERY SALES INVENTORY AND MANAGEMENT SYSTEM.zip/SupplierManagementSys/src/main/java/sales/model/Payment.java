package sales.model;

public class Payment {
    private int paymentID;
    private int orderID;
    private String method;
    private double amount;
    private String status;
    private static int nextID = 5000;

    public Payment(int orderID, String method, double amount) {
        this.paymentID = nextID++;
        this.orderID = orderID;
        this.method = method;
        this.amount = amount;
        this.status = "Pending";
    }

    public boolean processPayment(String details) {
        // Simulate payment processing
        if (details != null && !details.trim().isEmpty()) {
            this.status = "Paid";
            return true;
        }
        this.status = "Failed";
        return false;
    }

    public int getPaymentID() { return paymentID; }
    public int getOrderID() { return orderID; }
    public String getMethod() { return method; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }
}
