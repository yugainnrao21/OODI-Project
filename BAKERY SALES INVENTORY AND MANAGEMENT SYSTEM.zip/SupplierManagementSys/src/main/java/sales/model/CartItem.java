package sales.model;

public class CartItem {
    private int cartItemID;
    private int cartID;
    private int productID;
    private int quantity;
    private double subtotal;
    private String productName;
    private double unitPrice;

    // Original Constructor (Used for active shopping carts)
    public CartItem(int cartItemID, int cartID, Product product, int quantity) {
        this.cartItemID = cartItemID;
        this.cartID = cartID;
        this.productID = product.getProductID();
        this.productName = product.getName();
        this.unitPrice = product.getPrice();
        this.quantity = quantity;
        this.subtotal = unitPrice * quantity;
    }

    // NEW Constructor (Used by OrderDB to load historical order items)
    public CartItem(int productID, String productName, double unitPrice, int quantity) {
        this.productID = productID;
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.subtotal = unitPrice * quantity;
        // cartItemID and cartID remain default (0) because historical orders don't use them
    }

    public int getCartItemID() { return cartItemID; }
    public int getCartID() { return cartID; }
    public int getProductID() { return productID; }
    public String getProductName() { return productName; }
    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }
    public double getSubtotal() { return subtotal; }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.subtotal = unitPrice * quantity;
    }
}