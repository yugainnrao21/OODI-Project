package sales.model;

public class CartItem {
    private int cartItemID;
    private int cartID;
    private int productID;
    private int quantity;
    private double subtotal;
    private String productName;
    private double unitPrice;

    public CartItem(int cartItemID, int cartID, Product product, int quantity) {
        this.cartItemID = cartItemID;
        this.cartID = cartID;
        this.productID = product.getProductID();
        this.productName = product.getName();
        this.unitPrice = product.getPrice();
        this.quantity = quantity;
        this.subtotal = unitPrice * quantity;
    }

    public int getCartItemID() { return cartItemID; }
    public int getCartID() { return cartID; }
    public int getProductID() { return productID; }
    public String getProductName() { return productName; }
    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }
    public double getSubtotal() { return subtotal; }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.subtotal = unitPrice * quantity;
    }
}
