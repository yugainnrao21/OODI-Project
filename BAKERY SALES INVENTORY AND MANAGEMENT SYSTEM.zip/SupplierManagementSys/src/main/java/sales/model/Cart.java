package sales.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private int cartID;
    private int customerID;
    private double total;
    private List<CartItem> items;
    private double discountAmount;
    private String appliedCode;

    public Cart(int cartID, int customerID) {
        this.cartID = cartID;
        this.customerID = customerID;
        this.total = 0.0;
        this.items = new ArrayList<>();
        this.discountAmount = 0.0;
    }

    public void addItem(Product product, int qty) {
        for (CartItem item : items) {
            if (item.getProductID() == product.getProductID()) {
                item.setQuantity(item.getQuantity() + qty);
                recalculateTotal();
                return;
            }
        }
        CartItem newItem = new CartItem(items.size() + 1, cartID, product, qty);
        items.add(newItem);
        recalculateTotal();
    }

    public void removeItem(int productID) {
        items.removeIf(item -> item.getProductID() == productID);
        recalculateTotal();
    }

    public boolean applyDiscountCode(String code) {
        double discount = DiscountService.validateCode(code);
        if (discount > 0) {
            this.discountAmount = total * discount;
            this.appliedCode = code;
            recalculateTotal();
            return true;
        }
        return false;
    }

    public double recalculateTotal() {
        double raw = 0;
        for (CartItem item : items) {
            raw += item.getSubtotal();
        }
        total = raw - discountAmount;
        return total;
    }

    public int getCartID() { return cartID; }
    public int getCustomerID() { return customerID; }
    public double getTotal() { return total; }
    public List<CartItem> getItems() { return items; }
    public double getDiscountAmount() { return discountAmount; }
    public String getAppliedCode() { return appliedCode; }

    public double getRawTotal() {
        double raw = 0;
        for (CartItem item : items) raw += item.getSubtotal();
        return raw;
    }

    public void updateItemQty(int productID, int newQty) {
        for (CartItem item : items) {
            if (item.getProductID() == productID) {
                item.setQuantity(newQty);
                recalculateTotal();
                return;
            }
        }
    }
}
