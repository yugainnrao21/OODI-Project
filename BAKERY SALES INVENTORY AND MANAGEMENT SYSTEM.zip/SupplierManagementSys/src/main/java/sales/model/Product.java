package sales.model;

public class Product {
    private int productID;
    private String name;
    private String category;
    private double price;
    private int stockQuantity;
    private String description;

    public Product(int productID, String name, String category, double price, int stockQuantity, String description) {
        this.productID = productID;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.description = description;
    }

    public int getProductID() { return productID; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public int getStockQuantity() { return stockQuantity; }
    public String getDescription() { return description; }
    public void setStockQuantity(int qty) { this.stockQuantity = qty; }

    @Override
    public String toString() { return name; }
}
