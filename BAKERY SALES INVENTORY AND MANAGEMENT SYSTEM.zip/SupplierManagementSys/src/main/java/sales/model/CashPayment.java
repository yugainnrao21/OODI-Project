package sales.model;

/**
 * Cash on Delivery payment. No processing fee is charged.
 * Overrides PaymentMethod to provide cash-specific behaviour, demonstrating
 * polymorphism alongside CardPayment (same interface, different results).
 */
public class CashPayment implements PaymentMethod {

    @Override
    public double getProcessingFee(double amount) {
        return 0.0;
    }

    @Override
    public String getDescription() {
        return "Cash on Delivery";
    }
}
