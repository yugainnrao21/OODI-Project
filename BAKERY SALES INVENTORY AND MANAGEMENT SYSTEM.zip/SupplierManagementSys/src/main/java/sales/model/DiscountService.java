package sales.model;

import java.util.HashMap;
import java.util.Map;

public class DiscountService {
    // code -> discount fraction
    private static final Map<String, Double> VALID_CODES = new HashMap<>();

    static {
        VALID_CODES.put("SAVE10", 0.10);
        VALID_CODES.put("SAVE20", 0.20);
        VALID_CODES.put("WELCOME", 0.15);
    }

    public static double validateCode(String code) {
        return VALID_CODES.getOrDefault(code.toUpperCase(), 0.0);
    }

    public static boolean checkExpiry(String code) {
        return VALID_CODES.containsKey(code.toUpperCase());
    }

    public static boolean checkMinSpend(String code, double amount) {
        return amount >= 10.0; // minimum RM10
    }
}
