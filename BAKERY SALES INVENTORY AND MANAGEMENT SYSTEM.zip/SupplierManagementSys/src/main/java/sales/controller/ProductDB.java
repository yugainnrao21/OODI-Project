package sales.controller;

import sales.model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane; 

public class ProductDB {
    
    // Connect directly to the unified project database!
    private static final String URL = "jdbc:mysql://localhost:3306/bakery_db";
    private static final String USER = "root";
    private static final String PASS = "";

    // 1. Fetch live data from Nuriz's Product table using a JOIN
    public static List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        
        // 🚨 THE FINAL SQL JOIN QUERY 🚨
        // We link the Product table (p) to the Category table (c) using categoryID
        String query = "SELECT p.productID, p.name, c.name AS category, p.price, p.quantity, p.description " +
                       "FROM Product p " +
                       "JOIN Category c ON p.categoryID = c.categoryID";
        
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                // Creates the Product using live data from bakery_db
                products.add(new Product(
                    rs.getInt("productID"),
                    rs.getString("name"),
                    rs.getString("category"), // This now perfectly pulls the real category text!
                    rs.getDouble("price"),
                    rs.getInt("quantity"), // Pulling real stock!
                    rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // THE DEBUG TRAP
            JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage(), "SQL Error Trap", JOptionPane.ERROR_MESSAGE);
        }
        return products;
    }

    // 2. Filter logic now uses the live database list
    public static List<Product> getAvailableProducts() {
        List<Product> available = new ArrayList<>();
        for (Product p : getAllProducts()) { 
            if (p.getStockQuantity() > 0) available.add(p);
        }
        return available;
    }

    // 3. Search logic now uses the live database list
    public static List<Product> filterProducts(String category, String keyword) {
        List<Product> result = new ArrayList<>();
        for (Product p : getAllProducts()) {
            boolean catMatch = category == null || category.equals("All") || p.getCategory().equals(category);
            boolean kwMatch  = keyword == null || keyword.isEmpty()
                    || p.getName().toLowerCase().contains(keyword.toLowerCase());
            if (catMatch && kwMatch && p.getStockQuantity() > 0) result.add(p);
        }
        return result;
    }

    public static int checkStock(int productID) {
        for (Product p : getAllProducts()) {
            if (p.getProductID() == productID) return p.getStockQuantity();
        }
        return 0;
    }

    public static void deductStock(int productID, int qty) {
        // Reroute this old method to the new unified ProductDAO just to be safe!
        product.DatabaseManager.ProductDAO pDao = new product.DatabaseManager.ProductDAO();
        pDao.updateStock(productID, -qty);
    }
}