package sales.controller;

import sales.model.Order;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDB {
    
    // Connect to your unified project database
    private static final String URL = "jdbc:mysql://localhost:3306/bakery_db";
    private static final String USER = "root";
    private static final String PASS = ""; 

    // + saveOrder(Order order) : void --> UPGRADED TO DATABASE LOGIC
    public static void saveOrder(Order order) {
        // We use your unified tables: SalesOrder and OrderItem
        String sqlOrder = "INSERT INTO SalesOrder (orderID, status, createdAt) VALUES (?, ?, NOW())";
        String sqlItems = "INSERT INTO OrderItem (poNumber, itemName, quantity, unitPrice) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            // Turn off auto-commit so we can save the order AND update stock safely
            conn.setAutoCommit(false); 

            // 1. Save the main order record
            try (PreparedStatement psOrder = conn.prepareStatement(sqlOrder)) {
                psOrder.setInt(1, order.getOrderID());
                psOrder.setString(2, "Completed"); // Force status to Completed for successful checkout
                psOrder.executeUpdate();
            }

            // 2. THE BRIDGE: Setup Nuriz's ProductDAO to handle the inventory deduction
            product.DatabaseManager.ProductDAO pDao = new product.DatabaseManager.ProductDAO();

            // 3. Loop through the items in the cart, save them, and deduct stock
            try (PreparedStatement psItem = conn.prepareStatement(sqlItems)) {
                
                // (You may need to change 'getItems()' to match Aitish's actual cart list method)
                // Loop through the items in the cart, save them, and deduct stock
            for (var item : order.getOrderItems()) { 
    
    // Save to OrderItem table
                  psItem.setString(1, String.valueOf(order.getOrderID())); 
                  psItem.setString(2, item.getProductName()); 
                  psItem.setInt(3, item.getQuantity());       
                  psItem.setDouble(4, item.getUnitPrice()); // FIXED: using getUnitPrice()!      
                  psItem.executeUpdate();

    // 💥 THE INVENTORY RESTOCK MAGIC (DEDUCTION) 💥
    // Subtract the sold quantity from Nuriz's Product table!
    pDao.updateStock(item.getProductID(), -item.getQuantity());
}
            }

            // Commit the transaction to the database
            conn.commit();
            System.out.println("Sale successfully integrated into bakery_db!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to save order to bakery_db.");
        }
    }

    // + getOrdersByCustomer(int customerID) : List
    public static List<Order> getOrdersByCustomer(int customerID) {
        // Optional: Implement SELECT from SalesOrder if needed for his UI
        return new ArrayList<>(); 
    }

    // + getOrderByID(int orderID) : Order
    public static Order getOrderByID(int orderID) {
        // Optional: Implement SELECT from SalesOrder if needed for his UI
        return null;
    }
}