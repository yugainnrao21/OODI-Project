package sales.controller;

import sales.model.CartItem;
import sales.model.Order;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class OrderDB {

    // Make sure these match your database credentials!
    private static final String URL = "jdbc:mysql://localhost:3306/bakery_db";
    private static final String USER = "root";
    private static final String PASS = "";

    // 1. Save the Order to the new salesorder & salesorderitem tables
    public static boolean saveOrder(Order order) {
        String insertOrder = "INSERT INTO salesorder (customerID, total, shippingAddress, status) VALUES (?, ?, ?, ?)";
        String insertItem = "INSERT INTO salesorderitem (orderID, productID, quantity, unitPrice) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            // Turn off auto-commit so we can safely insert into two tables at once
            conn.setAutoCommit(false); 

            // Step A: Insert the main order
            try (PreparedStatement psOrder = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS)) {
                psOrder.setInt(1, order.getCustomerID());
                psOrder.setDouble(2, order.getTotal());
                psOrder.setString(3, order.getShippingAddress());
                psOrder.setString(4, order.getStatus());
                psOrder.executeUpdate();

                // Step B: Get the new orderID that MySQL just created
                ResultSet rs = psOrder.getGeneratedKeys();
                if (rs.next()) {
                    int newOrderID = rs.getInt(1);
                    order.setOrderID(newOrderID); 

                    // Step C: Insert every item from the cart into salesorderitem
                    try (PreparedStatement psItem = conn.prepareStatement(insertItem)) {
                        for (CartItem item : order.getOrderItems()) {
                            psItem.setInt(1, newOrderID);
                            psItem.setInt(2, item.getProductID());
                            psItem.setInt(3, item.getQuantity());
                            psItem.setDouble(4, item.getUnitPrice());
                            psItem.addBatch(); // Batch them for performance
                        }
                        psItem.executeBatch();
                    }
                }
                conn.commit(); // Save everything!
                return true;
            } catch (SQLException e) {
                conn.rollback(); // If something fails, undo it so we don't get partial data
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Error Saving Order: " + e.getMessage());
        }
        return false;
    }

    // 2. Fetch the orders for the History Screen
    public static List<Order> getOrdersByCustomer(int customerID) {
        List<Order> list = new ArrayList<>();
        String query = "SELECT * FROM salesorder WHERE customerID = ? ORDER BY createdAt ASC"; // ASC so BakeryApp can reverse it
        
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(query)) {
             
             ps.setInt(1, customerID);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()) {
                 Order o = new Order(
                     rs.getInt("orderID"), 
                     rs.getInt("customerID"), 
                     rs.getDouble("total"), 
                     rs.getString("shippingAddress"), 
                     new ArrayList<>() // Empty list for now, filled when clicked
                 );
                 o.setStatus(rs.getString("status"));
                 o.setOrderDate(rs.getTimestamp("createdAt"));
                 list.add(o);
             }
        } catch(SQLException e) { 
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Error Loading History: " + e.getMessage());
        }
        return list;
    }

    // 3. Fetch specific order details when a row is clicked
    public static Order getOrderByID(int orderID) {
        Order order = null;
        String qOrder = "SELECT * FROM salesorder WHERE orderID = ?";
        // JOIN allows us to get the real product name from the product table!
        String qItems = "SELECT si.*, p.name FROM salesorderitem si JOIN product p ON si.productID = p.productID WHERE si.orderID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            // Get main order info
            try (PreparedStatement ps1 = conn.prepareStatement(qOrder)) {
                ps1.setInt(1, orderID);
                ResultSet rs1 = ps1.executeQuery();
                if(rs1.next()) {
                     order = new Order(rs1.getInt("orderID"), rs1.getInt("customerID"), rs1.getDouble("total"), rs1.getString("shippingAddress"), new ArrayList<>());
                     order.setStatus(rs1.getString("status"));
                     order.setOrderDate(rs1.getTimestamp("createdAt"));
                }
            }
            
            // Get the line items
            if(order != null) {
                try (PreparedStatement ps2 = conn.prepareStatement(qItems)) {
                    ps2.setInt(1, orderID);
                    ResultSet rs2 = ps2.executeQuery();
                    List<CartItem> items = new ArrayList<>();
                    while(rs2.next()) {
                        items.add(new CartItem(
                            rs2.getInt("productID"),
                            rs2.getString("name"),
                            rs2.getDouble("unitPrice"),
                            rs2.getInt("quantity")
                        ));
                    }
                    order.setOrderItems(items);
                }
            }
        } catch(SQLException e) { 
            e.printStackTrace(); 
        }
        return order;
    }
}