package sales.controller;

import sales.model.CardPayment;
import sales.model.CartItem;
import sales.model.CashPayment;
import sales.model.Invoice;
import sales.model.Order;
import sales.model.Payment;
import sales.model.PaymentMethod;

import java.util.List;

/**
 * Factory Design Pattern implementation for the Sales & Order Processing
 * module. Centralises the creation of Order, Payment and Invoice objects
 * so the UI layer never calls "new Order(...)" / "new Payment(...)" /
 * "new Invoice(...)" directly. This keeps object-creation logic in one
 * place and makes it easy to extend (e.g. adding a new payment method)
 * without changing the panels that use these objects.
 */
public class BakeryComponentFactory {

    /** Creates a new Order using the same fields the system already collects. */
    public static Order createOrder(int customerID, double total, String shippingAddress, List<CartItem> items) {
        return new Order(customerID, total, shippingAddress, items);
    }

    /** Creates a new Payment record for the given order and method. */
    public static Payment createPayment(int orderID, String method, double amount) {
        return new Payment(orderID, method, amount);
    }

    /** Creates a new Invoice linked to the given order. */
    public static Invoice createInvoice(int orderID) {
        return new Invoice(orderID);
    }

    /**
     * Resolves the human-readable payment method name selected in the UI
     * to a concrete PaymentMethod implementation. This is the polymorphic
     * piece of the factory: callers only depend on the PaymentMethod
     * interface, never on CardPayment/CashPayment directly.
     */
    public static PaymentMethod resolvePaymentMethod(String selectedMethod) {
        if ("Cash on Delivery".equals(selectedMethod)) {
            return new CashPayment();
        }
        return new CardPayment();
    }
}
