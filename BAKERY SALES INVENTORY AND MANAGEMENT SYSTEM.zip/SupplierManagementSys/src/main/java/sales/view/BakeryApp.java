package sales.view;

import sales.controller.OrderDB;
import sales.controller.ProductDB;
import sales.controller.BakeryComponentFactory;
import sales.model.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.List;
import view.MasterDashboard;

/**
 * BakeryApp.java
 * Main application for Module 3: Sales & Order Processing
 * Bakery Smart Inventory & Sales System – BCS2163
 */
public class BakeryApp extends JFrame {

    // ── Colour palette ────────────────────────────────────────────────────────
    static final Color CRIMSON      = new Color(139, 0,  28);
    static final Color CRIMSON_DARK = new Color(100, 0,  20);
    static final Color CRIMSON_SOFT = new Color(180, 30, 55);
    static final Color CREAM        = new Color(255, 248, 240);
    static final Color WHITE        = Color.WHITE;
    static final Color TEXT_DARK    = new Color(30,  10, 10);
    static final Color TEXT_LIGHT   = new Color(220, 200, 200);
    static final Color GOLD         = new Color(218, 165, 32);
    static final Color TABLE_ROW_A  = new Color(255, 245, 245);
    static final Color TABLE_ROW_B  = new Color(255, 255, 255);

    // ── Fonts ─────────────────────────────────────────────────────────────────
    static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD,  22);
    static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  14);
    static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // ── State ─────────────────────────────────────────────────────────────────
    private Customer currentCustomer;
    private Cart cart;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    // ── Screens ───────────────────────────────────────────────────────────────
    private BrowsePanel   browsePanel;
    private CartPanel     cartPanel;
    private CheckoutPanel checkoutPanel;
    private PaymentPanel  paymentPanel;
    private InvoicePanel  invoicePanel;
    private HistoryPanel  historyPanel;
    
    public BakeryApp() {
        currentCustomer = new Customer(1, "Siti Aminah", "siti@email.com", "123 Jalan Bakery, Pekan, Pahang");
        cart = new Cart(1, currentCustomer.getCustomerID());

        setTitle("Bakery Smart Inventory & Sales System – Sales & Order Processing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 700);
        setMinimumSize(new Dimension(880, 600));
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel  = new JPanel(cardLayout);

        browsePanel   = new BrowsePanel(this);
        cartPanel     = new CartPanel(this);
        checkoutPanel = new CheckoutPanel(this);
        paymentPanel  = new PaymentPanel(this);
        invoicePanel  = new InvoicePanel(this);
        historyPanel = new HistoryPanel(this);

        mainPanel.add(browsePanel,   "browse");
        mainPanel.add(cartPanel,     "cart");
        mainPanel.add(checkoutPanel, "checkout");
        mainPanel.add(paymentPanel,  "payment");
        mainPanel.add(invoicePanel,  "invoice");
        mainPanel.add(historyPanel,  "history");

        add(buildNavBar(), BorderLayout.NORTH);
        add(mainPanel,     BorderLayout.CENTER);

        showScreen("browse");

        // 1. Create the button
        JButton backButton = new JButton("< BACK TO MAIN DASHBOARD");

        // 2. Style it to be larger and more professional
        backButton.setPreferredSize(new Dimension(300, 50)); 
        backButton.setBackground(new Color(200, 180, 180)); 
        backButton.setForeground(new Color(139, 0, 0));     
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 16)); 
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backButton.setBorder(BorderFactory.createLineBorder(new Color(180, 130, 130), 2)); 

        // 3. Add the click action
        backButton.addActionListener(e -> {
            this.dispose(); 
            // Ensures it doesn't crash if MasterDashboard doesn't exist yet
            try {
                new view.MasterDashboard().setVisible(true); 
            } catch (Exception ex) {
                System.out.println("MasterDashboard not found, exiting.");
            }
        });

        // 4. Create a panel with generous padding (Top/Bottom)
        JPanel bottomNavPanel = new JPanel();
        bottomNavPanel.setBackground(CRIMSON);
        bottomNavPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 
        
        bottomNavPanel.add(backButton);

        // 5. Add to layout
        this.add(bottomNavPanel, BorderLayout.SOUTH);
    }

    // ── Navigation bar ────────────────────────────────────────────────────────
    private JPanel buildNavBar() {
        JPanel nav = new JPanel(new BorderLayout());
        nav.setBackground(CRIMSON_DARK);
        
        // ✨ THE GOLD LINE FIX ✨
        nav.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, GOLD));

        // Logo/title
        JLabel logo = new JLabel("  🍞  Bakery Sales System");
        logo.setFont(FONT_TITLE);
        logo.setForeground(WHITE);
        logo.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 0));
        nav.add(logo, BorderLayout.WEST);

        // Buttons
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 8));
        btns.setBackground(CRIMSON_DARK);
        btns.add(navBtn("Browse",  "browse"));
        btns.add(navBtn("🛒 Cart", "cart"));
        btns.add(navBtn("My Orders", "history"));
        nav.add(btns, BorderLayout.EAST);

        return nav;
    }

    private JButton navBtn(String text, String screen) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(WHITE);
        btn.setBackground(WHITE);
        btn.setForeground(CRIMSON);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CRIMSON_SOFT, 1),
                BorderFactory.createEmptyBorder(5, 14, 5, 14)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> {
            if (screen.equals("cart")) cartPanel.refresh();
            if (screen.equals("history")) getHistoryPanel().refresh();
            showScreen(screen);
        });
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(CRIMSON); btn.setForeground(WHITE); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(WHITE); btn.setForeground(CRIMSON); }
        });
        return btn;
    }

    private JPanel buildFooter() {
        JPanel foot = new JPanel(new BorderLayout());
        foot.setBackground(CRIMSON_DARK);
        foot.setBorder(BorderFactory.createEmptyBorder(4, 16, 4, 16));
        JLabel lbl = new JLabel("Module 3: Sales & Order Processing  |  BCS2163  |  Logged in: " + currentCustomer.getName());
        lbl.setFont(FONT_SMALL);
        lbl.setForeground(TEXT_LIGHT);
        foot.add(lbl, BorderLayout.WEST);
        return foot;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    void showScreen(String name) { cardLayout.show(mainPanel, name); }
    Customer getCustomer()       { return currentCustomer; }
    Cart     getCart()           { return cart; }
    HistoryPanel getHistoryPanel() { return historyPanel; }
    void resetCart()             { cart = new Cart(cart.getCartID() + 1, currentCustomer.getCustomerID()); }

    void goToCheckout() {
    checkoutPanel.refresh();
    SwingUtilities.invokeLater(() -> showScreen("checkout"));
    }
    void goToPayment(Order order) { paymentPanel.setOrder(order); showScreen("payment"); }
    void goToInvoice(Order order, Payment payment) {
        invoicePanel.setData(order, payment);
        showScreen("invoice");
    }

    // ── Utility: styled button ────────────────────────────────────────────────
    static JButton actionBtn(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setBackground(bg);
        btn.setForeground(WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bg.darker(), 1),
                BorderFactory.createEmptyBorder(7, 18, 7, 18)));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(bg.darker()); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(bg); }
        });
        return btn;
    }

    static JLabel sectionTitle(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_TITLE);
        lbl.setForeground(WHITE);
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        return lbl;
    }

    static JPanel headerPanel(String title) {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(CRIMSON);
        hdr.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        hdr.add(sectionTitle(title), BorderLayout.WEST);
        return hdr;
    }

    // ── Main ─────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new BakeryApp().setVisible(true));
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 1 – Browse Products (UC1 + UC2)
// ═════════════════════════════════════════════════════════════════════════════
class BrowsePanel extends JPanel {
    private BakeryApp app;
    private JTextField searchField;
    private JComboBox<String> categoryBox;
    private JPanel productGrid;
    private List<Product> products;
    
    BrowsePanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CREAM);

        // Header
        JPanel hdr = BakeryApp.headerPanel("🍰  Browse Products");
        JPanel filters = buildFilters();
        JPanel top = new JPanel(new BorderLayout());
        top.add(hdr, BorderLayout.NORTH);
        top.add(filters, BorderLayout.SOUTH);

        productGrid = new JPanel(new GridLayout(0, 3, 12, 12));
        productGrid.setBackground(BakeryApp.CREAM);
        productGrid.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JScrollPane scroll = new JScrollPane(productGrid);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        add(top,    BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        loadProducts("All", "");
    }

    private JPanel buildFilters() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        p.setBackground(BakeryApp.CRIMSON_DARK);

        JLabel catLbl = new JLabel("Category:");
        catLbl.setForeground(BakeryApp.WHITE);
        catLbl.setFont(BakeryApp.FONT_BODY);

        categoryBox = new JComboBox<>(new String[]{"All","Cakes","Pastries","Muffins","Bread","Tarts"});
        categoryBox.setFont(BakeryApp.FONT_BODY);
        categoryBox.setPreferredSize(new Dimension(130, 28));

        JLabel searchLbl = new JLabel("Search:");
        searchLbl.setForeground(BakeryApp.WHITE);
        searchLbl.setFont(BakeryApp.FONT_BODY);

        searchField = new JTextField(16);
        searchField.setFont(BakeryApp.FONT_BODY);

        JButton searchBtn = BakeryApp.actionBtn("Search", Color.WHITE);
        JButton clearBtn  = BakeryApp.actionBtn("Clear",  Color.WHITE);
        searchBtn.setForeground(BakeryApp.CRIMSON);
        clearBtn.setForeground(BakeryApp.CRIMSON);

        searchBtn.addActionListener(e -> applyFilter());
        clearBtn.addActionListener(e -> { searchField.setText(""); categoryBox.setSelectedIndex(0); loadProducts("All",""); });
        categoryBox.addActionListener(e -> applyFilter());

        p.add(catLbl); p.add(categoryBox);
        p.add(Box.createHorizontalStrut(10));
        p.add(searchLbl); p.add(searchField);
        p.add(searchBtn); p.add(clearBtn);
        return p;
    }

    private void applyFilter() {
        String cat = (String) categoryBox.getSelectedItem();
        String kw  = searchField.getText().trim();
        loadProducts(cat, kw);
    }

    private void loadProducts(String category, String keyword) {
        products = ProductDB.filterProducts(category, keyword);
        productGrid.removeAll();

        if (products.isEmpty()) {
            JLabel none = new JLabel("No products found.", SwingConstants.CENTER);
            none.setFont(BakeryApp.FONT_HEADER);
            none.setForeground(BakeryApp.CRIMSON);
            productGrid.setLayout(new BorderLayout());
            productGrid.add(none, BorderLayout.CENTER);
        } else {
            productGrid.setLayout(new GridLayout(0, 3, 12, 12));
            for (Product p : products) productGrid.add(buildProductCard(p));
        }
        productGrid.revalidate();
        productGrid.repaint();
    }

    private JPanel buildProductCard(Product p) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(BakeryApp.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 210, 2), 1),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));

        // Category tag
        JLabel catTag = new JLabel("  " + p.getCategory() + "  ");
        catTag.setFont(BakeryApp.FONT_SMALL);
        catTag.setForeground(BakeryApp.WHITE);
        catTag.setBackground(BakeryApp.CRIMSON);
        catTag.setOpaque(true);

        JLabel name  = new JLabel(p.getName());
        name.setFont(BakeryApp.FONT_HEADER);
        name.setForeground(BakeryApp.TEXT_DARK);

        JLabel desc  = new JLabel("<html><body style='width:150px'>" + p.getDescription() + "</body></html>");
        desc.setFont(BakeryApp.FONT_SMALL);
        desc.setForeground(new Color(100, 60, 60));

        JLabel price = new JLabel(String.format("RM %.2f", p.getPrice()));
        price.setFont(new Font("Segoe UI", Font.BOLD, 16));
        price.setForeground(BakeryApp.CRIMSON);

        JLabel stock = new JLabel("Stock: " + p.getStockQuantity());
        stock.setFont(BakeryApp.FONT_SMALL);
        stock.setForeground(p.getStockQuantity() <= 5 ? new Color(200,80,0) : new Color(0,130,0));

        // Qty spinner
        SpinnerNumberModel model = new SpinnerNumberModel(1, 1, p.getStockQuantity(), 1);
        JSpinner qtySpinner = new JSpinner(model);
        qtySpinner.setFont(BakeryApp.FONT_BODY);
        qtySpinner.setPreferredSize(new Dimension(65, 28));

        JButton addBtn = BakeryApp.actionBtn("+ Add to Cart", Color.WHITE);
        addBtn.setForeground(BakeryApp.CRIMSON);

        addBtn.addActionListener(e -> {
            int qty = (Integer) qtySpinner.getValue();
            int available = ProductDB.checkStock(p.getProductID());
            if (qty > available) {
                JOptionPane.showMessageDialog(this,
                        "Only " + available + " items available.", "Stock Limit",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }
            app.getCart().addItem(p, qty);
            JOptionPane.showMessageDialog(this,
                    "\"" + p.getName() + "\" (x" + qty + ") added to cart!", "Added",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel info = new JPanel();
        info.setBackground(BakeryApp.WHITE);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.add(catTag); info.add(Box.createVerticalStrut(4));
        info.add(name);   info.add(Box.createVerticalStrut(2));
        info.add(desc);   info.add(Box.createVerticalStrut(6));
        info.add(price);  info.add(stock);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        bottom.setBackground(BakeryApp.WHITE);
        JLabel qtyLbl = new JLabel("Qty:");
        qtyLbl.setFont(BakeryApp.FONT_BODY);
        bottom.add(qtyLbl); bottom.add(qtySpinner); bottom.add(addBtn);

        card.add(info,   BorderLayout.CENTER);
        card.add(bottom, BorderLayout.SOUTH);
        return card;
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 2 – Shopping Cart (UC3 + UC8) — matches Image 2
// ═════════════════════════════════════════════════════════════════════════════
class CartPanel extends JPanel {
    private BakeryApp app;
    private DefaultTableModel tableModel;
    private JTable cartTable;
    private JLabel totalLabel;
    private JLabel discountLabel;
    private JComboBox<String> productDropdown;
    private JTextField qtyField;
    private JTextField discountField;
    private JLabel discountMsg;

    CartPanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CRIMSON);

        add(BakeryApp.headerPanel("🛒  Shopping Cart"), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new BorderLayout(0, 0));
        body.setBackground(BakeryApp.CRIMSON);
        body.setBorder(BorderFactory.createEmptyBorder(14, 18, 0, 18));

        // ── Top controls (mirrors Image 2 exactly) ─────────────────────────
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        controls.setBackground(BakeryApp.CRIMSON);
        controls.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        JLabel prodLbl = new JLabel("Product : ");
        prodLbl.setFont(BakeryApp.FONT_BODY);
        prodLbl.setForeground(BakeryApp.WHITE);

        List<Product> products = ProductDB.getAvailableProducts();
        String[] names = new String[products.size()];
        for (int i = 0; i < products.size(); i++) names[i] = products.get(i).getName();
        productDropdown = new JComboBox<>(names);
        productDropdown.setFont(BakeryApp.FONT_BODY);
        productDropdown.setPreferredSize(new Dimension(150, 28));

        JLabel qtyLbl = new JLabel("  Quantity:");
        qtyLbl.setFont(BakeryApp.FONT_BODY);
        qtyLbl.setForeground(BakeryApp.WHITE);

        qtyField = new JTextField(6);
        qtyField.setFont(BakeryApp.FONT_BODY);
        qtyField.setText("1");

        controls.add(prodLbl); controls.add(productDropdown);
        controls.add(qtyLbl);  controls.add(qtyField);

        // Action buttons row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        btnRow.setBackground(BakeryApp.CRIMSON);

        JButton addBtn    = BakeryApp.actionBtn("[ + Add to Cart ]",     Color.WHITE);
        JButton updateBtn = BakeryApp.actionBtn("[ ~ Update Selected ]", Color.WHITE);
        JButton removeBtn = BakeryApp.actionBtn("[ - Remove Selected ]", Color.WHITE);
        
        addBtn.setForeground(BakeryApp.CRIMSON);
        updateBtn.setForeground(BakeryApp.CRIMSON);
        removeBtn.setForeground(BakeryApp.CRIMSON);
        addBtn.addActionListener(e -> addProductFromDropdown());
        updateBtn.addActionListener(e -> updateSelected());
        removeBtn.addActionListener(e -> removeSelected());

        btnRow.add(addBtn); btnRow.add(updateBtn); btnRow.add(removeBtn);

        JPanel topSection = new JPanel(new BorderLayout());
        topSection.setBackground(BakeryApp.CRIMSON);
        topSection.add(controls, BorderLayout.NORTH);
        topSection.add(btnRow,   BorderLayout.SOUTH);

        // ── Table ──────────────────────────────────────────────────────────
        String[] cols = {"Product Name", "Unit Price", "Quantity", "Subtotal"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        cartTable = new JTable(tableModel);
        cartTable.setFont(BakeryApp.FONT_BODY);
        cartTable.setRowHeight(28);
        cartTable.setGridColor(new Color(220, 200, 200));
        cartTable.setSelectionBackground(new Color(200, 50, 70));
        cartTable.setSelectionForeground(BakeryApp.WHITE);
        cartTable.setBackground(BakeryApp.WHITE);
        cartTable.getTableHeader().setFont(BakeryApp.FONT_HEADER);
        cartTable.getTableHeader().setBackground(new Color(200, 220, 220));
        cartTable.getTableHeader().setForeground(BakeryApp.TEXT_DARK);

        // Alternating row renderer
        cartTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) comp.setBackground(r % 2 == 0 ? BakeryApp.TABLE_ROW_A : BakeryApp.TABLE_ROW_B);
                return comp;
            }
        });

        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(180, 160, 160)));
        scrollPane.setBackground(BakeryApp.WHITE);
        scrollPane.setPreferredSize(new Dimension(0, 220));

        // ── Discount + Summary ────────────────────────────────────────────
        JPanel discountRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        discountRow.setBackground(BakeryApp.CRIMSON);
        JLabel dcLbl = new JLabel("Discount Code:");
        dcLbl.setFont(BakeryApp.FONT_BODY);
        dcLbl.setForeground(BakeryApp.WHITE);
        discountField = new JTextField(12);
        discountField.setFont(BakeryApp.FONT_BODY);
        JButton applyBtn = BakeryApp.actionBtn("Apply", BakeryApp.GOLD);
        applyBtn.setForeground(BakeryApp.TEXT_DARK);
        discountMsg = new JLabel("");
        discountMsg.setFont(BakeryApp.FONT_SMALL);
        discountMsg.setForeground(BakeryApp.GOLD);
        discountRow.add(dcLbl); discountRow.add(discountField); discountRow.add(applyBtn); discountRow.add(discountMsg);

        applyBtn.addActionListener(e -> applyDiscount());

        JPanel summary = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6));
        summary.setBackground(BakeryApp.CRIMSON_DARK);
        summary.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        JLabel summaryLbl = new JLabel("Summary & Navigation");
        summaryLbl.setFont(BakeryApp.FONT_HEADER);
        summaryLbl.setForeground(BakeryApp.GOLD);
        discountLabel = new JLabel("Discount: RM 0.00");
        discountLabel.setFont(BakeryApp.FONT_BODY);
        discountLabel.setForeground(BakeryApp.GOLD);
        totalLabel = new JLabel("Grand Total: RM 0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        totalLabel.setForeground(BakeryApp.WHITE);

        JButton checkoutBtn = BakeryApp.actionBtn("Proceed to Checkout →", BakeryApp.GOLD);
        checkoutBtn.setForeground(BakeryApp.TEXT_DARK);
        checkoutBtn.addActionListener(e -> {
            if (app.getCart().getItems().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Your cart is empty!", "Empty Cart", JOptionPane.WARNING_MESSAGE);
            } else {
                app.goToCheckout();
            }
        });

        summary.add(summaryLbl);
        summary.add(Box.createHorizontalStrut(20));
        summary.add(discountLabel);
        summary.add(Box.createHorizontalStrut(20));
        summary.add(totalLabel);
        summary.add(Box.createHorizontalStrut(30));
        summary.add(checkoutBtn);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(BakeryApp.CRIMSON);
        bottom.add(discountRow, BorderLayout.NORTH);
        bottom.add(summary,     BorderLayout.SOUTH);

        body.add(topSection, BorderLayout.NORTH);
        body.add(scrollPane, BorderLayout.CENTER);
        body.add(bottom,     BorderLayout.SOUTH);
        return body;
    }

    void refresh() {
        tableModel.setRowCount(0);
        for (CartItem item : app.getCart().getItems()) {
            tableModel.addRow(new Object[]{
                    item.getProductName(),
                    String.format("RM %.2f", item.getUnitPrice()),
                    item.getQuantity(),
                    String.format("RM %.2f", item.getSubtotal())
            });
        }
        updateTotals();

        // Refresh product dropdown
        List<Product> products = ProductDB.getAvailableProducts();
        productDropdown.removeAllItems();
        for (Product p : products) productDropdown.addItem(p.getName());
    }

    private void updateTotals() {
        Cart cart = app.getCart();
        cart.recalculateTotal();
        discountLabel.setText(String.format("Discount: -RM %.2f", cart.getDiscountAmount()));
        totalLabel.setText(String.format("Grand Total: RM %.2f", cart.getTotal()));
    }

    private void addProductFromDropdown() {
        String selected = (String) productDropdown.getSelectedItem();
        if (selected == null) return;
        int qty;
        try { qty = Integer.parseInt(qtyField.getText().trim()); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (qty < 1) { JOptionPane.showMessageDialog(this, "Quantity must be at least 1."); return; }

        for (Product p : ProductDB.getAvailableProducts()) {
            if (p.getName().equals(selected)) {
                if (qty > ProductDB.checkStock(p.getProductID())) {
                    JOptionPane.showMessageDialog(this,
                            "Only " + ProductDB.checkStock(p.getProductID()) + " items available.",
                            "Stock Limit", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                app.getCart().addItem(p, qty);
                refresh();
                return;
            }
        }
    }

    private void updateSelected() {
    int row = cartTable.getSelectedRow();
    if (row < 0) {
        JOptionPane.showMessageDialog(this, "Please click on a row in the table first, then click Update.");
        return;
    }
    int qty;
    try {
        qty = Integer.parseInt(qtyField.getText().trim());
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter a valid number in the Quantity field.");
        return;
    }
    if (qty < 1) {
        JOptionPane.showMessageDialog(this, "Quantity must be at least 1. Use Remove to delete an item.");
        return;
    }
    CartItem item = app.getCart().getItems().get(row);
    int available = ProductDB.checkStock(item.getProductID());
    if (qty > available) {
        JOptionPane.showMessageDialog(this, "Only " + available + " items available in stock.");
        return;
    }
    app.getCart().updateItemQty(item.getProductID(), qty);
    JOptionPane.showMessageDialog(this, "\"" + item.getProductName() + "\" quantity updated to " + qty + "!");
    refresh();
}

    private void removeSelected() {
        int row = cartTable.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select an item to remove."); return; }
        CartItem item = app.getCart().getItems().get(row);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Remove \"" + item.getProductName() + "\" from cart?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            app.getCart().removeItem(item.getProductID());
            refresh();
        }
    }

    private void applyDiscount() {
        String code = discountField.getText().trim();
        if (code.isEmpty()) { discountMsg.setText("Please enter a code."); return; }
        Cart cart = app.getCart();
        if (cart.getItems().isEmpty()) { discountMsg.setText("Cart is empty."); return; }
        if (!DiscountService.checkMinSpend(code, cart.getRawTotal())) {
            discountMsg.setText("Min. spend RM 10.00 required.");
            discountMsg.setForeground(new Color(255, 180, 100));
            return;
        }
        boolean ok = cart.applyDiscountCode(code);
        if (ok) {
            discountMsg.setText("✓ Code applied! You save RM " + String.format("%.2f", cart.getDiscountAmount()));
            discountMsg.setForeground(BakeryApp.GOLD);
        } else {
            discountMsg.setText("✗ Invalid or expired code.");
            discountMsg.setForeground(new Color(255, 120, 120));
        }
        updateTotals();
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 3 – Checkout (UC4)
// ═════════════════════════════════════════════════════════════════════════════
class CheckoutPanel extends JPanel {
    private BakeryApp app;
    private JTextArea summaryArea;
    private JTextField addressField;
    private JLabel totalLabel;

    CheckoutPanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CREAM);
        add(BakeryApp.headerPanel("📋  Checkout"), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridBagLayout());
        body.setBackground(BakeryApp.CREAM);
        body.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;

        // Order summary
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel sumLbl = new JLabel("Order Summary");
        sumLbl.setFont(BakeryApp.FONT_HEADER);
        sumLbl.setForeground(BakeryApp.CRIMSON);
        body.add(sumLbl, gbc);

        gbc.gridy = 1;
        summaryArea = new JTextArea(8, 40);
        summaryArea.setEditable(false);
        summaryArea.setFont(BakeryApp.FONT_BODY);
        summaryArea.setBackground(BakeryApp.WHITE);
        summaryArea.setBorder(BorderFactory.createLineBorder(BakeryApp.CRIMSON));
        JScrollPane sp = new JScrollPane(summaryArea);
        body.add(sp, gbc);

        // Address
        gbc.gridy = 2; gbc.gridwidth = 1;
        JLabel addrLbl = new JLabel("Delivery Address:");
        addrLbl.setFont(BakeryApp.FONT_BODY);
        body.add(addrLbl, gbc);

        gbc.gridx = 1;
        addressField = new JTextField(app.getCustomer().getAddress(), 30);
        addressField.setFont(BakeryApp.FONT_BODY);
        body.add(addressField, gbc);

        // Total
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel tLbl = new JLabel("Total Payable:");
        tLbl.setFont(BakeryApp.FONT_HEADER);
        body.add(tLbl, gbc);

        gbc.gridx = 1;
        totalLabel = new JLabel("RM 0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        totalLabel.setForeground(BakeryApp.CRIMSON);
        body.add(totalLabel, gbc);

        // Buttons
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(BakeryApp.CREAM);
        JButton backBtn    = BakeryApp.actionBtn("← Back to Cart",  Color.WHITE);
        JButton confirmBtn = BakeryApp.actionBtn("Confirm Order →", Color.WHITE);
        backBtn.setForeground(new Color(100,100,100));
        confirmBtn.setForeground(BakeryApp.CRIMSON);
        backBtn.addActionListener(e -> app.showScreen("cart"));
        confirmBtn.addActionListener(e -> confirmOrder());
        btnRow.add(backBtn); btnRow.add(confirmBtn);
        body.add(btnRow, gbc);

        return body;
    }

    void refresh() {
        Cart cart = app.getCart();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-30s %8s %6s %10s%n", "Product", "Price", "Qty", "Subtotal"));
        sb.append("------------------------------------------------------------").append("\n");
        for (CartItem item : cart.getItems()) {
            sb.append(String.format("%-30s RM%6.2f %6d RM%8.2f%n",
                    item.getProductName(), item.getUnitPrice(), item.getQuantity(), item.getSubtotal()));
        }
        sb.append("------------------------------------------------------------").append("\n");
        if (cart.getDiscountAmount() > 0)
            sb.append(String.format("Discount (%s): -RM %.2f%n", cart.getAppliedCode(), cart.getDiscountAmount()));
        sb.append(String.format("TOTAL: RM %.2f%n", cart.getTotal()));
        summaryArea.setText(sb.toString());
        totalLabel.setText(String.format("RM %.2f", cart.getTotal()));
        addressField.setText(app.getCustomer().getAddress());
    }

    private void confirmOrder() {
        String addr = addressField.getText().trim();
        if (addr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a delivery address.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cart cart = app.getCart();
        
        // 1. Create the order using your factory
        Order order = BakeryComponentFactory.createOrder(app.getCustomer().getCustomerID(), cart.getTotal(), addr, cart.getItems());
        order.checkout(); 
        
        // 2. THE FIX: Capture the boolean result from the updated OrderDB
        boolean success = sales.controller.OrderDB.saveOrder(order);

        // 3. Route the user based on the database response
        if (success) {
            // Database successfully generated an ID and saved the items! Move to Payment.
            app.goToPayment(order);
        } else {
            // Database failed (e.g., table missing, connection dropped). Stop the flow!
            JOptionPane.showMessageDialog(this, "Database Error: Could not save the order to the system.", "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 4 – Process Payment (UC5)
// ═════════════════════════════════════════════════════════════════════════════
class PaymentPanel extends JPanel {
    private BakeryApp app;
    private Order order;
    private JLabel orderTotalLabel;
    private JComboBox<String> methodBox;
    private JTextField detailsField;

    PaymentPanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CREAM);
        add(BakeryApp.headerPanel("💳  Process Payment"), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildBody() {
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(BakeryApp.CREAM);
        wrap.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        // Card
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(BakeryApp.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BakeryApp.CRIMSON, 2),
                BorderFactory.createEmptyBorder(20, 30, 20, 30)));

        JLabel heading = new JLabel("Payment Details");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 20));
        heading.setForeground(BakeryApp.CRIMSON);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);

        orderTotalLabel = new JLabel("Amount: RM 0.00");
        orderTotalLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        orderTotalLabel.setForeground(BakeryApp.CRIMSON);
        orderTotalLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setForeground(new Color(220, 200, 200));

        JLabel methodLbl = new JLabel("Payment Method:");
        methodLbl.setFont(BakeryApp.FONT_BODY);
        methodBox = new JComboBox<>(new String[]{"Online Banking", "Credit/Debit Card", "E-Wallet (Touch 'n Go)", "Cash on Delivery"});
        methodBox.setFont(BakeryApp.FONT_BODY);
        methodBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        JLabel detailsLbl = new JLabel("Reference / Card Number (last 4 digits):");
        detailsLbl.setFont(BakeryApp.FONT_BODY);
        detailsField = new JTextField();
        detailsField.setFont(BakeryApp.FONT_BODY);
        detailsField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        JButton payBtn = BakeryApp.actionBtn("Confirm Payment", Color.WHITE);
        payBtn.setForeground(BakeryApp.CRIMSON);
        payBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        payBtn.setMaximumSize(new Dimension(260, 40));
        payBtn.addActionListener(e -> processPayment());

        card.add(heading); card.add(Box.createVerticalStrut(8));
        card.add(orderTotalLabel); card.add(Box.createVerticalStrut(10));
        card.add(sep); card.add(Box.createVerticalStrut(14));
        card.add(methodLbl); card.add(Box.createVerticalStrut(4)); card.add(methodBox);
        card.add(Box.createVerticalStrut(12));
        card.add(detailsLbl); card.add(Box.createVerticalStrut(4)); card.add(detailsField);
        card.add(Box.createVerticalStrut(20));
        card.add(payBtn);

        gbc.gridx = 0; gbc.gridy = 0;
        wrap.add(card, gbc);
        return wrap;
    }

    void setOrder(Order o) {
        this.order = o;
        orderTotalLabel.setText(String.format("Amount: RM %.2f", o.getTotal()));
        detailsField.setText("");
    }

private void processPayment() {
        String details = detailsField.getText().trim();
        if (details.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter payment reference details.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String method  = (String) methodBox.getSelectedItem();
        PaymentMethod resolvedMethod = BakeryComponentFactory.resolvePaymentMethod(method);
        
        // 1. Calculate the fee FIRST
        double extraFee = resolvedMethod.getProcessingFee(order.getTotal());
        double finalAmount = order.getTotal() + extraFee;

        // 2. Create the payment using the NEW finalAmount (not order.getTotal())
        Payment payment = BakeryComponentFactory.createPayment(order.getOrderID(), method, finalAmount);
        
        // 3. Show the popup to the user
        if (extraFee > 0) {
            JOptionPane.showMessageDialog(this, 
                "A processing fee of RM " + String.format("%.2f", extraFee) + 
                " has been applied for using " + resolvedMethod.getDescription() + ".\n" +
                "New Total: RM " + String.format("%.2f", finalAmount), 
                "Processing Fee Applied", 
                JOptionPane.INFORMATION_MESSAGE);
        }
        
        boolean success = payment.processPayment(details);
        if (success) {
            order.confirmOrder();
            // Deduct stock
            
                for (CartItem item : order.getOrderItems()) {
                ProductDB.deductStock(item.getProductID(), item.getQuantity());
                }       
            app.resetCart();
            app.goToInvoice(order, payment);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Payment failed. Please try again with a different method.",
                    "Payment Declined", JOptionPane.ERROR_MESSAGE);
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 5 – Invoice (UC6)
// ═════════════════════════════════════════════════════════════════════════════
class InvoicePanel extends JPanel {
    private BakeryApp app;
    private JLabel invoiceIDLabel, dateLabel, customerLabel, statusLabel;
    private JTextArea invoiceBody;
    private JLabel totalLabel;
    private Order currentOrder;
    private Payment currentPayment;

    InvoicePanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CREAM);
        add(BakeryApp.headerPanel("🧾  Invoice"), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new BorderLayout(0, 0));
        body.setBackground(BakeryApp.CREAM);
        body.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));

        // Invoice card
        JPanel invoice = new JPanel(new BorderLayout());
        invoice.setBackground(BakeryApp.WHITE);
        invoice.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BakeryApp.CRIMSON, 2),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)));

        // Invoice header
        JPanel invHead = new JPanel(new GridLayout(2, 2, 0, 0));
        invHead.setBackground(BakeryApp.CRIMSON);
        invHead.setBorder(BorderFactory.createEmptyBorder(12, 18, 12, 18));

        invoiceIDLabel  = styledLabel("Invoice #: -");
        dateLabel       = styledLabel("Date: -");
        customerLabel   = styledLabel("Customer: -");
        statusLabel     = styledLabel("Status: -");
        invHead.add(invoiceIDLabel); invHead.add(dateLabel);
        invHead.add(customerLabel);  invHead.add(statusLabel);

        invoiceBody = new JTextArea(10, 50);
        invoiceBody.setEditable(false);
        invoiceBody.setFont(new Font("Monospaced", Font.PLAIN, 13));
        invoiceBody.setBackground(BakeryApp.WHITE);
        invoiceBody.setBorder(BorderFactory.createEmptyBorder(12, 18, 12, 18));

        totalLabel = new JLabel("TOTAL: RM 0.00", SwingConstants.RIGHT);
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        totalLabel.setForeground(BakeryApp.CRIMSON);
        totalLabel.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));

        invoice.add(invHead,         BorderLayout.NORTH);
        invoice.add(new JScrollPane(invoiceBody), BorderLayout.CENTER);
        invoice.add(totalLabel,     BorderLayout.SOUTH);

        // Actions
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 12));
        actions.setBackground(BakeryApp.CREAM);

        JButton downloadBtn = BakeryApp.actionBtn("⬇ Download Invoice", Color.WHITE);
        JButton emailBtn    = BakeryApp.actionBtn("✉ Send via Email",   Color.WHITE);
        JButton homeBtn     = BakeryApp.actionBtn("🏠 Back to Browse",   Color.WHITE);
        JButton historyBtn  = BakeryApp.actionBtn("📜 View Order History", Color.WHITE);
        downloadBtn.setForeground(BakeryApp.CRIMSON);
        emailBtn.setForeground(new Color(70,130,180));
        homeBtn.setForeground(new Color(80,80,80));
        historyBtn.setForeground(new Color(60,120,60));

        downloadBtn.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Invoice downloaded to: " + (currentOrder != null ? "invoice_" + currentOrder.getOrderID() + ".pdf" : "-"),
                "Downloaded", JOptionPane.INFORMATION_MESSAGE));

        emailBtn.addActionListener(e -> {
            String email = JOptionPane.showInputDialog(this, "Enter email address:", app.getCustomer().getEmail());
            if (email != null && !email.isEmpty())
                JOptionPane.showMessageDialog(this, "Invoice sent to " + email + "!", "Email Sent",
                        JOptionPane.INFORMATION_MESSAGE);
        });

        homeBtn.addActionListener(e -> app.showScreen("browse"));
        historyBtn.addActionListener(e -> { app.getHistoryPanel().refresh(); app.showScreen("history"); });

        actions.add(downloadBtn); actions.add(emailBtn); actions.add(historyBtn); actions.add(homeBtn);

        body.add(invoice, BorderLayout.CENTER);
        body.add(actions, BorderLayout.SOUTH);
        return body;
    }

    private JLabel styledLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(BakeryApp.FONT_BODY);
        lbl.setForeground(BakeryApp.WHITE);
        return lbl;
    }

    void setData(Order order, Payment payment) {
        this.currentOrder   = order;
        this.currentPayment = payment;
        
        Invoice inv = BakeryComponentFactory.createInvoice(order.getOrderID());
        inv.generate();
        
        invoiceIDLabel.setText("Invoice #: " + inv.getInvoiceID());
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        dateLabel.setText("Date: " + sdf.format(inv.getIssueDate()));
        customerLabel.setText("Customer: " + app.getCustomer().getName());
        statusLabel.setText("Status: PAID  |  " + payment.getMethod());
        
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-32s %8s %5s %10s%n", "Product", "Unit Price", "Qty", "Subtotal"));
        sb.append("------------------------------------------------------------").append("\n");
        for (CartItem item : order.getOrderItems()) {
            sb.append(String.format("%-32s RM%6.2f %5d RM%8.2f%n",
                    item.getProductName(), item.getUnitPrice(), item.getQuantity(), item.getSubtotal()));
        }
        sb.append("-".repeat(60)).append("\n");
        
        // NEW CODE: Calculate if there was a fee and print it
        double fee = payment.getAmount() - order.getTotal();
        if (fee > 0) {
            sb.append(String.format("%-45s RM %8.2f%n", "Processing Fee", fee));
        }

        // Change order.getTotal() to payment.getAmount() so it includes the fee
        sb.append(String.format("%-45s RM %8.2f%n", "GRAND TOTAL", payment.getAmount()));
        
        sb.append("\nDelivery: ").append(order.getShippingAddress());
        sb.append("\nThank you for your purchase!\n");
        invoiceBody.setText(sb.toString());

        // Update the big red label at the bottom too
        totalLabel.setText(String.format("GRAND TOTAL: RM %.2f", payment.getAmount()));
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SCREEN 6 – Order History (UC7)
// ═════════════════════════════════════════════════════════════════════════════
class HistoryPanel extends JPanel {
    private BakeryApp app;
    private DefaultTableModel tableModel;
    private JTable historyTable;
    private JTextArea detailArea;

    HistoryPanel(BakeryApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(BakeryApp.CREAM);
        add(BakeryApp.headerPanel("📜  My Order History"), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new BorderLayout(0, 10));
        body.setBackground(BakeryApp.CREAM);
        body.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        String[] cols = {"Order ID", "Date", "Total (RM)", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        historyTable = new JTable(tableModel);
        historyTable.setFont(BakeryApp.FONT_BODY);
        historyTable.setRowHeight(28);
        historyTable.setSelectionBackground(BakeryApp.CRIMSON);
        historyTable.setSelectionForeground(BakeryApp.WHITE);
        historyTable.getTableHeader().setFont(BakeryApp.FONT_HEADER);
        historyTable.getTableHeader().setBackground(BakeryApp.CRIMSON);
        historyTable.getTableHeader().setForeground(BakeryApp.WHITE);

        historyTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) comp.setBackground(r % 2 == 0 ? BakeryApp.TABLE_ROW_A : BakeryApp.TABLE_ROW_B);
                return comp;
            }
        });

        JScrollPane tableScroll = new JScrollPane(historyTable);
        tableScroll.setBorder(BorderFactory.createLineBorder(BakeryApp.CRIMSON));

        detailArea = new JTextArea(8, 40);
        detailArea.setEditable(false);
        detailArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailArea.setBackground(BakeryApp.WHITE);
        detailArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(BakeryApp.CRIMSON), "Order Details",
                        TitledBorder.LEFT, TitledBorder.TOP, BakeryApp.FONT_BODY, BakeryApp.CRIMSON),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));

        historyTable.getSelectionModel().addListSelectionListener(e -> {
            int row = historyTable.getSelectedRow();
            if (row >= 0) {
                Object idObj = tableModel.getValueAt(row, 0);
                int orderID = Integer.parseInt(idObj.toString());
                Order order = OrderDB.getOrderByID(orderID);
                if (order != null) showOrderDetail(order);
            }
        });

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScroll, new JScrollPane(detailArea));
        split.setDividerLocation(250);
        split.setBorder(null);

        JLabel hint = new JLabel("Click a row to view order details.");
        hint.setFont(BakeryApp.FONT_SMALL);
        hint.setForeground(new Color(140, 80, 80));

        body.add(hint,  BorderLayout.NORTH);
        body.add(split, BorderLayout.CENTER);
        return body;
    }

    void refresh() {
        tableModel.setRowCount(0);
        List<Order> orders = OrderDB.getOrdersByCustomer(app.getCustomer().getCustomerID());
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        // newest first
        for (int i = orders.size() - 1; i >= 0; i--) {
            Order o = orders.get(i);
            tableModel.addRow(new Object[]{
                    o.getOrderID(),
                    sdf.format(o.getOrderDate()),
                    String.format("%.2f", o.getTotal()),
                    o.getStatus()
            });
        }
        if (orders.isEmpty()) detailArea.setText("No past orders found.");
        else detailArea.setText("Select an order above to view details.");
    }

    private void showOrderDetail(Order order) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        StringBuilder sb = new StringBuilder();
        sb.append("Order ID : ").append(order.getOrderID()).append("\n");
        sb.append("Date     : ").append(sdf.format(order.getOrderDate())).append("\n");
        sb.append("Status   : ").append(order.getStatus()).append("\n");
        sb.append("Delivery : ").append(order.getShippingAddress()).append("\n");
        sb.append("-------------------------------------------------------").append("\n");
        sb.append(String.format("%-30s %7s %5s %9s%n","Product","Price","Qty","Subtotal"));
        sb.append("-------------------------------------------------------").append("\n");
        for (CartItem item : order.getOrderItems()) {
            sb.append(String.format("%-30s RM%5.2f %5d RM%7.2f%n",
                    item.getProductName(), item.getUnitPrice(), item.getQuantity(), item.getSubtotal()));
        }
        sb.append("-------------------------------------------------------").append("\n");
        sb.append(String.format("TOTAL: RM %.2f%n", order.getTotal()));
        detailArea.setText(sb.toString());
    }
}